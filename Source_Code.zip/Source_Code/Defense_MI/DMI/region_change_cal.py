import torch

a = torch.load('attack_res/celeba/HSIC/Analysis_hp_list_((0.0, 0.0),)_lr_1e-4_Adam_all_epochs_VGG16/all/Trace.pt')
# my_a = torch.load('attack_res/celeba/HSIC/Analysis_1_hp_list_((0, 0.22),)_lr_1e-4_Adam_all_epochs_VGG16/all/Trace.pt')
my_a = torch.load('attack_res/celeba/HSIC/Analysis_DiffAug_hp_list_((0, 0.1),)_lr_1e-4_Adam_all_epochs_VGG16/all/Trace.pt')
torch.set_printoptions(threshold=10_000)
change = a - my_a

print(torch.mean(change, dim=1))
