from fid_score import calculate_fid_given_paths
import os

##############CelebA############
# result_dir = "attack_res/celeba/HSIC/Analysis_hp_list_((0.0, 0.0),)_lr_1e-4_Adam_all_epochs_VGG16/res_success/res_success"
# result_dir = "attack_res/celeba/HSIC/Analysis_1_hp_list_((0.05, 0.5),)_lr_1e-4_Adam_all_epochs_VGG16/all_class"
# result_dir = "attack_res/celeba/HSIC/Analysis_hp_list_((0.0, 0.0),)_lr_1e-4_Adam_all_epochs_VGG16/all_class" # Similarity:0.5070 Similarity:0.5724 Distance:0.9184 Distance_79: 0.9576 Diatnce 82: 0.9292
# result_dir = "attack_res/celeba/HSIC/Analysis_DiffAug_hp_list_((0, 0.1),)_lr_1e-4_Adam_all_epochs_VGG16/all/all/" # Similarity:0.4455 Similarity:0.5058 Distance:0.9867
# result_dir = "attack_res/celeba/HSIC/Analysis_DiffAug_hp_list_((0, 0.15),)_milestones_(40,)_lr_1e-4_Adam_all_epochs_VGG16/all_class" # Similarity:0.4421 Similarity:0.4999 Distance:0.9937
# result_dir = "attack_res/celeba/HSIC/Analysis_1_hp_list_((0, 0.22),)_lr_1e-4_Adam_all_epochs_VGG16/all/" # Similarity:0.4656 Similarity:0.5334
# result_dir = "attack_res/celeba/HSIC/Analysis_DiffAug_hp_list_((0, 0.11),)_lr_1e-4_Adam_all_epochs_VGG16/all/all" # Similarity:0.4437 Similarity:0.4977 Distance:0.9955
# result_dir = "attack_res/celeba/HSIC/Analysis_hp_list_((0.0, 0.0),)_lr_1e-2_SGD_VGG16/all/all" # Similarity:0.5419 Similarity:0.6137 Distance:0.8733
# result_dir = "attack_res/celeba/HSIC/Analysis_1_hp_list_((0.05, 0.5),)_milestones_(40,)_lr_1e-4_Adam_all_epochs_VGG16/all/" # Distance:0.9702
# result_dir = "attack_res/celeba/HSIC/Analysis_DiffAug_hp_list_((0, 0),)_milestones_(40,)_lr_1e-4_Adam_all_epochs_VGG16/all_class" # Distance: 0.9402
result_dir = "attack_res/celeba/HSIC/Analysis_DiffAug_cutout11.5_hp_list_((0, 0),)_milestones_(40,)_lr_1e-4_Adam_all_epochs_VGG16/all_class" # Distance: 0.9762
test_dataset_dir = "/home/hung/celeba/train_images"
# gan_dataset_dir = "/home/hung/celeba/gan_images"

###########MINIST#############
# result_dir = "attack_res/mnist/HSIC/Analysis_1_hp_list_((0, 0),)_milestones_(20, 35)_lr_1e-4_Adam_all_epochs_MCNN/all/all" # Distance:0.9450
# result_dir = "attack_res/mnist/HSIC/Analysis_1_hp_list_((2, 20),)_milestones_(20, 35)_lr_1e-4_Adam_all_epochs_MCNN/all/all" # Distance:1.0032
# result_dir = "attack_res/mnist/HSIC/Analysis_1_hp_list_((0, 1000),)_milestones_(20, 35)_lr_1e-4_Adam_all_epochs_MCNN/all/all" # Distance:1.1408
# result_dir = "attack_res/mnist/HSIC/Analysis_GaussianBlurr_1_hp_list_((0, 1000),)_milestones_(20, 35)_lr_1e-4_Adam_all_epochs_MCNN/all/all" # Distance:1.1308
# result_dir = "attack_res/mnist/HSIC/Analysis_DiffAugCutout1_2_hp_list_((0, 100),)_milestones_(20, 35)_lr_1e-4_Adam_all_epochs_MCNN/all_class/" # average_distance:1.1046
# test_dataset_dir = "/home/hung/mnist/train_images/"


##############CIFAR############
# result_dir = "attack_res/cifar/HSIC/Analysis_2_hp_list_((0, 0),)_milestones_(60,)_lr_1e-4_Adam_all_epochs_VGG16/all_class/" # Distance:0.6501
# result_dir = "attack_res/cifar/HSIC/Analysis_2_hp_list_((0, 10),)_milestones_(60,)_lr_1e-4_Adam_all_epochs_VGG16/all_class/" # Distance:0.6683
# result_dir = "attack_res/cifar/HSIC/Analysis_2_hp_list_((0.1, 1),)_milestones_(60,)_lr_1e-4_Adam_all_epochs_VGG16/all_class/" # Distance:0.6487
# result_dir = "attack_res/cifar/HSIC/Analysis_DiffAug_cutout14_2_hp_list_((0, 10),)_milestones_(60,)_lr_1e-4_Adam_all_epochs_VGG16/all_class/" # Distance:0.7494
# test_dataset_dir = '/home/hung/cifar/train_images'

# fid_value = calculate_fid_given_paths('celeba', [os.path.join(test_dataset_dir), os.path.join(result_dir)],128, 1, 2048)
# fid_value = calculate_fid_given_paths('celeba', [os.path.join(test_dataset_dir), os.path.join(gan_dataset_dir)], 64, 1, 2048)
# print(f'FID:{fid_value:.4f}')
# exit()

average_distance = 0
num_classes = 300
for i in range(num_classes):
    if i % 100 == 0 :
        print("Processing ...", i, average_distance/(i+1))
    _, distance = calculate_fid_given_paths('celeba', [os.path.join(test_dataset_dir, "class_"+str(i)), os.path.join(result_dir, "class_"+str(i))], 64, 1, 2048)
    average_distance += distance
average_distance /= num_classes
print(result_dir)
print(f'average_distance:{average_distance:.4f}')
# print(f'FID:{fid_value:.4f}')

# attack_res/celeba/HSIC/Analysis_hp_list_((0.0, 0.0),)_lr_1e-4_Adam_all_epochs_VGG16/all/: FID:255.0997 Distance:31.2629
# Analysis_DiffAug_hp_list_((0, 0.1),)_lr_1e-4_Adam_all_epochs_VGG16: FID:213.2046 Distance:33.2032 Distance:32.8814 Distance:32.6982 Distance:28.7933
# Analysis_1_hp_list_((0.05, 0.5),)_lr_1e-4_Adam_all_epochs_VGG16: FID:277.0398 Distance:32.4550 Distance:33.3872 Distance:33.3189
# Analysis_1_hp_list_((0, 0.22),)_lr_1e-4_Adam_all_epochs_VGG16 FID:249.6215 Distance:32.5177
# Analysis_DiffAug_hp_list_((0, 0.15),)_milestones_(40,)_lr_1e-4_Adam_all_epochs_VGG16 Distance:33.3392
# /home/hung/gan_images: FID:4.7937 FID:26.9393


# Analysis_hp_list_((0.0, 0.0),)_lr_1e-4_Adam_all_epochs_VGG16: Distance:34.4039
# Analysis_DiffAug_hp_list_((0, 0.1),)_lr_1e-4_Adam_all_epochs_VGG16: Distance:35.6612
# Analysis_1_hp_list_((0.05, 0.5),)_lr_1e-4_Adam_all_epochs_VGG16: Distance:36.0483
# Analysis_DiffAug_hp_list_((0, 0.15),)_milestones_(40,)_lr_1e-4_Adam_all_epochs_VGG16: Distance:36.1620
# Analysis_1_hp_list_((0, 0.22),)_lr_1e-4_Adam_all_epochs_VGG16: Distance:35.3095

# Output
# Analysis_1_hp_list_((0.05, 0.5),)_lr_1e-4_Adam_all_epochs_VGG16: Distance:8.9745
# Analysis_DiffAug_hp_list_((0, 0.1),)_lr_1e-4_Adam_all_epochs_VGG16:
# Analysis_DiffAug_hp_list_((0, 0.15),)_milestones_(40,)_lr_1e-4_Adam_all_epochs_VGG16:

