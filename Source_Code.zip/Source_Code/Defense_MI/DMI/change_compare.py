import torch
from torchvision.utils import save_image

# change_nodef = torch.load('attack_res/celeba/HSIC/Analysis_hp_list_((0.0, 0.0),)_lr_1e-4_Adam_all_epochs_VGG16/Trace.pt')
# change_bido = torch.load('attack_res/celeba/HSIC/Analysis_1_hp_list_((0.05, 0.5),)_lr_1e-4_Adam_all_epochs_VGG16/Trace.pt')
# change_uido = torch.load('attack_res/celeba/HSIC/Analysis_DiffAug_hp_list_((0, 0.1),)_lr_1e-4_Adam_all_epochs_VGG16/Trace.pt')
change_nodef = torch.load('attack_res/celeba/HSIC/Analysis_hp_list_((0.0, 0.0),)_lr_1e-4_Adam_all_epochs_VGG16/Trace_rgb.pt')
# change_bido = torch.load('attack_res/celeba/HSIC/Analysis_1_hp_list_((0.05, 0.5),)_lr_1e-4_Adam_all_epochs_VGG16/Trace_rgb.pt')
change_uido = torch.load('attack_res/celeba/HSIC/Analysis_DiffAug_hp_list_((0, 0.1),)_lr_1e-4_Adam_all_epochs_VGG16/Trace_rgb.pt')
comparison = change_nodef - change_uido
# comparison = change_uido - change_nodef
# comparison = torch.ceil(comparison)
comparison*=10
print(comparison)
save_image(comparison, 'comparison.jpg')

