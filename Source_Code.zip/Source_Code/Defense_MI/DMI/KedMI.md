# ../BiDO/target_model/NoDef_VGG16_0.000&0.000_86.90.tar
Avg acc:78.47   Avg acc5:94.07  Avg acc_var:4.6013      Avg acc_var5:2.3540
KNN Dist 1289.46
FID 19.85
Acc:15.9333 (+/- 4.0828), Acc5:35.4000 (+/- 4.8351)

# Analysis_1/hp_list_((0.05, 0.5),)_lr_1e-4_Adam_all_epochs/VGG16_0.050&0.500_79.85_90.33_47.tar
Avg acc:43.53   Avg acc5:71.40  Avg acc_var:3.9964      Avg acc_var5:4.1535
KNN Distance: 1494.35
FID: 33.07
Acc:6.6000 (+/- 3.1921), Acc5:15.6000 (+/- 5.3461)

# Analysis_DiffAug_cutout_0.5/hp_list_((0, 0),)_milestones_(40,)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.000_84.74_92.95_45.tar
Avg acc:45.00   Avg acc5:70.73  Avg acc_var:5.2603      Avg acc_var5:4.8004

# Analysis_DiffAug_cutout11.5/hp_list_((0, 0),)_milestones_(40,)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.000_84.87_92.15_42.tar
Avg acc:44.27   Avg acc5:73.07  Avg acc_var:3.8157      Avg acc_var5:3.6769
KNN Dist 1496.34
FID 25.86
Acc:4.4000 (+/- 1.5412), Acc5:13.6000 (+/- 4.2903)

# Analysis_DiffAug_cutout_0.75/hp_list_((0, 0),)_milestones_(40,)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.000_82.28_91.39_46.tar
Avg acc:38.93   Avg acc5:66.53  Avg acc_var:5.0487      Avg acc_var5:4.4567
KNN Dist 1535.50
FID 26.90
Acc:4.4667 (+/- 3.3747), Acc5:13.0000 (+/- 4.1663)

# Analysis_Random_Erasing_0.1_0.4_1_2/hp_list_((0, 0),)_milestones_(40,)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.000_80.25_89.76_44.tar
Avg acc:32.07   Avg acc5:59.27  Avg acc_var:5.8012      Avg acc_var5:2.3865
KNN Dist 1589.60
FID 30.08
Acc:4.2667 (+/- 1.8357), Acc5:11.4667 (+/- 3.5928)

############ MNIST ####################
# Analysis_DiffAug_cutout_0.9/hp_list_((0, 0),)_milestones_(20, 35)_lr_1e-4_Adam_all_epochs/MCNN_0.000&0.000_99.63_100.00_16.tar

# Analysis_2/hp_list_((0, 0),)_milestones_(20, 35)_lr_1e-4_Adam_all_epochs/MCNN_0.000&0.000_99.86_100.00_5.tar
Acc:14.7200 (+/- 12.9249), Acc5:93.3200 (+/- 8.9649)

# Analysis_2/hp_list_((2, 20),)_milestones_(20, 35)_lr_1e-4_Adam_all_epochs/MCNN_2.000&20.000_99.49_100.00_14.tar
Acc:8.9600 (+/- 10.5750), Acc5:96.3600 (+/- 6.6661)


# Analysis_Random_Erasing_NA/hp_list_((2, 20),)_milestones_(20, 35)_lr_1e-4_Adam_all_epochs/MCNN_2.000&20.000_99.49_100.00_19.tar
Acc:36.6800 (+/- 7.5481), Acc5:96.9600 (+/- 6.8485)

# Analysis_DiffAug_RandomErasing_0.2_0.8_1_2_value_1.0/hp_list_((0, 0),)_milestones_(20,)_lr_1e-4_Adam_all_epochs/MCNN_0.000&0.000_99.57_100.00_19.tar
Acc:26.4800 (+/- 10.6719), Acc5:91.0400 (+/- 10.1980)

# Analysis_DiffAug_RandomErasing_NA/hp_list_((0, 0),)_milestones_(20,)_lr_1e-4_Adam_all_epochs/MCNN_0.000&0.000_99.94_100.00_10.tar
Acc:47.8400 (+/- 5.1901), Acc5:100.0000 (+/- 0.0000)



##################### Cifar ###################
# Analysis_2/hp_list_((0, 0),)_milestones_(60,)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.000_95.59_100.00_49.tar
Acc:59.0400 (+/- 17.0997), Acc5:98.0000 (+/- 3.2084)

# Analysis_2/hp_list_((0.1, 1),)_milestones_(60,)_lr_1e-4_Adam_all_epochs/VGG16_0.100&1.000_93.23_100.00_33.tar
Acc:51.9600 (+/- 16.5491), Acc5:99.1600 (+/- 3.2595)

# Analysis_RE_0.3_0.8_1_1/hp_list_((0, 0),)_milestones_(60,)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.000_91.49_100.00_25.tar
Acc:44.6400 (+/- 17.4415), Acc5:98.6800 (+/- 4.8060)
