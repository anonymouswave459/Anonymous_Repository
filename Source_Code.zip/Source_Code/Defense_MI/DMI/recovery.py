import utils
from utils import *
from generator import *
from discri import *
import torch.nn as nn
import torch, time, time, os, logging, statistics
import numpy as np
from generator import Generator
from argparse import ArgumentDefaultsHelpFormatter, ArgumentParser
from recover_vib import reparameterize, dist_inversion
from fid_score import calculate_fid_given_paths
# from fid_score_raw import calculate_fid_given_paths0

import sys

sys.path.append('../BiDO')
import model

if __name__ == "__main__":
    parser = ArgumentParser(description='Step2: targeted recovery')
    parser.add_argument('--dataset', default='celeba', help='celeba | mnist | cifar')
    parser.add_argument('--defense', default='HSIC', help='HSIC | COCO')
    parser.add_argument('--iter', default=5000, type=int)
    parser.add_argument('--improved_flag', action='store_true', default=True, help='use improved k+1 GAN')
    parser.add_argument('--root_path', default="./improvedGAN")
    parser.add_argument('--model_path', default='../BiDO/target_model')
    parser.add_argument('--save_img_dir', default='./attack_res/')
    parser.add_argument('--success_dir', default='')
    parser.add_argument('--verbose', default=False, type=bool)

    args = parser.parse_args()

    z_dim = 100
    ############################# mkdirs ##############################
    save_model_dir = os.path.join(args.root_path, args.dataset, args.defense)

    ############################# mkdirs ##############################
    file = "./config/" + args.dataset + ".json"
    loaded_args = load_json(json_file=file)
    stage = loaded_args["dataset"]["stage"]
    model_name = loaded_args["dataset"]["model_name"]

    if args.dataset == 'celeba':
        hp_ac_list = [
            #HSIC
            # (0, 0.22, 80.55)
            # (0, 0.1, 80.75)
            # (0.05, 0.5, 79.85)
            (0, 0, 80.25)
            # (0, 0.017, 80.19)
        ]

        for (a1, a2, ac) in hp_ac_list:
            hp_set = "a1 = {:.3f}|a2 = {:.3f}, test_acc={:.2f}".format(a1, a2, ac)
            print(hp_set)
            # path_T = os.path.join(args.model_path, f"{args.dataset}", args.defense,"Analysis/hp_list_((0.0, 0.0),)_lr_1e-2_SGD/VGG16_0.000&0.000_86.90.tar")
            # path_T = os.path.join(args.model_path, args.dataset, args.defense, "Analysis/hp_list_((0.0, 0.0),)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.000_85.01_91.79_30.tar")
            # path_T = os.path.join(args.model_path, args.dataset, args.defense, "Analysis_1/hp_list_((0.05, 0.5),)_lr_1e-4_Adam_all_epochs/VGG16_0.050&0.500_79.85_90.33_47.tar")
            # path_T = os.path.join(args.model_path, f"{args.dataset}", args.defense,"Analysis/hp_list_((0.0, 0.0),)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.000_82.05_90.89_41.tar")
            # path_T = os.path.join(args.model_path, args.dataset, args.defense, 'Analysis_DiffAug/hp_list_((0, 0.1),)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.100_80.75_89.76_44.tar')
            path_T = os.path.join(args.model_path, args.dataset, args.defense, "Analysis_Random_Erasing_0.1_0.4_1_2/hp_list_((0, 0),)_milestones_(40,)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.000_80.25_89.76_44.tar")
            # path_T = os.path.join('../BiDO/target_model/NoDef_VGG16_0.000&0.000_86.90.tar')
            
            # model_name = path_T.split('/')[-2] + "_" + model_name
            # model_name = path_T.split('/')[-3] + "_" + path_T.split('/')[-2] + "_" + model_name
            model_name = path_T.split('/')[-1]
            args.save_img_dir = os.path.join(args.save_img_dir, args.dataset, args.defense, model_name)
            
            args.success_dir = args.save_img_dir + "/res_success"
            os.makedirs(args.success_dir, exist_ok=True)

            args.save_img_dir = os.path.join(args.save_img_dir, 'all')
            os.makedirs(args.save_img_dir, exist_ok=True)
            print(args.save_img_dir, args.success_dir)
            # ac = float(path_T.split('/')[-1].split('_')[2])


            G = Generator(z_dim)
            G = torch.nn.DataParallel(G).cuda()
            D = MinibatchDiscriminator()
            D = torch.nn.DataParallel(D).cuda()

            path_G = os.path.join(save_model_dir, "{}_G_{:.3f}&{:.3f}_{:.2f}.tar").format(model_name, a1, a2, ac)
            path_D = os.path.join(save_model_dir, "{}_D_{:.3f}&{:.3f}_{:.2f}.tar").format(model_name, a1, a2, ac)

            print(path_G, path_D, path_T)

            ckp_G = torch.load(path_G)
            G.load_state_dict(ckp_G['state_dict'],strict=True)
            ckp_D = torch.load(path_D)
            D.load_state_dict(ckp_D['state_dict'],strict=True)

            T = model.VGG16(1000, True)
            T = torch.nn.DataParallel(T).cuda()
            # path_T = os.path.join(args.model_path, f"{args.dataset}", args.defense,
            #                       "{}_{:.3f}&{:.3f}_{:.2f}.tar".format(model_name, a1, a2, ac))

            ckp_T = torch.load(path_T)
            T.load_state_dict(ckp_T['state_dict'],strict=True)

            E = model.FaceNet(1000)
            E = torch.nn.DataParallel(E).cuda()
            path_E = './eval_model/FaceNet_95.88.tar'
            ckp_E = torch.load(path_E)
            E.load_state_dict(ckp_E['state_dict'],strict=True)

            ############         attack     ###########
            aver_acc, aver_acc5, aver_var, aver_var5 = 0, 0, 0, 0
            # evaluate on the first 300 identities only
            ids = 300
            times = 5
            ids_per_time = ids // times
            iden = torch.from_numpy(np.arange(ids_per_time))
            for idx in range(times):
                if args.verbose:
                    print("--------------------- Attack batch [%s]------------------------------" % idx)

                acc, acc5, var, var5 = dist_inversion(args, G, D, T, E, iden, lr=2e-2, lamda=100,
                                                      iter_times=args.iter, clip_range=1, improved=args.improved_flag,
                                                      num_seeds=5, verbose=args.verbose)

                iden = iden + ids_per_time
                aver_acc += acc / times
                aver_acc5 += acc5 / times
                aver_var += var / times
                aver_var5 += var5 / times

            # fid_value = calculate_fid_given_paths(args.dataset,
            #                                       [f'attack_res/{args.dataset}/trainset/',
            #                                        f'attack_res/{args.dataset}/{args.defense}/all/'],
            #                                       50, 1, 2048)
            # print(f'FID:{fid_value:.4f}')
            print("Avg acc:{:.2f}\tAvg acc5:{:.2f}\tAvg acc_var:{:.4f}\tAvg acc_var5:{:.4f}".format(
                    aver_acc,
                    aver_acc5,
                    aver_var,
                    aver_var5))


    elif args.dataset == 'mnist':
        hp_ac_list = [
            # # mnist-coco
            (0, 0, 99.49)
        ]
        for (a1, a2, ac) in hp_ac_list:
            hp_set = "a1 = {:.3f}|a2 = {:.3f}, test_acc={:.2f}".format(a1, a2, ac)
            print(hp_set)
            path_T = os.path.join(args.model_path, f"{args.dataset}", args.defense,"Analysis_Random_Erasing_NA/hp_list_((2, 20),)_milestones_(20, 35)_lr_1e-4_Adam_all_epochs/MCNN_2.000&20.000_99.49_100.00_19.tar")

            model_name = path_T.split('/')[-3] + "_" + path_T.split('/')[-2] + "_" + model_name
            args.save_img_dir = os.path.join(args.save_img_dir, args.dataset, args.defense, model_name)
            args.success_dir = args.save_img_dir + "/res_success"
            os.makedirs(args.success_dir, exist_ok=True)
            args.save_img_dir = os.path.join(args.save_img_dir, 'all')
            os.makedirs(args.save_img_dir, exist_ok=True)


            G = GeneratorMNIST(z_dim)
            G = torch.nn.DataParallel(G).cuda()
            D = MinibatchDiscriminator_MNIST()
            D = torch.nn.DataParallel(D).cuda()

            path_G = os.path.join(save_model_dir, "{}_G_{:.3f}&{:.3f}_{:.2f}.tar").format(model_name, a1, a2, ac)
            path_D = os.path.join(save_model_dir, "{}_D_{:.3f}&{:.3f}_{:.2f}.tar").format(model_name, a1, a2, ac)

            print(path_G, path_D, path_T)

            ckp_G = torch.load(path_G)
            G.load_state_dict(ckp_G['state_dict'], strict=True)
            ckp_D = torch.load(path_D)
            D.load_state_dict(ckp_D['state_dict'], strict=True)

            T = model.MCNN(5)
            T = torch.nn.DataParallel(T).cuda()
            # path_T = os.path.join(args.model_path, f"{args.dataset}", args.defense,
            #                       "{}_{:.3f}&{:.3f}_{:.2f}.tar".format(model_name, a1, a2, ac))
            # path_T = os.path.join(args.model_path, f"{args.dataset}", args.defense,"Analysis/hp_list_((1.0, 50.0),)_lr_1e-1_Adam/MCNN_1.000&50.000_99.61.tar")
            # path_T = os.path.join(args.model_path, f"{args.dataset}", args.defense,"Analysis/hp_list_((0.0, 0.0),)_lr_1e-1_SGD/MCNN_0.000&0.000_99.92.tar")
            print("Target Model Loaded from...", path_T)
            ckp_T = torch.load(path_T)
            T.load_state_dict(ckp_T['state_dict'],strict=True)

            E = model.SCNN(10)
            path_E = './eval_model/SCNN_99.42.tar'
            ckp_E = torch.load(path_E)
            E = nn.DataParallel(E).cuda()
            E.load_state_dict(ckp_E['state_dict'])

            aver_acc, aver_acc5, aver_var, aver_var5 = 0, 0, 0, 0
            fid = []
            res_all = []

            K = 5
            for i in range(K):
                if args.verbose:
                    print('-------------------------')
                iden = torch.from_numpy(np.arange(5))
                acc, acc5, var, var5 = dist_inversion(args, G, D, T, E, iden, lr=2e-2, lamda=100, iter_times=args.iter,
                                                      clip_range=1, improved=True, num_seeds=100, verbose=args.verbose)


                # fid_value = calculate_fid_given_paths(args.dataset,
                                                    #   [f'attack_res/{args.dataset}/trainset/',
                                                    #    f'attack_res/{args.dataset}/{args.defense}/all/'],
                                                    #   50, 1, 2048)
                # print(f'FID:{fid_value:.4f}')


                # fid.append(fid_value)
                res_all.append([acc, acc5, var, var5])
                # fid.append(fid_value)

            res = np.array(res_all).mean(0)
            # avg_fid, var_fid = statistics.mean(fid), statistics.stdev(fid)
            print(res_all)
            print(f"Acc:{res[0]:.4f} (+/- {res[2]:.4f}), Acc5:{res[1]:.4f} (+/- {res[3]:.4f})")
            # print(f'FID:{avg_fid:.4f} (+/- {var_fid:.4f})')

