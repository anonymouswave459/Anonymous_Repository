import matplotlib.pyplot as plt

Cutout = [0, 2/3, 3/4]
Acc = [86.90, 84.74, 84.87, 82.28]
attack_acc = [78.47, 45.00, 44.27, 38.93]

plt.scatter(Acc[0], attack_acc[0], label="Ratio=0")
plt.scatter(Acc[1], attack_acc[1], label="Ratio=1/2")
plt.scatter(Acc[2], attack_acc[2], label="Ratio=2/3")
plt.scatter(Acc[3], attack_acc[2], label="Ratio=3/4")
plt.grid()
plt.legend()
plt.xlabel("Main Task Accuracy")
plt.ylabel("KedMI Attack Accuracy")
plt.savefig('ablation.png')

