import os
import shutil


all_folder = 'DMI/attack_res/celeba/HSIC/VGG16_0.000&0.000_80.25_89.76_44.tar/all/'
sucess_folder = 'DMI/attack_res/celeba/HSIC/VGG16_0.000&0.000_80.25_89.76_44.tar/res_success/'
new_all_folder = all_folder[:-5] + '_KedMI/' + 'all/'
os.makedirs(new_all_folder, exist_ok=True)
new_sucess_folder = sucess_folder[:-(len('res_success')+2)] + '_KedMI/' + 'res_success/'

for file_name in os.listdir(all_folder):
    class_name = file_name.split('.')[0].split('_')[-2]
    class_name = str(int(class_name))
    class_dir = os.path.join(new_all_folder, class_name)
    os.makedirs(class_dir, exist_ok=True)
    old_file_path = os.path.join(all_folder, file_name)
    new_file_path = os.path.join(class_dir, file_name)
    shutil.copy(old_file_path, new_file_path)

for file_name in os.listdir(sucess_folder):
    class_name = file_name.split('.')[0].split('_')[-2]
    class_name = str(int(class_name))
    class_dir = os.path.join(new_sucess_folder, class_name)
    os.makedirs(class_dir, exist_ok=True)
    old_file_path = os.path.join(sucess_folder, file_name)
    new_file_path = os.path.join(class_dir, file_name)
    shutil.copy(old_file_path, new_file_path)

