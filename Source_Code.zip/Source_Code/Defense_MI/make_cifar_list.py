import os,sys

dir_path = 'attack_dataset/CIFAR/Img/'
train_file = 'attack_dataset/CIFAR/trainset.txt'
test_file = 'attack_dataset/CIFAR/testset.txt'
gan_file = 'attack_dataset/CIFAR/ganset.txt'

for file_name in os.listdir(dir_path):
    image_id, label = file_name.split('.')[0].split('_')
    if int(image_id)<=50000 and int(label)<=4:
        with open(train_file, "a") as f:
            f.write(file_name+' '+label+'\n')
    elif int(image_id)<=50000 and int(label)>=5:
        with open(gan_file, "a") as f:
            f.write(file_name+'\n')
    elif int(image_id)>50000 and int(label)<=4:
        with open(test_file, "a") as f:
            f.write(file_name+' '+label+'\n')



    


