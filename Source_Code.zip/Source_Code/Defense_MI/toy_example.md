# Experiment 1
## Dataset
### Class 1:
mean_1 = [0, 0]
cov_1 = [[0.125, 0], [0, 0.125/6]]
### Class 2:
mean_2 = [2, 0]
cov_2 = [[0.125, 0], [0, 0.125/6]]
### Gan Dataset
mean_3 = [1, 0]
cov_3 = [[1, 0], [0, 0.125]]

# alpha = 2.0
O class x mean: 0, 0 class x var: 0.125
O class x MI mean: 0.15069858691692353, 0 class x MI var: 0.006110943388193846
O class y mean: 0, 0 class y var: 0.020833333333333332
O class y MI mean: 0.14161403617858886, 0 class y MI var: 0.06264985352754593
1 class x mean: 2, 1 class x var: 0.125
1 class x MI mean: 1.2939867312073707, 1 class x MI var: 0.2788144648075104
1 class y mean: 0, 1 class y var: 0.020833333333333332
1 class y MI mean: 0.0483708500161767, 1 class y MI var: 0.08674854785203934
# alpha=0.0
O class x mean: 0, 0 class x var: 0.125
O class x MI mean: 0.17783694030940533, 0 class x MI var: 0.007821339182555676
O class y mean: 0, 0 class y var: 0.020833333333333332
O class y MI mean: 0.11746101692244411, 0 class y MI var: 0.06805536150932312
1 class x mean: 2, 1 class x var: 0.125
1 class x MI mean: 1.4442121222257613, 1 class x MI var: 0.17374734580516815
1 class y mean: 0, 1 class y var: 0.020833333333333332
1 class y MI mean: 0.04654038026183844, 1 class y MI var: 0.08792226016521454

# Experiment 2
## Dataset
### Class 1:
mean_1 = [0, 0]
cov_1 = [[0.125, 0], [0, 0.125/6]]
### Class 2:
mean_2 = [2, 0.2]
cov_2 = [[0.125, 0], [0, 0.125/6]]
### Gan Dataset
mean_3 = [1, 0.1]
cov_3 = [[1, 0], [0, 0.125]]


