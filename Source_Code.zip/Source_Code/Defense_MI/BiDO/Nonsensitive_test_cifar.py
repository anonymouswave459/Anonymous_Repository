import torch, os, engine, model, utils, sys
import torchvision
from torchvision.utils import save_image
import torchvision.transforms as transform
import model
from tqdm import tqdm
import time
from util import Bar, Logger, AverageMeter, accuracy
from engine import multilayer_hsic_test
import utils_GAN
import matplotlib.pyplot as plt
import numpy as np

class AddGaussianNoise(object):
    def __init__(self, mean=0., std=1., device=None):
        self.std = std
        self.mean = mean
        self.device = device
        
    def __call__(self, tensor):
        return tensor + torch.randn(tensor.size()).to(device) * self.std + self.mean
    
    def __repr__(self):
        return self.__class__.__name__ + '(mean={0}, std={1})'.format(self.mean, self.std)

device = "cuda"
num_classes = 5
# T = model.VGG16(num_classes, False)
T = model.VGG16(num_classes, True)
dataset = 'cifar'
T = model.VGG16(5, hsic_training=True, dataset=dataset)
T = torch.nn.DataParallel(T).cuda()
model_path = 'target_model'
# defense = 'reg'
# defense = 'reg_hsichyperparams'
defense = 'HSIC'
path_T = os.path.join(model_path, dataset, defense, "Analysis_2/hp_list_((0, 0),)_milestones_(60,)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.000_95.59_100.00_49.tar")
# path_T = os.path.join(model_path, dataset, defense, 'Analysis_2/hp_list_((0, 10),)_milestones_(60,)_lr_1e-4_Adam_all_epochs/VGG16_0.000&10.000_93.49_100.00_48.tar')
# path_T = os.path.join(model_path, dataset, defense, 'Analysis_DiffAug_2/hp_list_((0, 10),)_milestones_(60,)_lr_1e-4_Adam_all_epochs/VGG16_0.000&10.000_94.07_100.00_46.tar')


print(path_T)
ckp_T = torch.load(path_T)
T.load_state_dict(ckp_T['state_dict'], strict=True)

# Loading Dataset
loaded_args = utils.load_json(json_file='config/cifar.json')
model_name = loaded_args["dataset"]["model_name"]

train_file = loaded_args['dataset']['train_file']
test_file = loaded_args['dataset']['test_file']

# trainloader = utils.init_dataloader(loaded_args, train_file, mode="train")
testloader = utils.init_dataloader(loaded_args, test_file, mode="test")
# gan_dataset, gan_dataloader = utils_GAN.init_dataloader(loaded_args, "../attack_dataset/CelebA/ganset_dummylabel_1.txt", 64, mode="gan")

pbar = tqdm(enumerate(testloader), total=len(testloader), ncols=150)
# pbar = tqdm(enumerate(trainloader), total=len(trainloader), ncols=150)
criterion = torch.nn.CrossEntropyLoss().cuda()

T.eval()
batch_time = AverageMeter()
data_time = AverageMeter()
losses = AverageMeter()
top1 = AverageMeter()
top5 = AverageMeter()
loss_cls = AverageMeter()
lxz, lyz = AverageMeter(), AverageMeter()
lxy = AverageMeter()
end = time.time()

h = w = 24
# w = 64

with torch.no_grad():
    for batch_idx, (inputs, iden) in pbar:
        data_time.update(time.time() - end)

        inputs, iden = inputs.to(device), iden.to(device)
        bs = inputs.size(0)
        iden = iden.view(-1)
        input_list = []
        for input in inputs:
            # input = torchvision.transforms.functional.erase(input, i=0, j=0, h=h, w=w, v=0)
            # input = torchvision.transforms.functional.erase(input, i=64-h, j=0, h=h, w=w, v=0)
            input = torchvision.transforms.functional.erase(input, i=16-int(h/2), j=16-int(w/2), h=h, w=w, v=0)
            # 32-int(h/2), j=32-int(w/2), h=h, w=w, v=0)
            # input = torchvision.transforms.GaussianBlur(kernel_size=(5, 5), sigma=(1, 1))(input)
            # input = torchvision.transforms.functional.adjust_sharpness(input, 20)
            # input = torchvision.transforms.RandomErasing(p=1.0, scale=(0.25, 0.25), ratio=(1, 1), value=0, inplace=False)(input)
            # input = AddGaussianNoise(0, 0.1, device)(input)
            # input = torchvision.transforms.functional.resized_crop(input, top=32-int(h/2), left=32-int(w/2), height=h,width=w, size=64)
            # input = torchvision.transforms.functional.resized_crop(input, top=0, left=0, height=h,width=w, size=[64, 64])
            input = torch.unsqueeze(input, 0)
            input_list.append(input)
        inputs = torch.cat(input_list, 0)
        
        if batch_idx == 0:
            save_image(inputs, 'train_images.png')
        # print(inputs.shape)
        # exit()

        loss, cross_loss, out_digit, hx_l_list, hy_l_list, hxy_l = multilayer_hsic_test(T, criterion, inputs, iden, 1, 1, num_classes, 'linear', True, 'HSIC')

        # measure accuracy and record loss

        prec1, prec5 = accuracy(out_digit.data, iden.data, topk=(1, 5))
        losses.update(loss.item(), bs)
        loss_cls.update(cross_loss.item(), bs)
        lxz.update(sum(hx_l_list) / len(hx_l_list), bs)
        lyz.update(sum(hy_l_list) / len(hy_l_list), bs)
        lxy.update(hxy_l, bs)

        top1.update(prec1.item(), bs)
        top5.update(prec5.item(), bs)

        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()

        # plot progress
        msg = 'CE:{cls:.4f} | Lxz(down):{lxz:.5f} | Lyz(up):{lyz:.5f} | Lxy(out):{lxy:.5f}| Loss:{loss:.4f} | ' \
                'top1:{top1: .4f} | top5:{top5: .4f}'.format(
            cls=loss_cls.avg,
            lxz=lxz.avg,
            lyz=lyz.avg,
            lxy=lxy.avg,
            loss=losses.avg,
            top1=top1.avg,
            top5=top5.avg,
        )
        pbar.set_description(msg)
    print("MI(x, z)", hx_l_list, lxz.avg)
    print("MI(z, y)", hy_l_list, lyz.avg)
    print("MI(x, y)", lxy.avg)
    print("top 1", top1.avg)
    print("top 5", top5.avg)

