import pandas as pd

dataframe = pd.read_csv('../attack_dataset/CelebA/identity_CelebA.txt', sep=' ', header=None, index_col=0, names=['id', 'label'])
traindf = pd.read_csv('../attack_dataset/CelebA/trainset.txt', sep=' ', header=None, index_col=0, names=['id', 'label'])
testdf = pd.read_csv('../attack_dataset/CelebA/testset.txt', sep=' ', header=None, index_col=0, names=['id', 'label'])
gandf = pd.read_csv('../attack_dataset/CelebA/ganset.txt', sep=' ', header=None, index_col=0, names=['id'])


train_labels = set()
train_index = set()
for index, row in traindf.iterrows():
    train_labels.add(dataframe.loc[index]['label'])
    train_index.add(index)

gan_labels = set()
gan_index = set()
for index, row in gandf.iterrows():
    gan_labels.add(dataframe.loc[index]['label'])
    gan_index.add(index)

test_labels = set()
test_index = set()
for index, row in testdf.iterrows():
    test_labels.add(dataframe.loc[index]['label'])
    test_index.add(index)


# newgandf = pd.DataFrame(columns=['id', 'label'])
# print(newgandf)

# ids = []
# labels = []
# for index, row in dataframe.iterrows():
#     if (index in traindf.index) or (index in testdf.index) or (index in gandf.index):
#         continue
#     label = dataframe.loc[index]['label']
#     if (label in train_labels) or (label in test_labels) or (label in gan_labels):
#         continue
#     ids.append(index)
#     labels.append(label)
#     if len(ids) % 100 == 0:
#         print('Creating:{progress:d}/30000'.format(progress=len(ids))) 
#     if len(ids) >= 30000:
#         break

# new_row = {'id': ids, 'label': labels}
# new_row = pd.DataFrame(new_row)
# newgandf = newgandf.append(new_row)
# newgandf.set_index('id', inplace=True)

newgandf = pd.read_csv('../attack_dataset/CelebA/reference_set.txt', sep=' ', header=None, index_col=0, names=['id'])
refer_labels = set()
refer_index = set()
for index, row in newgandf.iterrows():
    refer_labels.add(dataframe.loc[index]['label'])
    refer_index.add(index)

print("Number of refer labels", len(refer_labels))
print("Number of train labels", len(train_labels))
print("Number of test labels", len(test_labels))
print("Number of gan labels", len(gan_labels))

print("Number of refer images", len(newgandf))
print("Number of train images", len(traindf))
print("Number of test images", len(testdf))
print("Number of gan images", len(gandf))

interset = train_labels.intersection(refer_labels)
print("Train intersection", interset)
interset = test_labels.intersection(refer_labels)
print("Test intersection", interset)
interset = gan_labels.intersection(refer_labels)
print("GAN intersection", interset)


interset = train_index.intersection(refer_index)
print("Index Train intersection", interset)
interset = test_index.intersection(refer_index)
print("Index Test intersection", interset)
interset = gan_index.intersection(refer_index)
print("Index GAN intersection", interset)

newgandf.to_csv('../attack_dataset/CelebA/reference_set.txt', header=False, sep=' ')
