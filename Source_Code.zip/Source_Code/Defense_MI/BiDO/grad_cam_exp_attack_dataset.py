from pytorch_grad_cam import GradCAM, HiResCAM, ScoreCAM, GradCAMPlusPlus, AblationCAM, XGradCAM, EigenCAM, FullGrad
from pytorch_grad_cam.utils.model_targets import ClassifierOutputTarget
from pytorch_grad_cam.utils.image import show_cam_on_image
from torchvision.models import resnet50

import torch, os, engine, model, utils, sys
import model
from tqdm import tqdm
import time
from util import Bar, Logger, AverageMeter, accuracy
from engine import multilayer_hsic_test
import utils_GAN
import matplotlib.pyplot as plt
import numpy as np
import cv2
from torch import nn
import torchvision
from torchvision import datasets
from PIL import Image
import torchvision.transforms.functional as TF
from torchvision import transforms

class ImageFolderWithPaths(datasets.ImageFolder):

    def __getitem__(self, index):
  
        img, label = super(ImageFolderWithPaths, self).__getitem__(index)
        
        path = self.imgs[index][0]
        
        return (img, label ,path)

# Target Model Loading
device = "cuda"
num_classes = 1000
# T = model.VGG16_nohidden(num_classes, True)
T = model.VGG16(1000)
T = torch.nn.DataParallel(T).cuda()
# dataset = 'celeba'
# model_path = 'target_model'
# defense = 'HSIC'
# name_T = os.path.join("Analysis/hp_list_((0.0, 0.0),)_lr_1e-2_SGD/VGG16_0.000&0.000_86.90.tar")
# name_T = "Analysis/hp_list_((0.0, 0.0),)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.000_85.01_91.79_30.tar"
# name_T = "Analysis_1/hp_list_((0.05, 0.5),)_lr_1e-4_Adam_all_epochs/VGG16_0.050&0.500_79.85_90.33_47.tar"
# name_T = "Analysis_(2,)/hp_list_((0.05, 0.5),)_lr_1e-4_Adam_all_epochs/VGG16_0.050&0.500_79.79_89.33_47.tar"
# name_T = "Analysis_DiffAug/hp_list_((0, 0.1),)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.100_80.75_89.76_44.tar"
# name_T = "Analysis_1/hp_list_((0, 0.22),)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.220_80.55_89.20_41.tar"
path_T = '/home/hung/PLG_MI/baselines/checkpoints/VGG16_88.26.tar'
ckp_T = torch.load(path_T)
T.load_state_dict(ckp_T['state_dict'], strict=True)
T = T.module
T = T.to(device)
T.eval()
print(T.feature[-2])
# exit()
# target_layers = [T.layer5[-2]]
target_layers = [T.feature[-2]]



# name_T = "Analysis_1/hp_list_((0.05, 0.5),)_lr_1e-4_Adam_all_epochs/VGG16_0.050&0.500_79.85_90.33_47.tar"
# name_T = "Analysis_DiffAug/hp_list_((0, 0.1),)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.100_80.75_89.76_44.tar"

# all_img_dir = os.path.join(save_img_dir, 'Each_Class_Attack', 'Aug_all_class_53')
all_img_dir = '/home/hung/PLG_MI/PLG_MI_Inversion_NoDef/all_imgs'
success_img_dir = '/home/hung/PLG_MI/PLG_MI_Inversion_NoDef/success_imgs'
transform = torchvision.transforms.Compose([torchvision.transforms.ToTensor()])
dataset = ImageFolderWithPaths(all_img_dir, transform=transform)
sucess_dataset = ImageFolderWithPaths(success_img_dir, transform=transform)
sucess_names = set()
all_img_dir_gradcam = 'GRADCAM_Nodef'
success_img_dir_gradcam = 'GRADCAM_success_Nodef'
os.makedirs(all_img_dir_gradcam, exist_ok=True)
os.makedirs(success_img_dir_gradcam, exist_ok=True)
for i in range(len(sucess_dataset)):
    image, target, image_path = sucess_dataset[i]
    image_name = image_path.split('/')[-1].split('.')[0]
    sucess_names.add(image_name)

refer_image = Image.open('refer_image/000001.jpg')
proc = []
crop_size = 108
offset_height = (218 - crop_size) // 2
offset_width = (178 - crop_size) // 2
crop = lambda x: x[:, offset_height:offset_height + crop_size, offset_width:offset_width + crop_size]
re_size = 64
proc.append(transforms.ToTensor())
proc.append(transforms.Lambda(crop))
proc.append(transforms.ToPILImage())
proc.append(transforms.Resize((re_size, re_size)))
proc.append(transforms.ToTensor())
Augment = transforms.Compose(proc)
refer_image = Augment(refer_image)
refer_image.unsqueeze_(0)

# dataloader = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=False)
def grad_cam(dataset, model, save_dir, except_names = ()):
    print("Do grad cam on ...", save_dir)
    individual_save_dir = os.path.join(save_dir, "IndividualExample")
    os.makedirs(individual_save_dir, exist_ok=True)
    average_grayscale_cam = np.zeros((64,64))
    count = 0
    for i in range(len(dataset)):
        if i % 100 == 0:
            print("Loading " + str(i)) 
        image, target, image_path = dataset[i]
        target = image_path.split('/')[-1].split('.')[0].split('_')[-2]
        image_name = image_path.split('/')[-1].split('.')[0]
        if image_name in except_names:
            continue
        grad_cam_image_name = image_name + 'gradcam.png'
        target = int(target)

        input_tensor = torch.unsqueeze(image, 0)
        input_tensor = input_tensor.to(device)
        # input_tensor = torchvision.transforms.RandomErasing(p=1.0, scale=(0.1, 0.1), ratio=(1, 3), value=0, inplace=False)(input_tensor)
        try:
            output = T(input_tensor)
        except:
            output = T(input_tensor)
            print("$$$$$$$$$$$Run Again$$$$$$$$$$$$$$$")
        # Note: input_tensor can be a batch tensor with several images!

        # Construct the CAM object once, and then re-use it on many images:
        cam = GradCAM(model=T, target_layers=target_layers, use_cuda=True)

        # You can also use it within a with statement, to make sure it is freed,
        # In case you need to re-create it inside an outer loop:
        # with GradCAM(model=model, target_layers=target_layers, use_cuda=args.use_cuda) as cam:
        #   ...

        # We have to specify the target we want to generate
        # the Class Activation Maps for.
        # If targets is None, the highest scoring category
        # will be used for every image in the batch.
        # Here we use ClassifierOutputTarget, but you can define your own custom targets
        # That are, for example, combinations of categories, or specific outputs in a non standard model.
        targets = [ClassifierOutputTarget(target)]

        # You can also pass aug_smooth=True and eigen_smooth=True, to apply smoothing.
        grayscale_cam = cam(input_tensor=input_tensor, targets=targets)

        # In this example grayscale_cam has only one image in the batch:
        grayscale_cam = grayscale_cam[0, :]
        average_grayscale_cam += grayscale_cam
        input_tensor = torch.squeeze(input_tensor, 0)
        rgb_img = torchvision.transforms.ToPILImage()(input_tensor)
        rgb_img = np.array(rgb_img)/255

        visualization = show_cam_on_image(rgb_img, grayscale_cam, use_rgb=True)
        # print(visualization, rgb_img, grayscale_cam)
        # exit()
        im = Image.fromarray(visualization)
        # im.save(os.path.join(visual_dir, "no_defend.jpeg"))
        if count < 10000:
            # print("Save Image", i, count, grad_cam_image_name)
            os. makedirs(os.path.join(individual_save_dir, 'class_'+str(target)), exist_ok=True)
            im.save(os.path.join(individual_save_dir, 'class_'+str(target), grad_cam_image_name))
            count+=1
    average_grayscale_cam = average_grayscale_cam/len(dataset)
    print(average_grayscale_cam)
    input_tensor_1 = torch.squeeze(refer_image, 0)
    rgb_img = torchvision.transforms.ToPILImage()(input_tensor_1)
    rgb_img = np.array(rgb_img)/255
    visualization = show_cam_on_image(rgb_img, average_grayscale_cam, use_rgb=True)
    im = Image.fromarray(visualization)
    print("Saving ...", save_dir)
    im.save(os.path.join(save_dir, "00000_AverageGradCAM.jpeg"))
    torch.set_printoptions(threshold=10_000)
    np.set_printoptions(threshold=sys.maxsize)
    print(np.mean(average_grayscale_cam, axis=1))

grad_cam(dataset=dataset, model=T, save_dir=all_img_dir_gradcam, except_names=sucess_names)
grad_cam(dataset=sucess_dataset, model=T, save_dir=success_img_dir_gradcam)
