import torch, os, engine, model, utils, sys
import model
from tqdm import tqdm
import time
from util import Bar, Logger, AverageMeter, accuracy
from engine import multilayer_hsic_test
import utils_GAN
import matplotlib.pyplot as plt
import numpy as np
from DiffAugment_pytorch import DiffAugment
from torchvision.utils import save_image
from torchvision import transforms

device = "cuda"
num_classes = 1000
T = model.VGG16(num_classes, True)
T = torch.nn.DataParallel(T).cuda()
dataset = 'celeba'
model_path = 'target_model'
# defense = 'reg'
# defense = 'reg_hsichyperparams'
defense = 'HSIC'
# path_T = os.path.join(model_path, dataset, defense, 'Analysis_DiffAug_cutout_0.75/hp_list_((0, 0),)_milestones_(40,)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.000_82.28_91.39_46.tar')
path_T = 'target_model/NoDef_VGG16_0.000&0.000_86.90.tar'
print(path_T)
ckp_T = torch.load(path_T)
T.load_state_dict(ckp_T['state_dict'], strict=True)

# Loading Dataset
loaded_args = utils.load_json(json_file='config/celeba.json')
model_name = loaded_args["dataset"]["model_name"]

test_file = loaded_args['dataset']['test_file']

loaded_args[model_name]['batch_size'] = 16
testloader = utils.init_dataloader(loaded_args, test_file, mode="test")
# gan_dataset, gan_dataloader = utils_GAN.init_dataloader(loaded_args, "../attack_dataset/CelebA/ganset_dummylabel_1.txt", 64, mode="gan")


# Evaluate
# pbar = tqdm(enumerate(gan_dataloader), total=len(gan_dataloader), ncols=150)
pbar = tqdm(enumerate(testloader), total=len(testloader), ncols=150)
# pbar = tqdm(enumerate(testloader), total=len(testloader), ncols=150)
criterion = torch.nn.CrossEntropyLoss().cuda()

# test_loss, test_acc = engine.test_HSIC(T, criterion, testloader, 1, 1, num_classes, ktype='linear', hsic_training=True)

T.eval()
batch_time = AverageMeter()
data_time = AverageMeter()
losses = AverageMeter()
top1 = AverageMeter()
top5 = AverageMeter()
loss_cls = AverageMeter()
lxz, lyz = AverageMeter(), AverageMeter()
lxy = AverageMeter()
end = time.time()

# with torch.no_grad():
#     softmax_test = []
#     for batch_idx, (inputs, iden) in pbar:
#         if batch_idx >= 100:
#             break
#         inputs, iden = next(iter(gan_dataloader))
#         hiddens, out_digit = T(inputs)
#         out_softmax = torch.nn.Softmax(dim=1)(out_digit)
#         out_softmax = out_softmax.cpu().detach().numpy()
#         plt.hist(out_softmax)
#         plt.savefig("1.png")
#         high_num = (out_softmax>0.01).sum()
#         softmax_test.append(high_num)
#         # plot progress
#         msg = 'Check:{high_num:.4f}'.format(
#             high_num=high_num
#         )
#         pbar.set_description(msg)
# print(softmax_test)
# exit()
outputs = []
with torch.no_grad():
    for batch_idx, (inputs, iden) in pbar:
        data_time.update(time.time() - end)

        inputs, iden = inputs.to(device), iden.to(device)
        bs = inputs.size(0)
        iden = iden.view(-1)
        img = DiffAugment(inputs / 2 + .5, 'cutout11.5').clamp(0, 1) * 2 - 1
        # input_list = []
        # for input in inputs:
        #     input = transforms.RandomErasing(p=1.0, scale=(0.2, 0.80), ratio=(1, 2), value=0, inplace=False)(input)
        #     input = torch.unsqueeze(input, 0)
        #     input_list.append(input)
        # img = torch.cat(input_list, 0)
        # img = inputs
        if batch_idx == 0:
            save_image(img, 'img_cutout.png')
        hiddens, out_digit = T(img)
        out_digit = torch.nn.Softmax(dim=1)(out_digit)
        for i, id in enumerate(iden):
            outputs.append(out_digit[i][id].item())

        loss, cross_loss, out_digit, hx_l_list, hy_l_list, hxy_l = multilayer_hsic_test(T, criterion, inputs, iden, 1, 1,
                                                                            num_classes, 'linear', True, 'HSIC')

        # measure accuracy and record loss

        prec1, prec5 = accuracy(out_digit.data, iden.data, topk=(1, 5))
        losses.update(loss.item(), bs)
        loss_cls.update(cross_loss.item(), bs)
        lxz.update(sum(hx_l_list) / len(hx_l_list), bs)
        lyz.update(sum(hy_l_list) / len(hy_l_list), bs)
        lxy.update(hxy_l, bs)

        top1.update(prec1.item(), bs)
        top5.update(prec5.item(), bs)

        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()

        # plot progress
        msg = 'CE:{cls:.4f} | Lxz(down):{lxz:.5f} | Lyz(up):{lyz:.5f} | Lxy(out):{lxy:.5f}| Loss:{loss:.4f} | ' \
                'top1:{top1: .4f} | top5:{top5: .4f}'.format(
            cls=loss_cls.avg,
            lxz=lxz.avg,
            lyz=lyz.avg,
            lxy=lxy.avg,
            loss=losses.avg,
            top1=top1.avg,
            top5=top5.avg,
        )
        pbar.set_description(msg)
    print("MI(x, z)", hx_l_list, lxz.avg)
    print("MI(z, y)", hy_l_list, lyz.avg)
    print("MI(x, y)", lxy.avg)
    print("top 1", top1.avg)
    print("top 5", top5.avg)

outputs = np.array(outputs)
np.save("NoDef.npy", outputs)
# np.save("DTMD.npy", outputs)



