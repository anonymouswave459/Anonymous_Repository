import torch, os, engine, model, utils, sys
import torchvision
from torchvision.utils import save_image
import torchvision.transforms as transform
from torchvision import datasets
import model
from tqdm import tqdm
import time
from util import Bar, Logger, AverageMeter, accuracy
from engine import multilayer_hsic_test
import utils_GAN
import matplotlib.pyplot as plt
import numpy as np
import hsic

device = "cuda"
num_classes = 1000
# T = model.VGG16(num_classes, False)
classifier_1 = model.VGG16(num_classes, True)
classifier_1 = torch.nn.DataParallel(classifier_1).cuda()
dataset = 'celeba'
model_path = 'target_model'
defense = 'HSIC'
path_T = os.path.join(model_path, dataset, defense, "Analysis/hp_list_((0.0, 0.0),)_lr_1e-2_SGD/VGG16_0.000&0.000_86.90.tar")
# path_T = os.path.join(model_path, dataset, defense, "Analysis/hp_list_((0.05, 0.5),)_lr_1e-4_Adam/VGG16_0.050&0.500_79.29.tar")
# path_T = os.path.join(model_path, dataset, defense, "Analysis_ReferenceDataset/hp_list_((0.0, 0.012),)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.012_80.88_90.09_42.tar")
print(path_T)
ckp_T = torch.load(path_T)
classifier_1.load_state_dict(ckp_T['state_dict'], strict=True)

# Load Dataset
loaded_args = utils.load_json(json_file='config/celeba.json')
model_name = loaded_args["dataset"]["model_name"]
train_file = loaded_args['dataset']['train_file']
test_file = loaded_args['dataset']['test_file']
testloader = utils.init_dataloader(loaded_args, test_file, mode="test")
pbar = tqdm(enumerate(testloader), total=len(testloader), ncols=150)

classifier_1.eval()
batch_time = AverageMeter()
data_time = AverageMeter()
losses = AverageMeter()
top1 = AverageMeter()
top5 = AverageMeter()
loss_cls = AverageMeter()
lxz, lyz = AverageMeter(), AverageMeter()
lxy = AverageMeter()
end = time.time()
criterion = torch.nn.CrossEntropyLoss().cuda()

last_hidden = []

with torch.no_grad():
    for batch_idx, (inputs, iden) in pbar:
        data_time.update(time.time() - end)

        inputs, iden = inputs.to(device), iden.to(device)
        bs = inputs.size(0)
        iden = iden.view(-1)
        hiddens, _ = classifier_1(inputs)
        last_hidden.append(hiddens[-1].view(bs, -1))
        hidden_4 = hiddens[4]
        print(hidden_4)
        exit()
        # h_target = utils.to_categorical(iden, num_classes=num_classes).float()
        # hsic_hy_val = hsic.hsic_normalized_cca(hidden_4[:, 1000:1001], h_target, sigma=5., ktype='linear')
        # print(hsic_hy_val, hidden_4[:, :].shape)
        # exit()


        loss, cross_loss, out_digit, hx_l_list, hy_l_list, hxy_l = multilayer_hsic_test(classifier_1, criterion, inputs, iden, 1, 1, num_classes, 'linear', True, 'HSIC')

        # measure accuracy and record loss

        prec1, prec5 = accuracy(out_digit.data, iden.data, topk=(1, 5))
        losses.update(loss.item(), bs)
        loss_cls.update(cross_loss.item(), bs)
        lxz.update(sum(hx_l_list) / len(hx_l_list), bs)
        lyz.update(sum(hy_l_list) / len(hy_l_list), bs)
        lxy.update(hxy_l, bs)

        top1.update(prec1.item(), bs)
        top5.update(prec5.item(), bs)

        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()

        # plot progress
        msg = 'CE:{cls:.4f} | Lxz(down):{lxz:.5f} | Lyz(up):{lyz:.5f} | Lxy(out):{lxy:.5f}| Loss:{loss:.4f} | ' \
                'top1:{top1: .4f} | top5:{top5: .4f}'.format(
            cls=loss_cls.avg,
            lxz=lxz.avg,
            lyz=lyz.avg,
            lxy=lxy.avg,
            loss=losses.avg,
            top1=top1.avg,
            top5=top5.avg,
        )
        pbar.set_description(msg)
    print("MI(x, z)", hx_l_list, lxz.avg)
    print("MI(z, y)", hy_l_list, lyz.avg)
    print("MI(x, y", lxy.avg)
    print("top 1", top1.avg)
    print("top 5", top5.avg)

# last_hidden = torch.cat(last_hidden, 0)
# last_hidden = last_hidden.T
# print(last_hidden.shape)
# exit()
# last_hidden_var = torch.var(last_hidden, dim=1, keepdim=True)
# last_hidden_cov = torch.cov(last_hidden)
# u, s, v = torch.svd(last_hidden_cov)
# print(s.shape)
# print(torch.count_nonzero(s))
# print(s)
# exit()
# print(last_hidden_var)


