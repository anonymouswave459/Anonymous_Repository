from pytorch_grad_cam import GradCAM, HiResCAM, ScoreCAM, GradCAMPlusPlus, AblationCAM, XGradCAM, EigenCAM, FullGrad
from pytorch_grad_cam.utils.model_targets import ClassifierOutputTarget
from pytorch_grad_cam.utils.image import show_cam_on_image
from torchvision.models import resnet50

import torch, os, engine, model, utils, sys
import model
from tqdm import tqdm
import time
from util import Bar, Logger, AverageMeter, accuracy
from engine import multilayer_hsic_test
import utils_GAN
import matplotlib.pyplot as plt
import numpy as np
import cv2
from torch import nn
import torchvision
from torchvision import datasets
from PIL import Image

os.environ["CUDA_VISIBLE_DEVICES"]="0"
# Target Model Loading
device = "cuda"
n_classes = 5
T = model.MCNN_nohiddens(n_classes)
T = torch.nn.DataParallel(T).cuda()
dataset = 'mnist'
model_path = 'target_model'
defense = 'HSIC'
# path_T = os.path.join(model_path, dataset, defense, "Analysis_1/hp_list_((0, 0),)_milestones_(20, 35)_lr_1e-4_Adam_all_epochs/MCNN_0.000&0.000_99.86_100.00_17.tar")
# path_T = os.path.join(model_path, dataset, defense, "Analysis_1/hp_list_((2, 20),)_milestones_(20, 35)_lr_1e-4_Adam_all_epochs/MCNN_2.000&20.000_99.63_100.00_14.tar")
# path_T = os.path.join(model_path, dataset, defense, "Analysis_1/hp_list_((0, 30),)_milestones_(20, 35)_lr_1e-4_Adam_all_epochs/MCNN_0.000&30.000_99.73_100.00_11.tar")
path_T = os.path.join(model_path, dataset, defense, "Analysis_1/hp_list_((0, 1000),)_milestones_(20, 35)_lr_1e-4_Adam_all_epochs/MCNN_0.000&1000.000_99.38_100.00_18.tar")
print(path_T)
ckp_T = torch.load(path_T)
T.load_state_dict(ckp_T['state_dict'], strict=True)
T = T.module
T = T.to(device)
T.eval()
# target_layers = [T.layer1[-1], T.layer2[-1], T.layer3[-1]]
target_layers = [T.layer2[-1]]


# Loading Dataset
loaded_args = utils.load_json(json_file='config/mnist.json')
test_file = loaded_args['dataset']['test_file']
testloader = utils.init_dataloader(loaded_args, test_file, mode="test")
dataset = testloader.dataset
model_name = "MCNN"
dataset_name = "mnist"
save_img_dir = "../GRAD_CAM/attack_res/"
model_name = path_T.split('/')[-3] + "_" + path_T.split('/')[-2] + "_" + model_name
save_img_dir = os.path.join(save_img_dir, dataset_name, defense, model_name)
all_img_dir = os.path.join(save_img_dir, 'all')
all_img_dir_gradcam = os.path.join(save_img_dir, 'test_gradcam')
os.makedirs(all_img_dir_gradcam, exist_ok=True)


# dataloader = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=False)
def grad_cam(dataset, model, save_dir, except_names = ()):
    print("Do grad cam on ...", save_dir)
    individual_save_dir = os.path.join(save_dir, "IndividualExample")
    os.makedirs(individual_save_dir, exist_ok=True)
    average_grayscale_cam = np.zeros((32,32))
    for i in range(len(dataset)):
        if i % 100 == 0:
            print("Loading " + str(i)) 
        image, target = dataset[i]
        image_name = str(i) + '_' + str(target)
        if image_name in except_names:
            continue
        grad_cam_image_name = image_name + '_gradcam.png'

        input_tensor = torch.unsqueeze(image, 0)
        input_tensor = input_tensor.to(device)
        output = T(input_tensor)
        if output.max(-1)[1] != target: # Only correct predicted images
            continue
        # Note: input_tensor can be a batch tensor with several images!

        # Construct the CAM object once, and then re-use it on many images:
        cam = GradCAM(model=T, target_layers=target_layers, use_cuda=True)

        # You can also use it within a with statement, to make sure it is freed,
        # In case you need to re-create it inside an outer loop:
        # with GradCAM(model=model, target_layers=target_layers, use_cuda=args.use_cuda) as cam:
        #   ...

        # We have to specify the target we want to generate
        # the Class Activation Maps for.
        # If targets is None, the highest scoring category
        # will be used for every image in the batch.
        # Here we use ClassifierOutputTarget, but you can define your own custom targets
        # That are, for example, combinations of categories, or specific outputs in a non standard model.
        targets = [ClassifierOutputTarget(target)]

        # You can also pass aug_smooth=True and eigen_smooth=True, to apply smoothing.
        grayscale_cam = cam(input_tensor=input_tensor, targets=targets)

        # In this example grayscale_cam has only one image in the batch:
        grayscale_cam = grayscale_cam[0, :]
        # print(grayscale_cam)
        # exit()
        average_grayscale_cam += grayscale_cam
        input_tensor = torch.squeeze(input_tensor, 0)
        rgb_img = torchvision.transforms.ToPILImage()(input_tensor)
        rgb_img = rgb_img.convert('RGB')
        rgb_img = np.array(rgb_img)/255
        # print(rgb_img.shape)
        # exit()

        visualization = show_cam_on_image(rgb_img, grayscale_cam, use_rgb=True)
        im = Image.fromarray(visualization)
        # im.save(os.path.join(visual_dir, "no_defend.jpeg"))
        if i < 300:
            os. makedirs(os.path.join(individual_save_dir, 'class_'+str(target)), exist_ok=True)
            im.save(os.path.join(individual_save_dir, 'class_'+str(target), grad_cam_image_name))
    average_grayscale_cam = average_grayscale_cam/len(dataset)
    print(average_grayscale_cam)
    visualization = show_cam_on_image(rgb_img, average_grayscale_cam, use_rgb=True)
    im = Image.fromarray(visualization)
    print("Saving ...", save_dir)
    im.save(os.path.join(save_dir, "00000_AverageGradCAM.jpeg"))


grad_cam(dataset=dataset, model=T, save_dir=all_img_dir_gradcam, except_names=())
