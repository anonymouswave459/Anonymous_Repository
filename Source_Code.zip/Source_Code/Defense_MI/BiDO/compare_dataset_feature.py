import torch, os, engine, model, utils, sys
import torchvision
from torchvision.utils import save_image
import torchvision.transforms as transform
from torchvision import datasets
import model
from tqdm import tqdm
import time
from util import Bar, Logger, AverageMeter, accuracy
from engine import multilayer_hsic_test
import utils_GAN
import matplotlib.pyplot as plt
import numpy as np
from torch_cka import CKA


class ImageFolderWithPaths(datasets.ImageFolder):

    def __getitem__(self, index):
  
        img, label = super(ImageFolderWithPaths, self).__getitem__(index)
        
        path = self.imgs[index][0]
        
        return (img, label ,path)

# Load Model ##########################################################################
device = "cuda"
num_classes = 1000
# T = model.VGG16(num_classes, False)
classifier_1 = model.VGG16_nohidden(num_classes, True)
classifier_1 = torch.nn.DataParallel(classifier_1).cuda()
dataset = 'celeba'
model_path = 'target_model'
defense = 'HSIC'
path_T = os.path.join(model_path, dataset, defense, "Analysis/hp_list_((0.0, 0.0),)_lr_1e-2_SGD/VGG16_0.000&0.000_86.90.tar")
# path_T = os.path.join(model_path, dataset, defense, "Analysis/hp_list_((0.05, 0.5),)_lr_1e-4_Adam/VGG16_0.050&0.500_79.29.tar")
# path_T = os.path.join(model_path, dataset, defense, "Analysis_ReferenceDataset/hp_list_((0.0, 0.012),)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.012_80.88_90.09_42.tar")
print(path_T)
ckp_T = torch.load(path_T)
classifier_1.load_state_dict(ckp_T['state_dict'], strict=True)

device = "cuda"
num_classes = 1000
# T = model.VGG16(num_classes, False)
classifier_2 = model.VGG16_nohidden(num_classes, True)
classifier_2 = torch.nn.DataParallel(classifier_2).cuda()
dataset = 'celeba'
model_path = 'target_model'
defense = 'HSIC'
# path_T = os.path.join(model_path, dataset, defense, "Analysis/hp_list_((0.05, 0.5),)_lr_1e-4_Adam/VGG16_0.050&0.500_79.29.tar")
path_T = os.path.join(model_path, dataset, defense, "Analysis_ReferenceDataset_OnehotDepend/hp_list_((0.0, 0.02),)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.020_80.29_90.26_49.tar")
ckp_T = torch.load(path_T)
classifier_2.load_state_dict(ckp_T['state_dict'], strict=True)


# Load Dataset
loaded_args = utils.load_json(json_file='config/celeba.json')
model_name = loaded_args["dataset"]["model_name"]
train_file = loaded_args['dataset']['train_file']
test_file = loaded_args['dataset']['test_file']
# trainloader = utils.init_dataloader(loaded_args, train_file, mode="train")
testloader = utils.init_dataloader(loaded_args, test_file, mode="test")
# gan_dataset, gan_dataloader = utils_GAN.init_dataloader(loaded_args, "../attack_dataset/CelebA/ganset_dummylabel_1.txt", 64, mode="gan")


# Load attacked dataset
# path_T = os.path.join(model_path, dataset, defense, "Analysis/hp_list_((0.0, 0.0),)_lr_1e-2_SGD/VGG16_0.000&0.000_86.90.tar")
# model_name = "VGG16"
# dataset_name = "celeba"
# save_img_dir = "../GMI/attack_res/"
# model_name = path_T.split('/')[-3] + "_" + path_T.split('/')[-2] + "_" + model_name
# save_img_dir = os.path.join(save_img_dir, dataset_name, defense, model_name)
# all_img_dir = os.path.join(save_img_dir, 'all')
# transform = torchvision.transforms.Compose([torchvision.transforms.ToTensor()])
# attack_dataset = ImageFolderWithPaths(all_img_dir, transform=transform)
# attack_dataloder = torch.utils.data.DataLoader(attack_dataset, batch_size=64,num_workers=8, pin_memory=True, drop_last=True)

# cka = CKA(model1, model2,
#         model1_name="ResNet18", model2_name="ResNet34",
#         device='cuda')
#
# cka.compare(dataloader)
#
# cka.plot_results(save_path="../assets/resnet_compare.png")


#===============================================================


cka = CKA(classifier_1, classifier_2,
        model1_name="VGG16_NoDefend", model2_name="VGG16_Defend_BiDO_refonehot_0.02",
        device='cuda')

cka.compare(testloader)

# cka.plot_results(save_path="./assets/VGG16NoDefend-VGG16NoDefend_compare.png")
cka.plot_results(save_path="./assets/VGG16_NoDefend-VGG16_Defend_BiDO_refonehot_0.02_compare.png")


