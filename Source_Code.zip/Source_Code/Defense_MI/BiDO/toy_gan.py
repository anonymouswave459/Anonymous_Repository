# Drawn from https://gist.github.com/rocknrollnerd/06bfed6b9d1bce612fd6 (in theano)
# This is implemented in PyTorch
# Author : Anirudh Vemula
import numpy as np
import torch
import torch.nn as nn
from torch.autograd import Variable
from scipy.stats import norm
import matplotlib.pyplot as plt
import hsic
import utils
from torchvision import datasets
from torch.utils.data import DataLoader
import sys
import os

seed = 1
torch.manual_seed(seed)
np.random.seed(seed)

# Classifier
class Net(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(2, 2)
        self.fc2 = nn.Linear(2, 2)
        self.fc3 = nn.Linear(2, 2)


    def forward(self, x):
        feat_1 = self.fc1(x)
        feat_2 = self.fc2(feat_1)
        out = self.fc3(feat_2)
        return [feat_1, feat_2], out

def make_dataset_cls(mean_1, cov_1, mean_2, cov_2, num_sample):
    data_1 = np.random.multivariate_normal(mean_1, cov_1, num_sample)
    tensor_1 = torch.from_numpy(data_1).float()
    label_1 = torch.from_numpy(np.array([0]*num_sample)).long()

    data_2 = np.random.multivariate_normal(mean_2, cov_2, num_sample)
    tensor_2 = torch.from_numpy(data_2).float()
    label_2 = torch.from_numpy(np.array([1]*num_sample)).long()

    tensor = torch.cat((tensor_1, tensor_2), 0)
    label = torch.cat((label_1, label_2), 0)

    return data_1, data_2, tensor, label

# GAN training ##############
def make_dataset_1(mean_1, cov_1, mean_2, cov_2, num_sample):
    data_1 = np.random.multivariate_normal(mean_1, cov_1, num_sample)
    tensor_1 = torch.from_numpy(data_1).float()
    label_1 = torch.from_numpy(np.array([0]*num_sample)).long()

    data_2 = np.random.multivariate_normal(mean_2, cov_2, num_sample)
    tensor_2 = torch.from_numpy(data_2).float()
    label_2 = torch.from_numpy(np.array([1]*num_sample)).long()

    tensor = torch.cat((tensor_1, tensor_2), 0)
    label = torch.cat((label_1, label_2), 0)

    return data_1, data_2, tensor, label

def make_dataset(mean, cov, num_sample):
    data = np.random.multivariate_normal(mean, cov, num_sample)
    tensor = torch.from_numpy(data).float()
    return tensor


def plot_decision_boundary(discriminate):
    xs = np.linspace(-5, 5, 1000)
    plt.plot(xs, norm.pdf(xs, loc=mu, scale=sigma), label='p_data')

    r = 1000
    xs = np.float32(np.linspace(-5, 5, r))
    xs_tensor = Variable(torch.from_numpy(xs.reshape(r, 1)))
    ds_tensor = discriminate(xs_tensor)
    ds = ds_tensor.data.numpy()
    plt.plot(xs, ds, label='decision boundary')
    plt.show()


def plot_fig(generate, discriminate):
    xs = np.linspace(-5, 5, 1000)
    plt.plot(xs, norm.pdf(xs, loc=mu, scale=sigma), label='p_data')

    r = 5000
    xs = np.float32(np.linspace(-5, 5, r))
    xs_tensor = Variable(torch.from_numpy(xs.reshape(r, 1)))
    ds_tensor = discriminate(xs_tensor)
    ds = ds_tensor.data.numpy()
    plt.plot(xs, ds, label='decision boundary')

    zs = sample_noise(r)
    zs_tensor = Variable(torch.from_numpy(np.float32(zs.reshape(r, 1))))
    gs_tensor = generate(zs_tensor)
    gs = gs_tensor.data.numpy()
    plt.hist(gs, bins=10, normed=True)


# Generator
class Generator(nn.Module):
    def __init__(self):
        super(Generator, self).__init__()
        self.l1 = nn.Linear(8, 10)
        self.l1_relu = nn.ReLU()
        self.l2 = nn.Linear(10, 10)
        self.l2_relu = nn.ReLU()
        self.l3 = nn.Linear(10, 2)

    def forward(self, input):
        output = self.l1(input)
        output = self.l1_relu(output)
        output = self.l2(output)
        output = self.l2_relu(output)
        output = self.l3(output)
        return output


# Discriminator
class Discriminator(nn.Module):
    def __init__(self):
        super(Discriminator, self).__init__()
        self.l1 = nn.Linear(2, 10)
        self.l1_tanh = nn.Tanh()
        self.l2 = nn.Linear(10, 10)
        self.l2_tanh = nn.Tanh()
        self.l3 = nn.Linear(10, 2)
        self.l3_sigmoid = nn.Sigmoid()

    def forward(self, input):
        output = self.l1_tanh(self.l1(input))
        output = self.l2_tanh(self.l2(output))
        output = self.l3_sigmoid(self.l3(output))
        return output


def generator_criterion(d_output_g):
    return -0.5 * torch.mean(torch.log(d_output_g))


def discriminator_criterion(d_output_true, d_output_g):
    return -0.5 * torch.mean(torch.log(d_output_true) + torch.log(1 - d_output_g))

#################################################### make classifier ##############################################################################
net = Net()
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.SGD(net.parameters(), 0.01)

############################ Define Distribution #############################
mean_1 = [0, 0]
cov_1 = [[0.125, 0], [0, 0.125]]
mean_2 = [2, 0.2]
cov_2 = [[0.125, 0], [0, 0.125]]
mean_3 = [1, 0]
cov_3 = [[5.0, 0], [0, 1.0]]

# make dataset
iters = 100
batch_size = 256
train_tensors = []
train_labels = []
for i in range(int(iters)):
    data_1, data_2, train_tensor, train_label = make_dataset_cls(mean_1, cov_1, mean_2, cov_2, int(batch_size/2))
    train_tensors.append(train_tensor)
    train_labels.append(train_label)
train_tensors = torch.cat(train_tensors, dim=0)
train_labels = torch.cat(train_labels, dim=0)

test_data_1, test_data_2, test_tensor, test_label = make_dataset_cls(mean_1, cov_1, mean_2, cov_2, batch_size*iters)

# training classifier
epochs = 1
alpha = 3.0
root_dir = "visual_alpha_"+str(alpha)
os.makedirs(root_dir, exist_ok=True)
for epoch in range(epochs):
    for i in range(iters):
        # data_1, data_2, train_tensor, train_label = make_dataset_cls(mean_1, cov_1, mean_2, cov_2, batch_size)
        train_inputs = train_tensors[batch_size*i:batch_size*(i+1)]
        train_idens = train_labels[batch_size*i:batch_size*(i+1)]
        hiddens, output = net(train_inputs)
        loss = criterion(output, train_idens)
        loss_hsic = 0
        h_target = utils.to_categorical(train_idens, num_classes=2).float()
        h_data = train_inputs.view(batch_size, -1)
        for hidden in hiddens:
            hidden = hidden.view(batch_size, -1)
            hxz_l, hyz_l = hsic.hsic_objective(
                    hidden,
                    h_target=h_target.float(),
                    h_data=h_data,
                    sigma=5.,
                    ktype='linear'
                )
            loss_hsic += hyz_l
        loss = loss - alpha*loss_hsic
        loss.backward()
        optimizer.step()
        acc = (output.max(-1)[1] == train_idens).float().mean().item()

    print('Training ...', epoch, loss, loss_hsic, acc)

_, test_output = net(test_tensor)
test_acc = (test_output.max(-1)[1] == test_label).float().mean().item()
print("Testing ...", test_acc)
test_data_1, test_data_2, test_tensor, test_label = make_dataset_cls(mean_1, cov_1, mean_2, cov_2, batch_size)
hiddens, test_output = net(test_tensor)
loss_hsic = 0
h_target = utils.to_categorical(test_label, num_classes=2).float()
h_data = test_tensor.view(batch_size*2, -1)
for hidden in hiddens:
    hidden = hidden.view(batch_size*2, -1)
    hxz_l, hyz_l = hsic.hsic_objective(
            hidden,
            h_target=h_target.float(),
            h_data=h_data,
            sigma=5.,
            ktype='linear'
        )
    loss_hsic += hyz_l
print("Loss HSIC ...", loss_hsic)
# Test 1st dimension
new_test_tensor = test_tensor.clone()
new_test_tensor[:,1] = 0
_, test_output = net(new_test_tensor)
test_loss = criterion(test_output, test_label)
test_acc = (test_output.max(-1)[1] == test_label).float().mean().item()
print("1st Dimension Testing ...", test_acc, test_loss)
new_test_tensor = test_tensor.clone()
new_test_tensor[:, 0] = 0
_, test_output = net(new_test_tensor)
test_loss = criterion(test_output, test_label)
test_acc = (test_output.max(-1)[1] == test_label).float().mean().item()
print("2nd Dimension Testing ...", test_acc, test_loss)
####################################Visualization#############################################
x_1, y_1 = data_1.T
x_2, y_2 = data_2.T
plt.plot(x_1, y_1, 'o', color='r', alpha=0.2, label='0 label data')
plt.plot(x_2, y_2, 'o', color='g', alpha=0.2, label='1 label data')
plt.xlabel('x')
plt.ylabel('y')
plt.legend()
plt.savefig(os.path.join(root_dir, "visual_data.png"))
plt.close()
print(net.state_dict().keys())
print(net.state_dict()['fc1.weight'])

################################## GAN ############################################################################################################

mu = -2
sigma = 0.3
M = 200

discriminate = Discriminator()
generate = Generator()

# plot_fig(generate, discriminate)
# plt.title('Before training')
# plt.show()

epochs = 150
histd, histg = np.zeros(epochs), np.zeros(epochs)
k = 20

visualize_training = False

# plt.ion()

discriminate_optimizer = torch.optim.SGD(discriminate.parameters(), lr=0.1, momentum=0.6)
generate_optimizer = torch.optim.SGD(generate.parameters(), lr=0.01, momentum=0.6)

z_dim = 8
for i in range(epochs):
    for j in range(k):
        discriminate.zero_grad()
        z_tensor = torch.randn(M, z_dim)
        # x_tensor = Variable(torch.from_numpy(np.float32(x.reshape(M, 1))))
        x_tensor = make_dataset(mean_3, cov_3, M)
        g_out = generate(z_tensor)
        d_out_true = discriminate(x_tensor)
        d_out_g = discriminate(g_out)
        loss = discriminator_criterion(d_out_true, d_out_g)
        loss.backward()
        discriminate_optimizer.step()
        histd[i] = loss.data.numpy()

    generate.zero_grad()
    z_tensor = torch.randn(M, z_dim)
    g_out = generate(z_tensor)
    d_out_g = discriminate(g_out)
    loss = generator_criterion(d_out_g)
    loss.backward()
    generate_optimizer.step()
    histg[i] = loss.data.numpy()

    if i % 10 == 0:
        print("Epoch ", i)
        print('Discriminator loss', histd[i])
        print('Generator loss', histg[i])
        for param_group in generate_optimizer.param_groups:
            param_group['lr'] *= 0.999
        for param_group in discriminate_optimizer.param_groups:
            param_group['lr'] *= 0.999

# Visualization
num_sample = 5000
real_tensor = make_dataset(mean_3, cov_3, num_sample)
x_real, y_real = real_tensor.numpy().T
z_tensor = torch.randn(num_sample, z_dim)
g_out = generate(z_tensor)
x_f, y_f = g_out.detach().numpy().T

data_1, data_2, train_tensor, train_label = make_dataset_cls(mean_1, cov_1, mean_2, cov_2, num_sample)
test_data_1, test_data_2, test_tensor, test_label = make_dataset_cls(mean_1, cov_1, mean_2, cov_2, num_sample)
x_1, y_1 = data_1.T
x_2, y_2 = data_2.T
plt.plot(x_1, y_1, 'o', color='r', alpha=0.2, label='0 label data')
plt.plot(x_2, y_2, 'o', color='g', alpha=0.2, label='1 label data')
plt.plot(x_real, y_real, 'o', color='c', alpha=0.2, label='GAN unlabeled data')
plt.xlabel('x')
plt.ylabel('y')
plt.legend()
plt.savefig(os.path.join(root_dir, "visual_data_and_gan.png"))
plt.close()

################################## GMI ############################################################################################################
# Train sample

num_sample = 5000
criterion = nn.CrossEntropyLoss()
z = torch.randn(num_sample, z_dim)
z.requires_grad = True
v = torch.zeros(num_sample, z_dim).float()
iter_times = 50
momentum=0.9
lamda = 100
clip_range = 1
lr=0.01
init_fake = generate(z)
for i in range(iter_times):
    if i%1 == 0:
        print("Acc ...", acc)
        z.requires_grad = False
        fake_0 = generate(z)
        changes = fake_0 - init_fake
        changes = torch.mean(changes, dim=0)
        x_mi_0, y_mi_0 = fake_0.detach().numpy().T
        plt.plot(x_mi_0, y_mi_0, 'x', color='m', alpha=1.0, label='1 label attacked data')
        plt.plot(x_1, y_1, 'o', color='r', alpha=0.2, label='0 label data')
        plt.plot(x_2, y_2, 'o', color='g', alpha=0.2, label='1 label data')
        plt.legend()
        os.makedirs(os.path.join(root_dir, "class_0"), exist_ok=True)
        plt.savefig(os.path.join(root_dir, "class_0", "visual_GMI_"+str(i)+"_0.png"))
        plt.close()
        z.requires_grad = True
    fake = generate(z)
    _, output = net(fake)
    d_out = discriminate(fake)
    target = torch.from_numpy(np.array([0]*num_sample))
    Total_Loss = 0
    Total_Loss += -torch.mean(torch.log(d_out))
    Total_Loss += lamda*criterion(output, target)
    acc = (output.max(-1)[1] == target).float().mean().item()
    Total_Loss.backward()
    v_prev = v.clone()
    gradient = z.grad.data
    v = momentum * v - lr * gradient
    z = z + (- momentum * v_prev + (1 + momentum) * v)
    z = torch.clamp(z.detach(), -clip_range, clip_range).float()
    z.requires_grad = True

z.requires_grad = False
fake_0 = generate(z)
x_mi_0, y_mi_0 = fake_0.detach().numpy().T
changes = fake_0 - init_fake
changes = torch.mean(changes, dim=0)
print("0", changes)

z = torch.randn(num_sample, z_dim)
z.requires_grad = True
v = torch.zeros(num_sample, z_dim).float()
print('#'*20)
init_fake = generate(z)
for i in range(iter_times):
    if i%1 == 0:
        print("Acc ...", acc)
        z.requires_grad = False
        fake_1 = generate(z)
        changes = fake_1 - init_fake
        changes = torch.mean(changes, dim=0)
        x_mi_1, y_mi_1 = fake_1.detach().numpy().T
        plt.plot(x_mi_1, y_mi_1, 'x', color='y', alpha=1.0, label='1 label attacked data')
        plt.plot(x_1, y_1, 'o', color='r', alpha=0.2, label='0 label data')
        plt.plot(x_2, y_2, 'o', color='g', alpha=0.2, label='1 label data')
        plt.legend()
        os.makedirs(os.path.join(root_dir, "class_1"), exist_ok=True)
        plt.savefig(os.path.join(root_dir, "class_1", "visual_GMI_"+str(i)+"_1.png"))
        plt.close()
        z.requires_grad = True
    fake = generate(z)
    _, output = net(fake)
    d_out = discriminate(fake)
    target = torch.from_numpy(np.array([1]*num_sample))
    Total_Loss = 0
    Total_Loss += -torch.mean(torch.log(d_out))
    Total_Loss += lamda*criterion(output, target)
    acc = (output.max(-1)[1] == target).float().mean().item()
    Total_Loss.backward()
    v_prev = v.clone()
    gradient = z.grad.data
    v = momentum * v - lr * gradient
    z = z + (- momentum * v_prev + (1 + momentum) * v)
    z = torch.clamp(z.detach(), -clip_range, clip_range).float()
    z.requires_grad = True

x_mi_1, y_mi_1 = fake_1.detach().numpy().T
plt.plot(x_mi_0, y_mi_0, 'x', color='m', alpha=1.0, label='0 label attacked data')
plt.plot(x_mi_1, y_mi_1, 'x', color='y', alpha=1.0, label='1 label attacked data')
plt.plot(x_1, y_1, 'o', color='r', alpha=0.2, label='0 label data')
plt.plot(x_2, y_2, 'o', color='g', alpha=0.2, label='1 label data')
plt.legend()
plt.savefig(os.path.join(root_dir, "visual_GMI.png"))
z.requires_grad = False
fake_1 = generate(z)
x_mi_1, y_mi_1 = fake_0.detach().numpy().T
changes = fake_1 - init_fake
changes = torch.mean(changes, dim=0)
print("1", changes)

# Test 1st dimension
new_test_tensor_0 = fake_0.clone()
test_label_0 = torch.from_numpy(np.array([0]*num_sample))
new_test_tensor_1 = fake_1.clone()
test_label_1 = torch.from_numpy(np.array([1]*num_sample))
new_test_tensor = torch.cat([new_test_tensor_0, new_test_tensor_1], dim=0)
test_label = torch.cat([test_label_0, test_label_1], dim=0)
new_test_tensor[:,1] = 0
_, test_output = net(new_test_tensor)
test_loss = criterion(test_output, test_label)
test_acc = (test_output.max(-1)[1] == test_label).float().mean().item()
print("1st Dimension Testing ...", test_acc, test_loss)
new_test_tensor_0 = fake_0.clone()
test_label_0 = torch.from_numpy(np.array([0]*num_sample))
new_test_tensor_1 = fake_1.clone()
test_label_1 = torch.from_numpy(np.array([1]*num_sample))
new_test_tensor = torch.cat([new_test_tensor_0, new_test_tensor_1], dim=0)
test_label = torch.cat([test_label_0, test_label_1], dim=0)
new_test_tensor[:, 0] = 0
_, test_output = net(new_test_tensor)
test_loss = criterion(test_output, test_label)
test_acc = (test_output.max(-1)[1] == test_label).float().mean().item()
print("2nd Dimension Testing ...", test_acc, test_loss)

