import torch, os, time, model, utils, hsic, sys
import numpy as np
import torch.nn as nn
from copy import deepcopy
from torch.optim.lr_scheduler import MultiStepLR
from util import Bar, Logger, AverageMeter, accuracy, mkdir_p, savefig
from util.misc import AverageListMeter
import torch.nn.functional as F
from tqdm import tqdm
from DiffAugment_pytorch import DiffAugment
from torchvision import transforms
from torchvision.utils import save_image
import torchvision


device = "cuda"


def test(model, criterion, dataloader):
    tf = time.time()
    model.eval()
    loss, cnt, ACC = 0.0, 0, 0

    for img, iden in dataloader:
        img, iden = img.to(device), iden.to(device)
        bs = img.size(0)
        iden = iden.view(-1)

        out_digit = model(img)[-1]
        out_iden = torch.argmax(out_digit, dim=1).view(-1)
        ACC += torch.sum(iden == out_iden).item()
        cnt += bs

    return ACC * 100.0 / cnt


def multilayer_hsic(model, criterion, inputs, target, a1, a2, n_classes, ktype, hsic_training, measure):
    hx_l_list = []
    hy_l_list = []
    bs = inputs.size(0)
    total_loss = 0

    if hsic_training:
        hiddens, out_digit = model(inputs)
        cross_loss = criterion(out_digit, target)

        total_loss += cross_loss
        h_target = utils.to_categorical(target, num_classes=n_classes).float()
        h_data = inputs.view(bs, -1)
        for hidden in hiddens:
            hidden = hidden.view(bs, -1)

            if measure == 'HSIC':
                hxz_l, hyz_l = hsic.hsic_objective(
                    hidden,
                    h_target=h_target.float(),
                    h_data=h_data,
                    sigma=5.,
                    ktype=ktype
                )
            elif measure == 'COCO':
                hxz_l, hyz_l = hsic.coco_objective(
                    hidden,
                    h_target=h_target.float(),
                    h_data=h_data,
                    sigma=5.,
                    ktype=ktype
                )

            temp_hsic = a1 * hxz_l - a2 * hyz_l
            total_loss += temp_hsic

            hx_l_list.append(round(hxz_l.item(), 5))
            hy_l_list.append(round(hyz_l.item(), 5))

    else:
        feats, out_digit = model(inputs)
        cross_loss = criterion(out_digit, target)

        total_loss += cross_loss
        h_target = utils.to_categorical(target, num_classes=n_classes).float()
        h_data = inputs.view(bs, -1)
        # hidden = feats.view(bs, -1)

        # hxy_l = hsic.hsic_normalized_cca(h_data, out_digit, sigma=5., ktype=ktype)
        hxy_l = hsic.coco_normalized_cca(h_data, out_digit, sigma=5., ktype=ktype)

        # hxz_l, hyz_l = hsic.hsic_objective(
        #     hidden,
        #     h_target=h_target,
        #     h_data=h_data,
        #     sigma=5.,
        #     ktype=ktype
        # )

        # temp_hsic = a1 * hxz_l - a2 * hyz_l
        temp_hsic = a1 * hxy_l
        total_loss += temp_hsic

        hxz_l = hxy_l
        hyz_l = hxy_l
        hx_l_list.append(round(hxz_l.item(), 5))
        hy_l_list.append(round(hyz_l.item(), 5))

    return total_loss, cross_loss, out_digit, hx_l_list, hy_l_list


def multilayer_hsic_layers(model, criterion, inputs, target, a1, a2, n_classes, ktype, hsic_training, measure, layers):
    hx_l_list = []
    hy_l_list = []
    bs = inputs.size(0)
    total_loss = 0

    if hsic_training:
        hiddens, out_digit = model(inputs)
        hiddens = [hiddens[i] for i in layers]
        cross_loss = criterion(out_digit, target)

        total_loss += cross_loss
        h_target = utils.to_categorical(target, num_classes=n_classes).float()
        h_data = inputs.view(bs, -1)
        for hidden in hiddens:
            hidden = hidden.view(bs, -1)

            if measure == 'HSIC':
                hxz_l, hyz_l = hsic.hsic_objective(
                    hidden,
                    h_target=h_target.float(),
                    h_data=h_data,
                    sigma=5.,
                    ktype=ktype
                )
            elif measure == 'COCO':
                hxz_l, hyz_l = hsic.coco_objective(
                    hidden,
                    h_target=h_target.float(),
                    h_data=h_data,
                    sigma=5.,
                    ktype=ktype
                )

            temp_hsic = a1 * hxz_l - a2 * hyz_l
            total_loss += temp_hsic

            hx_l_list.append(round(hxz_l.item(), 5))
            hy_l_list.append(round(hyz_l.item(), 5))

    else:
        feats, out_digit = model(inputs)
        cross_loss = criterion(out_digit, target)

        total_loss += cross_loss
        h_target = utils.to_categorical(target, num_classes=n_classes).float()
        h_data = inputs.view(bs, -1)
        # hidden = feats.view(bs, -1)

        # hxy_l = hsic.hsic_normalized_cca(h_data, out_digit, sigma=5., ktype=ktype)
        hxy_l = hsic.coco_normalized_cca(h_data, out_digit, sigma=5., ktype=ktype)

        # hxz_l, hyz_l = hsic.hsic_objective(
        #     hidden,
        #     h_target=h_target,
        #     h_data=h_data,
        #     sigma=5.,
        #     ktype=ktype
        # )

        # temp_hsic = a1 * hxz_l - a2 * hyz_l
        temp_hsic = a1 * hxy_l
        total_loss += temp_hsic

        hxz_l = hxy_l
        hyz_l = hxy_l
        hx_l_list.append(round(hxz_l.item(), 5))
        hy_l_list.append(round(hyz_l.item(), 5))

    return total_loss, cross_loss, out_digit, hx_l_list, hy_l_list

import random
def multilayer_hsic_diffaug(model, criterion, inputs, target, a1, a2, n_classes, ktype, hsic_training, measure, batch_idx):
    hx_l_list = []
    hy_l_list = []
    bs = inputs.size(0)
    total_loss = 0
    # aug_prob = 10.0

    if hsic_training:
        # if random.random() < aug_prob:
        input_list = []
        for image in inputs:
            new_input = torchvision.transforms.RandomErasing(p=1, scale=(0.3, 0.8), ratio=(1, 1), value=0.0, inplace=False)(image)
            diff = torch.sum(new_input - image)
            if diff == 0:
                while torch.sum(new_input - image)==0:
                    new_input = torchvision.transforms.RandomErasing(p=1, scale=(0.3, 0.8), ratio=(1, 1), value=0.0, inplace=False)(image)
            image = torch.unsqueeze(new_input, 0)
            input_list.append(image)
        diff_inputs = torch.cat(input_list, 0)
        # diff_inputs = DiffAugment(inputs / 2 + .5, 'cutout').clamp(0, 1) * 2 - 1
        save_image(diff_inputs, 'hsic_training_images.png')
        # else:

            # diff_inputs = inputs
            # pass
        hiddens, out_digit = model(diff_inputs)
        # hiddens, _ = model(diff_inputs)
        cross_loss = criterion(out_digit, target)

        total_loss += cross_loss
        h_target = utils.to_categorical(target, num_classes=n_classes).float()
        h_data = diff_inputs.view(bs, -1)
        for hidden in hiddens:
            hidden = hidden.view(bs, -1)

            if measure == 'HSIC':
                hxz_l, hyz_l = hsic.hsic_objective(
                    hidden,
                    h_target=h_target.float(),
                    h_data=h_data,
                    sigma=5.,
                    ktype=ktype
                )
            elif measure == 'COCO':
                hxz_l, hyz_l = hsic.coco_objective(
                    hidden,
                    h_target=h_target.float(),
                    h_data=h_data,
                    sigma=5.,
                    ktype=ktype
                )

            temp_hsic = a1 * hxz_l - a2 * hyz_l
            total_loss += temp_hsic

            hx_l_list.append(round(hxz_l.item(), 5))
            hy_l_list.append(round(hyz_l.item(), 5))

    else:
        feats, out_digit = model(inputs)
        cross_loss = criterion(out_digit, target)

        total_loss += cross_loss
        h_target = utils.to_categorical(target, num_classes=n_classes).float()
        h_data = inputs.view(bs, -1)
        # hidden = feats.view(bs, -1)

        # hxy_l = hsic.hsic_normalized_cca(h_data, out_digit, sigma=5., ktype=ktype)
        hxy_l = hsic.coco_normalized_cca(h_data, out_digit, sigma=5., ktype=ktype)

        # hxz_l, hyz_l = hsic.hsic_objective(
        #     hidden,
        #     h_target=h_target,
        #     h_data=h_data,
        #     sigma=5.,
        #     ktype=ktype
        # )

        # temp_hsic = a1 * hxz_l - a2 * hyz_l
        temp_hsic = a1 * hxy_l
        total_loss += temp_hsic

        hxz_l = hxy_l
        hyz_l = hxy_l
        hx_l_list.append(round(hxz_l.item(), 5))
        hy_l_list.append(round(hyz_l.item(), 5))

    return total_loss, cross_loss, out_digit, hx_l_list, hy_l_list

def multilayer_hsic_blurr(model, criterion, inputs, target, a1, a2, n_classes, ktype, hsic_training, measure):
    hx_l_list = []
    hy_l_list = []
    bs = inputs.size(0)
    total_loss = 0

    if hsic_training:
        new_inputs = transforms.GaussianBlur(kernel_size=int(0.05 * 64))(inputs)
        hiddens, out_digit = model(new_inputs)
        # hiddens, _ = model(diff_inputs)
        cross_loss = criterion(out_digit, target)

        total_loss += cross_loss
        h_target = utils.to_categorical(target, num_classes=n_classes).float()
        h_data = new_inputs.view(bs, -1)
        for hidden in hiddens:
            hidden = hidden.view(bs, -1)

            if measure == 'HSIC':
                hxz_l, hyz_l = hsic.hsic_objective(
                    hidden,
                    h_target=h_target.float(),
                    h_data=h_data,
                    sigma=5.,
                    ktype=ktype
                )
            elif measure == 'COCO':
                hxz_l, hyz_l = hsic.coco_objective(
                    hidden,
                    h_target=h_target.float(),
                    h_data=h_data,
                    sigma=5.,
                    ktype=ktype
                )

            temp_hsic = a1 * hxz_l - a2 * hyz_l
            total_loss += temp_hsic

            hx_l_list.append(round(hxz_l.item(), 5))
            hy_l_list.append(round(hyz_l.item(), 5))

    else:
        feats, out_digit = model(inputs)
        cross_loss = criterion(out_digit, target)

        total_loss += cross_loss
        h_target = utils.to_categorical(target, num_classes=n_classes).float()
        h_data = inputs.view(bs, -1)
        # hidden = feats.view(bs, -1)

        # hxy_l = hsic.hsic_normalized_cca(h_data, out_digit, sigma=5., ktype=ktype)
        hxy_l = hsic.coco_normalized_cca(h_data, out_digit, sigma=5., ktype=ktype)

        # hxz_l, hyz_l = hsic.hsic_objective(
        #     hidden,
        #     h_target=h_target,
        #     h_data=h_data,
        #     sigma=5.,
        #     ktype=ktype
        # )

        # temp_hsic = a1 * hxz_l - a2 * hyz_l
        temp_hsic = a1 * hxy_l
        total_loss += temp_hsic

        hxz_l = hxy_l
        hyz_l = hxy_l
        hx_l_list.append(round(hxz_l.item(), 5))
        hy_l_list.append(round(hyz_l.item(), 5))

    return total_loss, cross_loss, out_digit, hx_l_list, hy_l_list


def multilayer_hsic_public(model, criterion, inputs, target, gan_inputs, a1, a2, n_classes, ktype, hsic_training, measure):
    hx_l_list = []
    hy_l_list = []
    bs = inputs.size(0)
    total_loss = 0

    if hsic_training:
        _, out_digit = model(inputs)
        cross_loss = criterion(out_digit, target)

        total_loss += cross_loss
        # h_target = utils.to_categorical(target, num_classes=n_classes).float()
        hiddens, gan_out_digit = model(gan_inputs)
        gan_out_digit = torch.nn.Softmax(dim=1)(gan_out_digit)
        # h_target = gan_out_digit
        h_target = gan_out_digit.max(-1)[1]
        h_target = utils.to_categorical(h_target, num_classes=n_classes).float()
        h_data = gan_inputs.view(bs, -1)
        for hidden in hiddens:
            hidden = hidden.view(bs, -1)

            if measure == 'HSIC':
                hxz_l, hyz_l = hsic.hsic_objective(
                    hidden,
                    h_target=h_target.float(),
                    h_data=h_data,
                    sigma=5.,
                    ktype=ktype
                )
            elif measure == 'COCO':
                hxz_l, hyz_l = hsic.coco_objective(
                    hidden,
                    h_target=h_target.float(),
                    h_data=h_data,
                    sigma=5.,
                    ktype=ktype
                )

            temp_hsic = a1 * hxz_l - a2 * hyz_l
            total_loss += temp_hsic

            hx_l_list.append(round(hxz_l.item(), 5))
            hy_l_list.append(round(hyz_l.item(), 5))

    else:
        feats, out_digit = model(inputs)
        cross_loss = criterion(out_digit, target)

        total_loss += cross_loss
        h_target = utils.to_categorical(target, num_classes=n_classes).float()
        h_data = inputs.view(bs, -1)
        # hidden = feats.view(bs, -1)

        # hxy_l = hsic.hsic_normalized_cca(h_data, out_digit, sigma=5., ktype=ktype)
        hxy_l = hsic.coco_normalized_cca(h_data, out_digit, sigma=5., ktype=ktype)

        # hxz_l, hyz_l = hsic.hsic_objective(
        #     hidden,
        #     h_target=h_target,
        #     h_data=h_data,
        #     sigma=5.,
        #     ktype=ktype
        # )

        # temp_hsic = a1 * hxz_l - a2 * hyz_l
        temp_hsic = a1 * hxy_l
        total_loss += temp_hsic

        hxz_l = hxy_l
        hyz_l = hxy_l
        hx_l_list.append(round(hxz_l.item(), 5))
        hy_l_list.append(round(hyz_l.item(), 5))

    return total_loss, cross_loss, out_digit, hx_l_list, hy_l_list

def multilayer_hsic_public_2_last(model, criterion, inputs, target, gan_inputs, a1, a2, n_classes, ktype, hsic_training, measure):
    hx_l_list = []
    hy_l_list = []
    bs = inputs.size(0)
    total_loss = 0

    if hsic_training:
        _, out_digit = model(inputs)
        cross_loss = criterion(out_digit, target)

        total_loss += cross_loss
        # h_target = utils.to_categorical(target, num_classes=n_classes).float()
        hiddens, gan_out_digit = model(gan_inputs)
        hiddens = hiddens[-2:]
        gan_out_digit = torch.nn.Softmax(dim=1)(gan_out_digit)
        # h_target = gan_out_digit
        h_target = gan_out_digit.max(-1)[1]
        h_target = utils.to_categorical(h_target, num_classes=n_classes).float()
        h_data = gan_inputs.view(bs, -1)
        for hidden in hiddens:
            hidden = hidden.view(bs, -1)

            if measure == 'HSIC':
                hxz_l, hyz_l = hsic.hsic_objective(
                    hidden,
                    h_target=h_target.float(),
                    h_data=h_data,
                    sigma=5.,
                    ktype=ktype
                )
            elif measure == 'COCO':
                hxz_l, hyz_l = hsic.coco_objective(
                    hidden,
                    h_target=h_target.float(),
                    h_data=h_data,
                    sigma=5.,
                    ktype=ktype
                )

            temp_hsic = a1 * hxz_l - a2 * hyz_l
            total_loss += temp_hsic

            hx_l_list.append(round(hxz_l.item(), 5))
            hy_l_list.append(round(hyz_l.item(), 5))

    else:
        feats, out_digit = model(inputs)
        cross_loss = criterion(out_digit, target)

        total_loss += cross_loss
        h_target = utils.to_categorical(target, num_classes=n_classes).float()
        h_data = inputs.view(bs, -1)
        # hidden = feats.view(bs, -1)

        # hxy_l = hsic.hsic_normalized_cca(h_data, out_digit, sigma=5., ktype=ktype)
        hxy_l = hsic.coco_normalized_cca(h_data, out_digit, sigma=5., ktype=ktype)

        # hxz_l, hyz_l = hsic.hsic_objective(
        #     hidden,
        #     h_target=h_target,
        #     h_data=h_data,
        #     sigma=5.,
        #     ktype=ktype
        # )

        # temp_hsic = a1 * hxz_l - a2 * hyz_l
        temp_hsic = a1 * hxy_l
        total_loss += temp_hsic

        hxz_l = hxy_l
        hyz_l = hxy_l
        hx_l_list.append(round(hxz_l.item(), 5))
        hy_l_list.append(round(hyz_l.item(), 5))

    return total_loss, cross_loss, out_digit, hx_l_list, hy_l_list


def multilayer_hsic_test(model, criterion, inputs, target, a1, a2, n_classes, ktype, hsic_training, measure):
    hx_l_list = []
    hy_l_list = []
    bs = inputs.size(0)
    total_loss = 0
    # print(target.dtype)
    # exit()

    # zero_probs = []

    if hsic_training:
        hiddens, out_digit = model(inputs)
        # out_softmax = torch.nn.Softmax(dim=1)(out_digit)
        # for output in out_softmax:
            # zero_probs.append(output[0].item())
        if isinstance(hiddens, list):
            hiddens = hiddens
        else:
            hiddens = [hiddens]
        cross_loss = criterion(out_digit, target)

        total_loss += cross_loss
        h_target = utils.to_categorical(target, num_classes=n_classes).float()
        # out_digit = torch.nn.Softmax(dim=1)(out_digit)
        # h_target = out_digit
        h_data = inputs.view(bs, -1)
        hxy_l, _ = hsic.hsic_objective(h_data, h_target=h_target.float(), h_data=h_data, sigma=5., ktype=ktype)
        for hidden in hiddens:
            hidden = hidden.view(bs, -1)
            # print(hidden.shape)

            if measure == 'HSIC':
                hxz_l, hyz_l = hsic.hsic_objective(
                    hidden,
                    h_target=h_target.float(),
                    h_data=h_data,
                    sigma=5.,
                    ktype=ktype
                )
            elif measure == 'COCO':
                hxz_l, hyz_l = hsic.coco_objective(
                    hidden,
                    h_target=h_target.float(),
                    h_data=h_data,
                    sigma=5.,
                    ktype=ktype
                )

            temp_hsic = a1 * hxz_l - a2 * hyz_l
            total_loss += temp_hsic

            hx_l_list.append(round(hxz_l.item(), 5))
            hy_l_list.append(round(hyz_l.item(), 5))
        # exit()
    else:
        feats, out_digit = model(inputs)
        cross_loss = criterion(out_digit, target)

        total_loss += cross_loss
        h_target = utils.to_categorical(target, num_classes=n_classes).float()
        h_data = inputs.view(bs, -1)
        # hidden = feats.view(bs, -1)

        # hxy_l = hsic.hsic_normalized_cca(h_data, out_digit, sigma=5., ktype=ktype)
        hxy_l = hsic.coco_normalized_cca(h_data, out_digit, sigma=5., ktype=ktype)

        # hxz_l, hyz_l = hsic.hsic_objective(
        #     hidden,
        #     h_target=h_target,
        #     h_data=h_data,
        #     sigma=5.,
        #     ktype=ktype
        # )

        # temp_hsic = a1 * hxz_l - a2 * hyz_l
        temp_hsic = a1 * hxy_l
        total_loss += temp_hsic

        hxz_l = hxy_l
        hyz_l = hxy_l
        hx_l_list.append(round(hxz_l.item(), 5))
        hy_l_list.append(round(hyz_l.item(), 5))

    return total_loss, cross_loss, out_digit, hx_l_list, hy_l_list, hxy_l


def train_HSIC(model, criterion, optimizer, trainloader, a1, a2, n_classes,
               ktype='gaussian', hsic_training=True,measure='HSIC'):
    model.train()
    batch_time = AverageMeter()
    data_time = AverageMeter()
    losses = AverageMeter()
    top1 = AverageMeter()
    top5 = AverageMeter()
    loss_cls = AverageMeter()
    lxz, lyz = AverageMeter(), AverageMeter()
    lxz_list, lyz_list = AverageListMeter(3), AverageListMeter(3)
    end = time.time()

    pbar = tqdm(enumerate(trainloader), total=len(trainloader), ncols=150)

    for batch_idx, (inputs, iden) in pbar:
        if batch_idx == 0:
            save_image(inputs, 'hsic_training_images.png')
        data_time.update(time.time() - end)
        bs = inputs.size(0)
        inputs, iden = inputs.to(device), iden.to(device)
        iden = iden.view(-1)

        loss, cross_loss, out_digit, hx_l_list, hy_l_list = multilayer_hsic(model, criterion, inputs, iden, a1, a2,
                                                                            n_classes, ktype, hsic_training, measure)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # measure accuracy and record loss
        prec1, prec5 = accuracy(out_digit.data, iden.data, topk=(1, 5))
        losses.update(loss.item())
        loss_cls.update(float(cross_loss.detach().cpu().numpy()))
        lxz.update(sum(hx_l_list) / len(hx_l_list))
        lyz.update(sum(hy_l_list) / len(hy_l_list))

        lxz_list.update(hx_l_list)
        lyz_list.update(hy_l_list)

        top1.update(prec1.item())
        top5.update(prec5.item())

        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()

        # plot progress
        msg = 'CE:{cls:.4f} | Lxz(down):{lxz:.5f} | Lyz(up):{lyz:.5f} | Loss:{loss:.4f} | ' \
              'top1:{top1: .4f} | top5:{top5: .4f}'.format(
            cls=loss_cls.avg,
            lxz=lxz.avg,
            lyz=lyz.avg,
            loss=losses.avg,
            top1=top1.avg,
            top5=top5.avg,
        )
        pbar.set_description(msg)
    print("hx_l_list:", hx_l_list, lxz_list.avg)
    print("hy_l_list:", hy_l_list, lyz_list.avg)
    return losses.avg, loss_cls.avg, top1.avg, lxz.avg, lyz.avg, lxz_list.avg, lyz_list.avg

def train_HSIC_nonsenstive(model, criterion, optimizer, trainloader, a1, a2, n_classes,
               ktype='gaussian', hsic_training=True,measure='HSIC'):
    model.train()
    batch_time = AverageMeter()
    data_time = AverageMeter()
    losses = AverageMeter()
    top1 = AverageMeter()
    top5 = AverageMeter()
    loss_cls = AverageMeter()
    lxz, lyz = AverageMeter(), AverageMeter()
    lxz_list, lyz_list = AverageListMeter(5), AverageListMeter(5)
    end = time.time()

    pbar = tqdm(enumerate(trainloader), total=len(trainloader), ncols=150)
    h = w = 48
    # w = 64
    for batch_idx, (inputs, iden) in pbar:
        data_time.update(time.time() - end)
        bs = inputs.size(0)
        input_list = []
        for input in inputs:
            # input = torchvision.transforms.functional.erase(input, i=0, j=0, h=h, w=w, v=0)
            # input = torchvision.transforms.functional.erase(input, i=64-h, j=0, h=h, w=w, v=0)
            # input = torchvision.transforms.functional.erase(input, i=32-int(h/2), j=32-int(w/2), h=h, w=w, v=0)
            # 32-int(h/2), j=32-int(w/2), h=h, w=w, v=0)
            # input = torchvision.transforms.GaussianBlur(kernel_size=(5, 5), sigma=(1, 1))(input)
            # input = torchvision.transforms.functional.adjust_sharpness(input, 20)
            # input = torchvision.transforms.RandomErasing(p=1.0, scale=(0.25, 0.25), ratio=(1, 1), value=0, inplace=False)(input)
            # input = AddGaussianNoise(0, 0.1, device)(input)
            input = torchvision.transforms.functional.resized_crop(input, top=32-int(h/2), left=32-int(w/2), height=h,width=w, size=h)
            input = torchvision.transforms.Pad(padding=int((64-h)/2))(input)
            # input = torchvision.transforms.functional.resized_crop(input, top=0, left=0, height=h,width=w, size=[64, 64])
            input = torch.unsqueeze(input, 0)
            input_list.append(input)
        inputs = torch.cat(input_list, 0)
        if batch_idx == 0:
            save_image(inputs, 'hsic_training_images.png')
        
        inputs, iden = inputs.to(device), iden.to(device)
        iden = iden.view(-1)

        loss, cross_loss, out_digit, hx_l_list, hy_l_list = multilayer_hsic(model, criterion, inputs, iden, a1, a2,
                                                                            n_classes, ktype, hsic_training, measure)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # measure accuracy and record loss
        prec1, prec5 = accuracy(out_digit.data, iden.data, topk=(1, 5))
        losses.update(loss.item())
        loss_cls.update(float(cross_loss.detach().cpu().numpy()))
        lxz.update(sum(hx_l_list) / len(hx_l_list))
        lyz.update(sum(hy_l_list) / len(hy_l_list))

        lxz_list.update(hx_l_list)
        lyz_list.update(hy_l_list)

        top1.update(prec1.item())
        top5.update(prec5.item())

        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()

        # plot progress
        msg = 'CE:{cls:.4f} | Lxz(down):{lxz:.5f} | Lyz(up):{lyz:.5f} | Loss:{loss:.4f} | ' \
              'top1:{top1: .4f} | top5:{top5: .4f}'.format(
            cls=loss_cls.avg,
            lxz=lxz.avg,
            lyz=lyz.avg,
            loss=losses.avg,
            top1=top1.avg,
            top5=top5.avg,
        )
        pbar.set_description(msg)
    print("hx_l_list:", hx_l_list, lxz_list.avg)
    print("hy_l_list:", hy_l_list, lyz_list.avg)
    return losses.avg, loss_cls.avg, top1.avg, lxz.avg, lyz.avg, lxz_list.avg, lyz_list.avg

def train_HSIC_layers(model, criterion, optimizer, trainloader, a1, a2, n_classes,
               ktype='gaussian', hsic_training=True,measure='HSIC', layers=None):
    model.train()
    batch_time = AverageMeter()
    data_time = AverageMeter()
    losses = AverageMeter()
    top1 = AverageMeter()
    top5 = AverageMeter()
    loss_cls = AverageMeter()
    lxz, lyz = AverageMeter(), AverageMeter()
    lxz_list, lyz_list = AverageListMeter(len(layers)), AverageListMeter(len(layers))
    end = time.time()

    pbar = tqdm(enumerate(trainloader), total=len(trainloader), ncols=150)

    for batch_idx, (inputs, iden) in pbar:
        data_time.update(time.time() - end)
        bs = inputs.size(0)
        inputs, iden = inputs.to(device), iden.to(device)
        iden = iden.view(-1)

        loss, cross_loss, out_digit, hx_l_list, hy_l_list = multilayer_hsic_layers(model, criterion, inputs, iden, a1, a2,
                                                                            n_classes, ktype, hsic_training, measure, layers)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # measure accuracy and record loss
        prec1, prec5 = accuracy(out_digit.data, iden.data, topk=(1, 5))
        losses.update(loss.item())
        loss_cls.update(float(cross_loss.detach().cpu().numpy()))
        lxz.update(sum(hx_l_list) / len(hx_l_list))
        lyz.update(sum(hy_l_list) / len(hy_l_list))

        lxz_list.update(hx_l_list)
        lyz_list.update(hy_l_list)

        top1.update(prec1.item())
        top5.update(prec5.item())

        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()

        # plot progress
        msg = 'CE:{cls:.4f} | Lxz(down):{lxz:.5f} | Lyz(up):{lyz:.5f} | Loss:{loss:.4f} | ' \
              'top1:{top1: .4f} | top5:{top5: .4f}'.format(
            cls=loss_cls.avg,
            lxz=lxz.avg,
            lyz=lyz.avg,
            loss=losses.avg,
            top1=top1.avg,
            top5=top5.avg,
        )
        pbar.set_description(msg)
    print("hx_l_list:", hx_l_list, lxz_list.avg)
    print("hy_l_list:", hy_l_list, lyz_list.avg)
    return losses.avg, loss_cls.avg, top1.avg, lxz.avg, lyz.avg, lxz_list.avg, lyz_list.avg

def train_HSIC_DiffAug(model, criterion, optimizer, trainloader, a1, a2, n_classes,
               ktype='gaussian', hsic_training=True,measure='HSIC'):
    model.train()
    batch_time = AverageMeter()
    data_time = AverageMeter()
    losses = AverageMeter()
    top1 = AverageMeter()
    top5 = AverageMeter()
    loss_cls = AverageMeter()
    lxz, lyz = AverageMeter(), AverageMeter()
    lxz_list, lyz_list = AverageListMeter(3), AverageListMeter(3)
    end = time.time()

    pbar = tqdm(enumerate(trainloader), total=len(trainloader), ncols=150)

    for batch_idx, (inputs, iden) in pbar:
        data_time.update(time.time() - end)
        bs = inputs.size(0)
        inputs, iden = inputs.to(device), iden.to(device)
        iden = iden.view(-1)

        loss, cross_loss, out_digit, hx_l_list, hy_l_list = multilayer_hsic_diffaug(model, criterion, inputs, iden, a1, a2,
                                                                            n_classes, ktype, hsic_training, measure, batch_idx)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # measure accuracy and record loss
        prec1, prec5 = accuracy(out_digit.data, iden.data, topk=(1, 5))
        losses.update(loss.item())
        loss_cls.update(float(cross_loss.detach().cpu().numpy()))
        lxz.update(sum(hx_l_list) / len(hx_l_list))
        lyz.update(sum(hy_l_list) / len(hy_l_list))

        lxz_list.update(hx_l_list)
        lyz_list.update(hy_l_list)

        top1.update(prec1.item())
        top5.update(prec5.item())

        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()

        # plot progress
        msg = 'CE:{cls:.4f} | Lxz(down):{lxz:.5f} | Lyz(up):{lyz:.5f} | Loss:{loss:.4f} | ' \
              'top1:{top1: .4f} | top5:{top5: .4f}'.format(
            cls=loss_cls.avg,
            lxz=lxz.avg,
            lyz=lyz.avg,
            loss=losses.avg,
            top1=top1.avg,
            top5=top5.avg,
        )
        pbar.set_description(msg)
    print("hx_l_list:", hx_l_list, lxz_list.avg)
    print("hy_l_list:", hy_l_list, lyz_list.avg)
    return losses.avg, loss_cls.avg, top1.avg, lxz.avg, lyz.avg, lxz_list.avg, lyz_list.avg

def train_HSIC_RandomErasing(model, criterion, optimizer, trainloader, a1, a2, n_classes,
               ktype='gaussian', hsic_training=True,measure='HSIC'):
    model.train()
    batch_time = AverageMeter()
    data_time = AverageMeter()
    losses = AverageMeter()
    top1 = AverageMeter()
    top5 = AverageMeter()
    loss_cls = AverageMeter()
    lxz, lyz = AverageMeter(), AverageMeter()
    lxz_list, lyz_list = AverageListMeter(3), AverageListMeter(3)
    end = time.time()

    pbar = tqdm(enumerate(trainloader), total=len(trainloader), ncols=150)

    for batch_idx, (inputs, iden) in pbar:
        data_time.update(time.time() - end)
        bs = inputs.size(0)
        inputs, iden = inputs.to(device), iden.to(device)
        iden = iden.view(-1)
        input_list = []
        for input in inputs:
            input = torchvision.transforms.RandomErasing(p=1.0, scale=(0.1, 0.4), ratio=(1, 1), value=(0.485, 0.456, 0.406), inplace=False)(input)
            input = torch.unsqueeze(input, 0)
            input_list.append(input)
        inputs = torch.cat(input_list, 0)
        if batch_idx == 0:
            save_image(inputs, './Training_images.png')

        loss, cross_loss, out_digit, hx_l_list, hy_l_list = multilayer_hsic(model, criterion, inputs, iden, a1, a2,n_classes, ktype, hsic_training, measure)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # measure accuracy and record loss
        prec1, prec5 = accuracy(out_digit.data, iden.data, topk=(1, 5))
        losses.update(loss.item())
        loss_cls.update(float(cross_loss.detach().cpu().numpy()))
        lxz.update(sum(hx_l_list) / len(hx_l_list))
        lyz.update(sum(hy_l_list) / len(hy_l_list))

        lxz_list.update(hx_l_list)
        lyz_list.update(hy_l_list)

        top1.update(prec1.item())
        top5.update(prec5.item())

        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()

        # plot progress
        msg = 'CE:{cls:.4f} | Lxz(down):{lxz:.5f} | Lyz(up):{lyz:.5f} | Loss:{loss:.4f} | ' \
              'top1:{top1: .4f} | top5:{top5: .4f}'.format(
            cls=loss_cls.avg,
            lxz=lxz.avg,
            lyz=lyz.avg,
            loss=losses.avg,
            top1=top1.avg,
            top5=top5.avg,
        )
        pbar.set_description(msg)
    print("hx_l_list:", hx_l_list, lxz_list.avg)
    print("hy_l_list:", hy_l_list, lyz_list.avg)
    return losses.avg, loss_cls.avg, top1.avg, lxz.avg, lyz.avg, lxz_list.avg, lyz_list.avg


# def train_HSIC_Blurr(model, criterion, optimizer, trainloader, a1, a2, n_classes,
#                ktype='gaussian', hsic_training=True,measure='HSIC'):
#     model.train()
#     batch_time = AverageMeter()
#     data_time = AverageMeter()
#     losses = AverageMeter()
#     top1 = AverageMeter()
#     top5 = AverageMeter()
#     loss_cls = AverageMeter()
#     lxz, lyz = AverageMeter(), AverageMeter()
#     lxz_list, lyz_list = AverageListMeter(5), AverageListMeter(5)
#     end = time.time()

#     pbar = tqdm(enumerate(trainloader), total=len(trainloader), ncols=150)

#     for batch_idx, (inputs, iden) in pbar:
#         data_time.update(time.time() - end)
#         bs = inputs.size(0)
#         inputs, iden = inputs.to(device), iden.to(device)
#         iden = iden.view(-1)

#         loss, cross_loss, out_digit, hx_l_list, hy_l_list = multilayer_hsic_blurr(model, criterion, inputs, iden, a1, a2,
#                                                                             n_classes, ktype, hsic_training, measure)
#         optimizer.zero_grad()
#         loss.backward()
#         optimizer.step()

#         # measure accuracy and record loss
#         prec1, prec5 = accuracy(out_digit.data, iden.data, topk=(1, 5))
#         losses.update(loss.item())
#         loss_cls.update(float(cross_loss.detach().cpu().numpy()))
#         lxz.update(sum(hx_l_list) / len(hx_l_list))
#         lyz.update(sum(hy_l_list) / len(hy_l_list))

#         lxz_list.update(hx_l_list)
#         lyz_list.update(hy_l_list)

#         top1.update(prec1.item())
#         top5.update(prec5.item())

#         # measure elapsed time
#         batch_time.update(time.time() - end)
#         end = time.time()

#         # plot progress
#         msg = 'CE:{cls:.4f} | Lxz(down):{lxz:.5f} | Lyz(up):{lyz:.5f} | Loss:{loss:.4f} | ' \
#               'top1:{top1: .4f} | top5:{top5: .4f}'.format(
#             cls=loss_cls.avg,
#             lxz=lxz.avg,
#             lyz=lyz.avg,
#             loss=losses.avg,
#             top1=top1.avg,
#             top5=top5.avg,
#         )
#         pbar.set_description(msg)
#     print("hx_l_list:", hx_l_list, lxz_list.avg)
#     print("hy_l_list:", hy_l_list, lyz_list.avg)
#     return losses.avg, loss_cls.avg, top1.avg, lxz.avg, lyz.avg, lxz_list.avg, lyz_list.avg

# def train_HSIC_public(model, criterion, optimizer, trainloader, gan_loader, a1, a2, n_classes,
#                ktype='gaussian', hsic_training=True,measure='HSIC'):
#     model.train()
#     batch_time = AverageMeter()
#     data_time = AverageMeter()
#     losses = AverageMeter()
#     top1 = AverageMeter()
#     top5 = AverageMeter()
#     loss_cls = AverageMeter()
#     lxz, lyz = AverageMeter(), AverageMeter()
#     lxz_list, lyz_list = AverageListMeter(5), AverageListMeter(5)
#     end = time.time()

#     pbar = tqdm(enumerate(zip(trainloader, gan_loader)), total=len(trainloader), ncols=150)

#     # pbar = tqdm(enumerate(gan_loader), total=len(gan_loader), ncols=150)
#     for batch_idx, (data_1, data_2) in pbar:
#         inputs, iden = data_1
#         gan_inputs, _ = data_2
#         data_time.update(time.time() - end)
#         bs = inputs.size(0)
#         inputs, iden = inputs.to(device), iden.to(device)
#         iden = iden.view(-1)


#         loss, cross_loss, out_digit, hx_l_list, hy_l_list = multilayer_hsic_public(model, criterion, inputs, iden, gan_inputs, a1, a2,
#                                                                             n_classes, ktype, hsic_training, measure)
#         optimizer.zero_grad()
#         loss.backward()
#         optimizer.step()

#         # measure accuracy and record loss
#         prec1, prec5 = accuracy(out_digit.data, iden.data, topk=(1, 5))
#         losses.update(loss.item())
#         loss_cls.update(float(cross_loss.detach().cpu().numpy()))
#         lxz.update(sum(hx_l_list) / len(hx_l_list))
#         lyz.update(sum(hy_l_list) / len(hy_l_list))

#         lxz_list.update(hx_l_list)
#         lyz_list.update(hy_l_list)

#         top1.update(prec1.item())
#         top5.update(prec5.item())

#         # measure elapsed time
#         batch_time.update(time.time() - end)
#         end = time.time()

#         # plot progress
#         msg = 'CE:{cls:.4f} | Lxz(down):{lxz:.5f} | Lyz(up):{lyz:.5f} | Loss:{loss:.4f} | ' \
#               'top1:{top1: .4f} | top5:{top5: .4f}'.format(
#             cls=loss_cls.avg,
#             lxz=lxz.avg,
#             lyz=lyz.avg,
#             loss=losses.avg,
#             top1=top1.avg,
#             top5=top5.avg,
#         )
#         pbar.set_description(msg)
#     print("hx_l_list:", hx_l_list, lxz_list.avg)
#     print("hy_l_list:", hy_l_list, lyz_list.avg)
#     return losses.avg, loss_cls.avg, top1.avg, lxz.avg, lyz.avg, lxz_list.avg, lyz_list.avg

# def train_HSIC_public_2_last(model, criterion, optimizer, trainloader, gan_loader, a1, a2, n_classes,
#                ktype='gaussian', hsic_training=True,measure='HSIC'):
#     model.train()
#     batch_time = AverageMeter()
#     data_time = AverageMeter()
#     losses = AverageMeter()
#     top1 = AverageMeter()
#     top5 = AverageMeter()
#     loss_cls = AverageMeter()
#     lxz, lyz = AverageMeter(), AverageMeter()
#     lxz_list, lyz_list = AverageListMeter(2), AverageListMeter(2)
#     end = time.time()

#     pbar = tqdm(enumerate(zip(trainloader, gan_loader)), total=len(trainloader), ncols=150)

#     # pbar = tqdm(enumerate(gan_loader), total=len(gan_loader), ncols=150)

#     for batch_idx, (data_1, data_2) in pbar:
#         inputs, iden = data_1
#         gan_inputs, _ = data_2
#         data_time.update(time.time() - end)
#         bs = inputs.size(0)
#         inputs, iden = inputs.to(device), iden.to(device)
#         iden = iden.view(-1)

#         loss, cross_loss, out_digit, hx_l_list, hy_l_list = multilayer_hsic_public_2_last(model, criterion, inputs, iden, gan_inputs, a1, a2,
#                                                                             n_classes, ktype, hsic_training, measure)
#         optimizer.zero_grad()
#         loss.backward()
#         optimizer.step()

#         # measure accuracy and record loss
#         prec1, prec5 = accuracy(out_digit.data, iden.data, topk=(1, 5))
#         losses.update(loss.item())
#         loss_cls.update(float(cross_loss.detach().cpu().numpy()))
#         lxz.update(sum(hx_l_list) / len(hx_l_list))
#         lyz.update(sum(hy_l_list) / len(hy_l_list))

#         lxz_list.update(hx_l_list)
#         lyz_list.update(hy_l_list)

#         top1.update(prec1.item())
#         top5.update(prec5.item())

#         # measure elapsed time
#         batch_time.update(time.time() - end)
#         end = time.time()

#         # plot progress
#         msg = 'CE:{cls:.4f} | Lxz(down):{lxz:.5f} | Lyz(up):{lyz:.5f} | Loss:{loss:.4f} | ' \
#               'top1:{top1: .4f} | top5:{top5: .4f}'.format(
#             cls=loss_cls.avg,
#             lxz=lxz.avg,
#             lyz=lyz.avg,
#             loss=losses.avg,
#             top1=top1.avg,
#             top5=top5.avg,
#         )
#         pbar.set_description(msg)
#     print("hx_l_list:", hx_l_list, lxz_list.avg)
#     print("hy_l_list:", hy_l_list, lyz_list.avg)
#     return losses.avg, loss_cls.avg, top1.avg, lxz.avg, lyz.avg, lxz_list.avg, lyz_list.avg


# define "soft" cross-entropy with pytorch tensor operations
def softXEnt (input, target):
    logprobs = torch.nn.functional.log_softmax (input, dim = 1)
    return  -(target * logprobs).sum() / input.shape[0]


def train_uniform(model, member_net, criterion, optimizer, member_optimizer, trainloader, gan_dataloader, a1, a2, n_classes,
               ktype='gaussian', hsic_training=True,measure='HSIC'):
    model.train()
    batch_time = AverageMeter()
    data_time = AverageMeter()
    losses = AverageMeter()
    member_losses = AverageMeter()
    top1 = AverageMeter()
    top5 = AverageMeter()
    member_top1 = AverageMeter()
    loss_cls = AverageMeter()
    lxz, lyz = AverageMeter(), AverageMeter()
    lxz_list, lyz_list = AverageListMeter(3), AverageListMeter(3)
    end = time.time()

    pbar = tqdm(enumerate(zip(trainloader, gan_dataloader)), total=len(trainloader), ncols=150)
    # pbar = tqdm(enumerate(gan_dataloader), total=len(gan_dataloader), ncols=150)

    for batch_idx, (data_1, data_2) in pbar:
        inputs, iden = data_1
        gan_inputs = data_2
        data_time.update(time.time() - end)
        bs = inputs.size(0)
        inputs, iden = inputs.to(device), iden.to(device)
        gan_inputs = gan_inputs.to(device)
        iden = iden.view(-1)

        _, data_out_digit = model(inputs)
        data_out_digit = torch.nn.Softmax(dim=1)(data_out_digit)
        data_label = torch.zeros(64)
        data_label = data_label.to(device)
        data_label = data_label.long()
        _, gan_data_out_digit = model(gan_inputs)
        gan_data_out_digit = torch.nn.Softmax(dim=1)(gan_data_out_digit)
        gan_label = torch.ones(64)
        gan_label = gan_label.to(device)
        gan_label = gan_label.long()

        # if batch_idx > 3:
        data_member_out = member_net(data_out_digit)
        gan_member_out = member_net(gan_data_out_digit)
        member_output = torch.cat((data_member_out, gan_member_out), 0)
        member_label = torch.cat((data_label, gan_label), 0)
        member_loss = criterion(member_output, member_label)
        member_optimizer.zero_grad()
        member_loss.backward()
        member_optimizer.step()
        member_prec1 = accuracy(member_output.data, member_label.data, topk=(1,))[0]
        member_losses.update(member_loss.item(), bs)
        member_top1.update(member_prec1.item())

        
        

        loss, cross_loss, out_digit, hx_l_list, hy_l_list = multilayer_hsic(model, criterion, inputs, iden, a1, a2,
                                                                            n_classes, ktype, hsic_training, measure)
        
        _, data_out_digit = model(inputs)
        data_out_digit = torch.nn.Softmax(dim=1)(data_out_digit)
        data_label = torch.zeros(64)
        data_label = data_label.to(device)
        data_label = data_label.long()
        _, gan_data_out_digit = model(gan_inputs)
        gan_data_out_digit = torch.nn.Softmax(dim=1)(gan_data_out_digit)
        gan_label = torch.ones(64)
        gan_label = gan_label.to(device)
        gan_label = gan_label.long()
        data_member_out = member_net(data_out_digit)
        gan_member_out = member_net(gan_data_out_digit)
        member_output = torch.cat((data_member_out, gan_member_out), 0)
        member_label = torch.cat((data_label, gan_label), 0)
        member_loss = criterion(member_output, member_label)
        loss = loss + 0.1*member_loss
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # measure accuracy and record loss
        prec1, prec5 = accuracy(out_digit.data, iden.data, topk=(1, 5))
        losses.update(loss.item())
        loss_cls.update(float(cross_loss.detach().cpu().numpy()))
        lxz.update(sum(hx_l_list) / len(hx_l_list))
        lyz.update(sum(hy_l_list) / len(hy_l_list))

        lxz_list.update(hx_l_list)
        lyz_list.update(hy_l_list)

        top1.update(prec1.item())
        top5.update(prec5.item())

        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()

        # plot progress
        msg = 'CE:{cls:.4f} | memloss:{member_loss:.5f} | memtop1:{member_top1:.5f} | Lxz:{lxz:.5f} | Lyz:{lyz:.5f} | Loss:{loss:.4f} | ' \
              'top1:{top1: .4f} | top5:{top5: .4f}'.format(
            cls=loss_cls.avg,
            member_loss=member_loss,
            member_top1=member_top1.avg,
            lxz=lxz.avg,
            lyz=lyz.avg,
            loss=losses.avg,
            top1=top1.avg,
            top5=top5.avg,
        )
        pbar.set_description(msg)
    print("hx_l_list:", hx_l_list, lxz_list.avg)
    print("hy_l_list:", hy_l_list, lyz_list.avg)
    return losses.avg, loss_cls.avg, top1.avg, lxz.avg, lyz.avg, lxz_list.avg, lyz_list.avg

# FGSM attack code
def fgsm_attack(image, epsilon, data_grad):
    # Collect the element-wise sign of the data gradient
    sign_data_grad = data_grad.sign()
    # Create the perturbed image by adjusting each pixel of the input image
    perturbed_image = image + epsilon*sign_data_grad
    # Adding clipping to maintain [0,1] range
    perturbed_image = torch.clamp(perturbed_image, 0, 1)
    # Return the perturbed image
    return perturbed_image

def train_adv(model, criterion, optimizer, trainloader, a1, a2, n_classes,
               ktype='gaussian', hsic_training=True,measure='HSIC'):
    model.train()
    batch_time = AverageMeter()
    data_time = AverageMeter()
    losses = AverageMeter()
    top1 = AverageMeter()
    top5 = AverageMeter()
    loss_cls = AverageMeter()
    loss_adv = AverageMeter()
    lxz, lyz = AverageMeter(), AverageMeter()
    lxz_list, lyz_list = AverageListMeter(5), AverageListMeter(5)
    end = time.time()

    pbar = tqdm(enumerate(trainloader), total=len(trainloader), ncols=150)

    for batch_idx, (inputs, iden) in pbar:
        data_time.update(time.time() - end)
        bs = inputs.size(0)
        inputs, iden = inputs.to(device), iden.to(device)
        iden = iden.view(-1)

        # Set requires_grad attribute of tensor. Important for Attack
        model.eval()
        inputs.requires_grad = True
        _, output = model(inputs)
        attack_loss = criterion(output, iden)
        model.zero_grad()
        attack_loss.backward()
        data_grad = inputs.grad.data
        perturbed_datas = fgsm_attack(image=inputs, epsilon=0.001, data_grad=data_grad)
        model.train()
        inputs.requires_grad = False

        loss, cross_loss, out_digit, hx_l_list, hy_l_list = multilayer_hsic(model, criterion, inputs, iden, a1, a2,
                                                                            n_classes, ktype, hsic_training, measure)
        _, adv_out = model(perturbed_datas)
        adv_cross_loss = criterion(adv_out, iden)
        loss = loss - 0.001*adv_cross_loss

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # measure accuracy and record loss
        prec1, prec5 = accuracy(out_digit.data, iden.data, topk=(1, 5))
        losses.update(loss.item())
        loss_cls.update(float(cross_loss.detach().cpu().numpy()))
        loss_adv.update(float(adv_cross_loss.detach().cpu().numpy()))
        lxz.update(sum(hx_l_list) / len(hx_l_list))
        lyz.update(sum(hy_l_list) / len(hy_l_list))

        lxz_list.update(hx_l_list)
        lyz_list.update(hy_l_list)

        top1.update(prec1.item())
        top5.update(prec5.item())

        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()

        # plot progress
        msg = 'CE:{cls:.5f} | Adv:{adv_loss:.5f} | Lxz(down):{lxz:.5f} | Lyz(up):{lyz:.5f} | Loss:{loss:.4f} | ' \
              'top1:{top1: .4f} | top5:{top5: .4f}'.format(
            cls=loss_cls.avg,
            adv_loss=loss_adv.avg,
            lxz=lxz.avg,
            lyz=lyz.avg,
            loss=losses.avg,
            top1=top1.avg,
            top5=top5.avg,
        )
        pbar.set_description(msg)
    print("hx_l_list:", hx_l_list, lxz_list.avg)
    print("hy_l_list:", hy_l_list, lyz_list.avg)
    return losses.avg, loss_cls.avg, top1.avg, lxz.avg, lyz.avg, lxz_list.avg, lyz_list.avg, loss_adv.avg

def train_no_defend(model, criterion, optimizer, trainloader, n_classes):
    model.train()
    batch_time = AverageMeter()
    data_time = AverageMeter()
    losses = AverageMeter()
    top1 = AverageMeter()
    top5 = AverageMeter()
    loss_cls = AverageMeter()
    lxz, lyz = AverageMeter(), AverageMeter()
    end = time.time()

    pbar = tqdm(enumerate(trainloader), total=len(trainloader), ncols=150)

    for batch_idx, (inputs, iden) in pbar:
        data_time.update(time.time() - end)
        bs = inputs.size(0)
        inputs, iden = inputs.to(device), iden.to(device)
        iden = iden.view(-1)

        hiddens, out_digit = model(inputs)
        loss = criterion(out_digit, iden)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # measure accuracy and record loss
        prec1, prec5 = accuracy(out_digit.data, iden.data, topk=(1, 5))
        losses.update(loss.item())

        top1.update(prec1.item())
        top5.update(prec5.item())

        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()

        # plot progress
        msg = 'CE:{cls:.4f} | Lxz(down):{lxz:.5f} | Lyz(up):{lyz:.5f} | Loss:{loss:.4f} | ' \
              'top1:{top1: .4f} | top5:{top5: .4f}'.format(
            cls=loss_cls.avg,
            lxz=lxz.avg,
            lyz=lyz.avg,
            loss=losses.avg,
            top1=top1.avg,
            top5=top5.avg,
        )
        pbar.set_description(msg)
    return losses.avg, top1.avg


def test_HSIC(model, criterion, testloader, a1, a2, n_classes, ktype='gaussian', hsic_training=True,measure='HSIC'):
    model.eval()
    batch_time = AverageMeter()
    data_time = AverageMeter()
    losses = AverageMeter()
    top1 = AverageMeter()
    top5 = AverageMeter()
    loss_cls = AverageMeter()
    lxz, lyz = AverageMeter(), AverageMeter()
    end = time.time()

    pbar = tqdm(enumerate(testloader), total=len(testloader), ncols=150)
    with torch.no_grad():
        for batch_idx, (inputs, iden) in pbar:
            if batch_idx == 0:
                save_image(inputs, 'hsic_testing_images.png')
            data_time.update(time.time() - end)

            inputs, iden = inputs.to(device), iden.to(device)
            bs = inputs.size(0)
            iden = iden.view(-1)

            loss, cross_loss, out_digit, hx_l_list, hy_l_list = multilayer_hsic(model, criterion, inputs, iden, a1, a2,
                                                                                n_classes, ktype, hsic_training, measure)

            # measure accuracy and record loss

            prec1, prec5 = accuracy(out_digit.data, iden.data, topk=(1, 5))
            losses.update(loss.item(), bs)
            loss_cls.update(cross_loss.item(), bs)
            lxz.update(sum(hx_l_list) / len(hx_l_list), bs)
            lyz.update(sum(hy_l_list) / len(hy_l_list), bs)

            top1.update(prec1.item(), bs)
            top5.update(prec5.item(), bs)

            # measure elapsed time
            batch_time.update(time.time() - end)
            end = time.time()

            # plot progress
            msg = 'CE:{cls:.4f} | Lxz(down):{lxz:.5f} | Lyz(up):{lyz:.5f} | Loss:{loss:.4f} | ' \
                  'top1:{top1: .4f} | top5:{top5: .4f}'.format(
                cls=loss_cls.avg,
                lxz=lxz.avg,
                lyz=lyz.avg,
                loss=losses.avg,
                top1=top1.avg,
                top5=top5.avg,
            )
            pbar.set_description(msg)

    print("hx_l_list:", hx_l_list)
    print("hy_l_list:", hy_l_list)
    print('-' * 80)
    return losses.avg, top1.avg, top5.avg

def test_no_defend(model, criterion, testloader, n_classes):
    model.eval()
    batch_time = AverageMeter()
    data_time = AverageMeter()
    losses = AverageMeter()
    top1 = AverageMeter()
    top5 = AverageMeter()
    loss_cls = AverageMeter()
    lxz, lyz = AverageMeter(), AverageMeter()
    end = time.time()

    pbar = tqdm(enumerate(testloader), total=len(testloader), ncols=150)
    with torch.no_grad():
        for batch_idx, (inputs, iden) in pbar:
            data_time.update(time.time() - end)

            inputs, iden = inputs.to(device), iden.to(device)
            bs = inputs.size(0)
            iden = iden.view(-1)

            hiddens, out_digit = model(inputs)
            loss = criterion(out_digit, iden)

            # measure accuracy and record loss

            prec1, prec5 = accuracy(out_digit.data, iden.data, topk=(1, 5))
            losses.update(loss.item(), bs)

            top1.update(prec1.item(), bs)
            top5.update(prec5.item(), bs)

            # measure elapsed time
            batch_time.update(time.time() - end)
            end = time.time()

            # plot progress
            msg = 'CE:{cls:.4f} | Lxz(down):{lxz:.5f} | Lyz(up):{lyz:.5f} | Loss:{loss:.4f} | ' \
                  'top1:{top1: .4f} | top5:{top5: .4f}'.format(
                cls=loss_cls.avg,
                lxz=lxz.avg,
                lyz=lyz.avg,
                loss=losses.avg,
                top1=top1.avg,
                top5=top5.avg,
            )
            pbar.set_description(msg)

    print('-' * 80)
    return losses.avg, top1.avg


def train_reg(model, criterion, optimizer, trainloader):
    model.train()
    batch_time = AverageMeter()
    losses = AverageMeter()
    top1 = AverageMeter()
    top5 = AverageMeter()
    loss_cls = AverageMeter()
    end = time.time()

    pbar = tqdm(enumerate(trainloader), total=len(trainloader), ncols=150)

    for batch_idx, (inputs, iden) in pbar:
        inputs, iden = inputs.to(device), iden.to(device)
        iden = iden.view(-1)

        feats, out_digit = model(inputs)
        cross_loss = criterion(out_digit, iden)
        # triplet_loss = triplet(feats, iden)
        loss = cross_loss
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # measure accuracy and record loss
        bs = inputs.size(0)
        prec1, prec5 = accuracy(out_digit.data, iden.data, topk=(1, 5))
        losses.update(loss.item(), bs)
        loss_cls.update(cross_loss.item(), bs)

        top1.update(prec1.item(), bs)
        top5.update(prec5.item(), bs)

        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()

        # plot progress
        msg = '({batch}/{size}) | ' \
              'Loss:{loss:.4f} | ' \
              'top1:{top1: .4f} | top5:{top5: .4f}'.format(
            batch=batch_idx + 1,
            size=len(trainloader),
            cls=loss_cls.avg,
            loss=losses.avg,
            top1=top1.avg,
            top5=top5.avg,
        )
        pbar.set_description(msg)

    return losses.avg, top1.avg


def test_reg(model, criterion, testloader):
    model.eval()
    batch_time = AverageMeter()
    data_time = AverageMeter()
    losses = AverageMeter()
    top1 = AverageMeter()
    top5 = AverageMeter()
    end = time.time()

    pbar = tqdm(enumerate(testloader), total=len(testloader), ncols=150)

    with torch.no_grad():
        for batch_idx, (inputs, iden) in pbar:
            data_time.update(time.time() - end)

            inputs, iden = inputs.to(device), iden.to(device)
            bs = inputs.size(0)
            iden = iden.view(-1)
            feats, out_digit = model(inputs)
            cross_loss = criterion(out_digit, iden)

            loss = cross_loss

            # measure accuracy and record loss
            prec1, prec5 = accuracy(out_digit.data, iden.data, topk=(1, 5))
            losses.update(loss.item(), bs)
            top1.update(prec1.item(), bs)
            top5.update(prec5.item(), bs)

            # measure elapsed time
            batch_time.update(time.time() - end)
            end = time.time()

            # plot progress
            # plot progress
            msg = '({batch}/{size}) | ' \
                  'Loss:{loss:.4f} | ' \
                  'top1:{top1: .4f} | top5:{top5: .4f}'.format(
                batch=batch_idx + 1,
                size=len(testloader),
                loss=losses.avg,
                top1=top1.avg,
                top5=top5.avg,
            )
            pbar.set_description(msg)

    return losses.avg, top1.avg


def train_vib(model, criterion, optimizer, trainloader, beta=1e-2):
    # switch to train mode
    model.train()

    batch_time = AverageMeter()
    data_time = AverageMeter()
    losses = AverageMeter()
    info_losses = AverageMeter()
    top1 = AverageMeter()
    top5 = AverageMeter()
    end = time.time()

    pbar = tqdm(enumerate(trainloader), total=len(trainloader), ncols=150)

    for batch_idx, (inputs, targets) in pbar:
        # measure data loading time
        data_time.update(time.time() - end)

        inputs, targets = inputs.cuda(), targets.cuda()
        bs = inputs.size(0)

        # compute output
        _, mu, std, out_digit = model(inputs)
        cross_loss = criterion(out_digit, targets)
        info_loss = - 0.5 * (1 + 2 * std.log() - mu.pow(2) - std.pow(2)).sum(dim=1).mean()
        loss = cross_loss + beta * info_loss

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # measure accuracy and record loss
        prec1, prec5 = accuracy(out_digit.data, targets.data, topk=(1, 5))
        losses.update(loss.item(), bs)
        info_losses.update(info_loss.item(), bs)
        top1.update(prec1.item(), bs)
        top5.update(prec5.item(), bs)
        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()

        # plot progress
        # plot progress
        msg = '({batch}/{size}) | ' \
              'Loss:{loss:.4f} | ' \
              'top1:{top1: .4f} | top5:{top5: .4f}'.format(
            batch=batch_idx + 1,
            size=len(trainloader),
            cls=losses.avg,
            loss=losses.avg,
            top1=top1.avg,
            top5=top5.avg,
        )
        pbar.set_description(msg)
    return losses.avg, top1.avg, info_losses.avg


def test_vib(model, criterion, testloader, beta=1e-2):
    global best_acc

    batch_time = AverageMeter()
    data_time = AverageMeter()
    losses = AverageMeter()
    top1 = AverageMeter()
    top5 = AverageMeter()

    # switch to evaluate mode
    model.eval()

    end = time.time()
    pbar = tqdm(enumerate(testloader), total=len(testloader), ncols=150)
    with torch.no_grad():
        for batch_idx, (inputs, targets) in pbar:
            # measure data loading time
            data_time.update(time.time() - end)

            inputs, targets = inputs.cuda(), targets.cuda()
            bs = inputs.size(0)

            # compute output
            _, mu, std, out_digit = model(inputs)
            cross_loss = criterion(out_digit, targets)
            info_loss = - 0.5 * (1 + 2 * std.log() - mu.pow(2) - std.pow(2)).sum(dim=1).mean()
            loss = cross_loss + beta * info_loss

            # measure accuracy and record loss
            prec1, prec5 = accuracy(out_digit.data, targets.data, topk=(1, 5))
            losses.update(loss.item(), bs)
            top1.update(prec1.item(), bs)
            top5.update(prec5.item(), bs)

            # measure elapsed time
            batch_time.update(time.time() - end)
            end = time.time()

            # plot progress
            msg = '({batch}/{size}) | ' \
                  'Loss:{loss:.4f} | ' \
                  'top1:{top1: .4f} | top5:{top5: .4f}'.format(
                batch=batch_idx + 1,
                size=len(testloader),
                cls=losses.avg,
                loss=losses.avg,
                top1=top1.avg,
                top5=top5.avg,
            )
            pbar.set_description(msg)
    return losses.avg, top1.avg
