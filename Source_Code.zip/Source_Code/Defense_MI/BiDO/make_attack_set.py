import torch, os, sys, utils
import torchvision
from torchvision.utils import save_image
import torchvision.transforms as transform
from tqdm import tqdm
import time
import matplotlib.pyplot as plt
import numpy as np
import utils_GAN
from torchvision import datasets
from torch.utils.data import DataLoader


class ImageFolderWithPaths(datasets.ImageFolder):

    def __getitem__(self, index):
  
        img, label = super(ImageFolderWithPaths, self).__getitem__(index)
        
        path = self.imgs[index][0]
        
        return (img, label ,path)


device = "cuda"
num_classes = 1000
dataset = 'celeba'
model_path = 'target_model'
# defense = 'reg'
# defense = 'reg_hsichyperparams'
defense = 'HSIC'
# path_T = "Analysis_2/hp_list_((0, 0),)_milestones_(60,)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.000_95.59_100.00_49.tar"
# path_T = "Analysis_2/hp_list_((0.1, 1),)_milestones_(60,)_lr_1e-4_Adam_all_epochs/VGG16_0.100&1.000_93.23_100.00_33.tar"
# path_T = "Analysis_2/hp_list_((0, 10),)_milestones_(60,)_lr_1e-4_Adam_all_epochs/VGG16_0.000&10.000_93.49_100.00_48.tar"
# path_T = "Analysis_1/hp_list_((0.05, 0.5),)_milestones_(40,)_lr_1e-4_Adam_all_epochs/VGG16_0.050&0.500_80.92_90.56_46.tar"
# path_T = "Analysis/hp_list_((0.0, 0.0),)_lr_1e-2_SGD/VGG16_0.000&0.000_86.90.tar"
path_T = "Analysis/hp_list_((0.0, 0.0),)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.000_85.01_91.79_30.tar"
# path_T = "Analysis_1/hp_list_((0.05, 0.5),)_lr_1e-4_Adam_all_epochs/VGG16_0.050&0.500_79.85_90.33_47.tar"
# path_T = "Analysis_DiffAug_cutout11.5/hp_list_((0, 0),)_milestones_(40,)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.000_82.31_91.32_45.tar"

print("Dataset ", path_T)
model_name = "VGG16"
dataset_name = "celeba"
save_img_dir = "../DMI/attack_res/"
model_name = path_T.split('/')[-3] + "_" + path_T.split('/')[-2] + "_" + model_name
save_img_dir = os.path.join(save_img_dir, dataset_name, defense, model_name)
all_img_dir = os.path.join(save_img_dir, 'all')
success_img_dir = os.path.join(save_img_dir, 'res_success')
transform = torchvision.transforms.Compose([torchvision.transforms.ToTensor()])
# dataset = ImageFolderWithPaths(all_img_dir, transform=transform)
# dataloader = DataLoader(dataset, batch_size=64, shuffle=False)
sucess_dataset = ImageFolderWithPaths(success_img_dir, transform=transform)
dataloader = DataLoader(sucess_dataset, batch_size=64, shuffle=False)

pbar = tqdm(enumerate(dataloader), total=len(dataloader), ncols=150)




image_dir = os.path.join(save_img_dir, 'res_success_class')
# count = 0
for batch_idx, (inputs, label, image_path) in pbar:
    idens = []
    image_names = []
    for path in image_path:
        image_name = path.split('/')[-1]
        target = path.split('/')[-1].split('.')[0].split('_')[-2]
        # image_name = path.split('/')[-1].split('.')[0]
        target = int(target)
        idens.append(target)
        image_names.append(image_name)
    iden = torch.Tensor(np.array(idens)).long()
    inputs, iden = inputs.to(device), iden.to(device)
    for i, input in enumerate(inputs):
        label = iden[i]
        class_dir = os.path.join(image_dir, "class_"+str(label.item()))
        os.makedirs(class_dir, exist_ok=True)
        save_image(input, os.path.join(class_dir, image_names[i]))
    # if count % 100:
        # print(batch_idx, "save image", os.path.join(image_dir, str(count)+"_.png"))
        # count+=1
    



