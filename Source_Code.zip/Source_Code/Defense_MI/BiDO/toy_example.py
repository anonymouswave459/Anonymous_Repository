import numpy as np
import torch
import matplotlib.pyplot as plt
from torch import nn

class Net(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(2, 2)
        self.fc2 = nn.Linear(2, 2)

    def forward(self, x):
        out = self.fc1(x)
        out = self.fc2(out)
        return out

def make_dataset_cls(mean_1, cov_1, mean_2, cov_2, num_sample):
    data_1 = np.random.multivariate_normal(mean_1, cov_1, num_sample)
    tensor_1 = torch.from_numpy(data_1).float()
    label_1 = torch.from_numpy(np.array([0]*num_sample)).long()

    data_2 = np.random.multivariate_normal(mean_2, cov_2, num_sample)
    tensor_2 = torch.from_numpy(data_2).float()
    label_2 = torch.from_numpy(np.array([1]*num_sample)).long()

    tensor = torch.cat((tensor_1, tensor_2), 0)
    label = torch.cat((label_1, label_2), 0)

    return data_1, data_2, tensor, label

# make classifier
net = Net()
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(net.parameters(), 0.1)
epochs = 2

# make dataset
mean_1 = [0, 5]
cov_1 = [[1, 0], [0, 5]]
mean_2 = [6, 20]
cov_2 = [[1, 0], [0, 5]]
num_sample = 5000
data_1, data_2, train_tensor, train_label = make_dataset_cls(mean_1, cov_1, mean_2, cov_2, num_sample)
test_data_1, test_data_2, test_tensor, test_label = make_dataset_cls(mean_1, cov_1, mean_2, cov_2, num_sample)

# training classifier
epochs = 90
for epoch in range(epochs):
    output = net(train_tensor)
    loss = criterion(output, train_label)
    loss.backward()
    optimizer.step()
    acc = (output.max(-1)[1] == train_label).float().mean().item()
    print('Training ...', epoch, loss, acc)
test_output = net(test_tensor)
test_acc = (test_output.max(-1)[1] == test_label).float().mean().item()
print("Testing ...", test_acc)


# Visualize
x_1, y_1 = data_1.T
x_2, y_2 = data_2.T
plt.plot(x_1, y_1, 'x', color='r')
plt.plot(x_2, y_2, 'x', color='g')
plt.axis('equal')
plt.savefig("visual.png")

