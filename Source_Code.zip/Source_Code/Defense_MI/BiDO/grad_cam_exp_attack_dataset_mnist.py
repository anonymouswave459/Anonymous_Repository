from pytorch_grad_cam import GradCAM, HiResCAM, ScoreCAM, GradCAMPlusPlus, AblationCAM, XGradCAM, EigenCAM, FullGrad
from pytorch_grad_cam.utils.model_targets import ClassifierOutputTarget
from pytorch_grad_cam.utils.image import show_cam_on_image
from torchvision.models import resnet50

import torch, os, engine, model, utils, sys
import model
from tqdm import tqdm
import time
from util import Bar, Logger, AverageMeter, accuracy
from engine import multilayer_hsic_test
import utils_GAN
import matplotlib.pyplot as plt
import numpy as np
import cv2
from torch import nn
import torchvision
from torchvision import datasets
from PIL import Image
import torchvision.transforms.functional as TF
from torchvision import transforms

class ImageFolderWithPaths(datasets.ImageFolder):

    def __getitem__(self, index):
  
        img, label = super(ImageFolderWithPaths, self).__getitem__(index)
        
        path = self.imgs[index][0]
        
        return (img, label ,path)

os.environ["CUDA_VISIBLE_DEVICES"]="0"
# Target Model Loading
device = "cuda"
n_classes = 5
T = model.MCNN_nohiddens(n_classes)
T = torch.nn.DataParallel(T).cuda()
dataset = 'mnist'
model_path = 'target_model'
defense = 'HSIC'
name_T = "Analysis_1/hp_list_((0, 0),)_milestones_(20, 35)_lr_1e-4_Adam_all_epochs/MCNN_0.000&0.000_99.86_100.00_17.tar"
# name_T = "Analysis_1/hp_list_((0, 1000),)_milestones_(20, 35)_lr_1e-4_Adam_all_epochs/MCNN_0.000&1000.000_99.38_100.00_18.tar"
# name_T = "Analysis_DiffAug/hp_list_((0, 0.1),)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.100_80.75_89.76_44.tar"
path_T = os.path.join(model_path, dataset, defense, name_T)
print(path_T)
ckp_T = torch.load(path_T)
T.load_state_dict(ckp_T['state_dict'], strict=True)
T = T.module
T = T.to(device)
T.eval()
# target_layers = [T.layer1[-1], T.layer2[-1], T.layer3[-1]]
target_layers = [T.layer2[-1]]

path_T = os.path.join(model_path, dataset, defense, name_T)
print("Dataset ", path_T)
model_name = "MCNN"
dataset_name = "mnist"
save_img_dir = "../DMI/attack_res/"
model_name = path_T.split('/')[-3] + "_" + path_T.split('/')[-2] + "_" + model_name
save_img_dir = os.path.join(save_img_dir, dataset_name, defense, model_name)
all_img_dir = os.path.join(save_img_dir, 'all')
all_img_dir_gradcam = os.path.join(save_img_dir, 'all_defendmodel_gradcam')
os.makedirs(all_img_dir_gradcam, exist_ok=True)
success_img_dir = os.path.join(save_img_dir, 'res_success')
success_img_dir_gradcam = os.path.join(save_img_dir, 'res_success_defendmodel_gradcam')
os.makedirs(success_img_dir_gradcam, exist_ok=True)
transform = torchvision.transforms.Compose([torchvision.transforms.ToTensor()])
dataset = ImageFolderWithPaths(all_img_dir, transform=transform)
sucess_dataset = ImageFolderWithPaths(success_img_dir, transform=transform)
sucess_names = set()
for i in range(len(sucess_dataset)):
    image, target, image_path = sucess_dataset[i]
    image_name = image_path.split('/')[-1].split('.')[0]
    sucess_names.add(image_name)

refer_image = Image.open('refer_image/000001.jpg')
proc = []
crop_size = 108
offset_height = (218 - crop_size) // 2
offset_width = (178 - crop_size) // 2
crop = lambda x: x[:, offset_height:offset_height + crop_size, offset_width:offset_width + crop_size]
re_size = 64
proc.append(transforms.ToTensor())
proc.append(transforms.Lambda(crop))
proc.append(transforms.ToPILImage())
proc.append(transforms.Resize((re_size, re_size)))
proc.append(transforms.ToTensor())
Augment = transforms.Compose(proc)
refer_image = Augment(refer_image)
refer_image.unsqueeze_(0)

# dataloader = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=False)
def grad_cam(dataset, model, save_dir, except_names = ()):
    print("Do grad cam on ...", save_dir)
    individual_save_dir = os.path.join(save_dir, "IndividualExample")
    os.makedirs(individual_save_dir, exist_ok=True)
    average_grayscale_cam = np.zeros((32,32))
    count = 0
    for i in range(len(dataset)):
        if i % 100 == 0:
            print("Loading " + str(i)) 
        image, target, image_path = dataset[i]
        target = image_path.split('/')[-1].split('.')[0].split('_')[-2]
        image_name = image_path.split('/')[-1].split('.')[0]
        if image_name in except_names:
            continue
        grad_cam_image_name = image_name + '_gradcam.png'
        target = int(target)

        input_tensor = torch.unsqueeze(image, 0)
        input_tensor = input_tensor.to(device)
        input_tensor = torchvision.transforms.functional.rgb_to_grayscale(input_tensor, num_output_channels=1)
        try:
            output = T(input_tensor)
        except:
            output = T(input_tensor)
            print("$$$$$$$$$$$Run Again$$$$$$$$$$$$$$$")
        # Note: input_tensor can be a batch tensor with several images!

        # Construct the CAM object once, and then re-use it on many images:
        cam = GradCAM(model=T, target_layers=target_layers, use_cuda=True)

        # You can also use it within a with statement, to make sure it is freed,
        # In case you need to re-create it inside an outer loop:
        # with GradCAM(model=model, target_layers=target_layers, use_cuda=args.use_cuda) as cam:
        #   ...

        # We have to specify the target we want to generate
        # the Class Activation Maps for.
        # If targets is None, the highest scoring category
        # will be used for every image in the batch.
        # Here we use ClassifierOutputTarget, but you can define your own custom targets
        # That are, for example, combinations of categories, or specific outputs in a non standard model.
        targets = [ClassifierOutputTarget(target)]

        # You can also pass aug_smooth=True and eigen_smooth=True, to apply smoothing.
        grayscale_cam = cam(input_tensor=input_tensor, targets=targets)

        # In this example grayscale_cam has only one image in the batch:
        grayscale_cam = grayscale_cam[0, :]
        average_grayscale_cam += grayscale_cam
        input_tensor = input_tensor.repeat(1, 3, 1, 1)
        input_tensor = torch.squeeze(input_tensor, 0)
        rgb_img = torchvision.transforms.ToPILImage()(input_tensor)
        rgb_img = np.array(rgb_img)/255

        visualization = show_cam_on_image(rgb_img, grayscale_cam, use_rgb=True)
        # print(visualization, rgb_img, grayscale_cam)
        # exit()
        im = Image.fromarray(visualization)
        # im.save(os.path.join(visual_dir, "no_defend.jpeg"))
        if count < 500:
            # print("Save Image", i, count, grad_cam_image_name)
            os. makedirs(os.path.join(individual_save_dir, 'class_'+str(target)), exist_ok=True)
            im.save(os.path.join(individual_save_dir, 'class_'+str(target), grad_cam_image_name))
            count+=1
    average_grayscale_cam = average_grayscale_cam/len(dataset)
    print(average_grayscale_cam)

grad_cam(dataset=dataset, model=T, save_dir=all_img_dir_gradcam, except_names=sucess_names)
grad_cam(dataset=sucess_dataset, model=T, save_dir=success_img_dir_gradcam)
