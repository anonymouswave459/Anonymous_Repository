import torch, os, engine, model, utils, sys
import model
from tqdm import tqdm
import time
from util import Bar, Logger, AverageMeter, accuracy
from engine import multilayer_hsic_test
import utils_GAN

import torch.nn.functional as F
import torch.optim as optim
import numpy as np
import matplotlib.pyplot as plt

import torchvision

from torchvision import datasets
from torch.utils.data import DataLoader


class ImageFolderWithPaths(datasets.ImageFolder):

    def __getitem__(self, index):
  
        img, label = super(ImageFolderWithPaths, self).__getitem__(index)
        
        path = self.imgs[index][0]
        
        return (img, label ,path)



# FGSM attack code
def fgsm_attack(image, epsilon, data_grad):
    # Collect the element-wise sign of the data gradient
    sign_data_grad = data_grad.sign()
    # Create the perturbed image by adjusting each pixel of the input image
    perturbed_image = image + epsilon*sign_data_grad
    # Adding clipping to maintain [0,1] range
    perturbed_image = torch.clamp(perturbed_image, 0, 1)
    # Return the perturbed image
    return perturbed_image

target_label = 6

def test(model, device, test_loader, epsilon ):

    # Accuracy counter
    correct = 0
    adv_examples = []

    # Loop over all examples in test set
    pbar = tqdm(enumerate(test_loader), total=len(test_loader), ncols=150)
    # for batch_idx, (data, target)  in pbar:
    # for batch_idx, (data, label, image_path) in pbar:
    for batch_idx, (inputs, iden) in pbar:
        # idens = []
        # for path in image_path:
        #     target = path.split('/')[-1].split('.')[0].split('_')[-2]
        #     image_name = path.split('/')[-1].split('.')[0]
        #     target = int(target)
        #     idens.append(target)
        # target = torch.Tensor(np.array(idens)).long()

        # # Send the data and label to the device
        data, target = inputs.to(device), iden.to(device)

        # # Set requires_grad attribute of tensor. Important for Attack
        data.requires_grad = True

        # Forward pass the data through the model
        _, output = model(data)
        init_pred = output.max(1, keepdim=True)[1] # get the index of the max log-probability

        # If the initial prediction is wrong, dont bother attacking, just move on
        if init_pred.item() != target.item():
            continue

        # Calculate the loss
        loss = F.nll_loss(output, target)

        # Zero all existing gradients
        model.zero_grad()

        # Calculate gradients of model in backward pass
        loss.backward()

        # Collect datagrad
        data_grad = data.grad.data

        # Call FGSM Attack
        perturbed_data = fgsm_attack(data, epsilon, data_grad)

        # Re-classify the perturbed image
        _, output = model(perturbed_data)

        # Check for success
        final_pred = output.max(1, keepdim=True)[1] # get the index of the max log-probability
        if final_pred.item() == target.item():
            correct += 1
            # Special case for saving 0 epsilon examples
            if (epsilon == 0) and (len(adv_examples) < 5):
                adv_ex = perturbed_data.squeeze().detach().cpu().numpy()
                adv_examples.append( (init_pred.item(), final_pred.item(), adv_ex) )
        else:
            # Save some adv examples for visualization later
            if len(adv_examples) < 5:
                adv_ex = perturbed_data.squeeze().detach().cpu().numpy()
                adv_examples.append( (init_pred.item(), final_pred.item(), adv_ex) )
         # plot progress
        msg = 'Accuracy:{acc:.5f}'.format(
            acc=correct/float(len(test_loader))
        )
        pbar.set_description(msg)
    # Calculate final accuracy for this epsilon
    final_acc = correct/float(len(test_loader))*100
    print("Epsilon: {}\tTest Accuracy = {} / {} = {}".format(epsilon, correct, len(test_loader), final_acc))

    # Return the accuracy and an adversarial example
    return final_acc, adv_examples

# Defining
device = "cuda"
num_classes = 1000
# T = model.VGG16(num_classes, False)
T = model.VGG16(num_classes, True)
T = torch.nn.DataParallel(T).cuda()
dataset = 'celeba'
model_path = 'target_model'
# defense = 'reg'
# defense = 'reg_hsichyperparams'
defense = 'HSIC'
# path_T = os.path.join(model_path, dataset, defense, "Analysis/hp_list_((0.0, 0.0),)_lr_1e-2_SGD/VGG16_0.000&0.000_86.90.tar")
# path_T = os.path.join(model_path, dataset, defense, 'Analysis/hp_list_((0.0, 0.0),)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.000_85.01_91.79_30.tar')
path_T = os.path.join(model_path, dataset, defense, 'Analysis_1/hp_list_((0.05, 0.5),)_lr_1e-4_Adam_all_epochs/VGG16_0.050&0.500_79.85_90.33_47.tar')
# path_T = os.path.join(model_path, dataset, defense, 'Analysis_DiffAug/hp_list_((0, 0.1),)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.100_80.75_89.76_44.tar')
# path_T = os.path.join(model_path, dataset, defense, 'Analysis_1/hp_list_((0, 0.22),)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.220_80.55_89.20_41.tar')


print(path_T)
ckp_T = torch.load(path_T)
T.load_state_dict(ckp_T['state_dict'], strict=True)

# Loading Dataset
loaded_args = utils.load_json(json_file='config/celeba.json')
model_name = loaded_args["dataset"]["model_name"]
# train_file = loaded_args['dataset']['train_file']
test_file = loaded_args['dataset']['test_file']
train_loader = utils.init_adv_dataloader(loaded_args, test_file, mode="test")

# print("Dataset ", path_T)
# model_name = "VGG16"
# dataset_name = "celeba"
# save_img_dir = "../DMI/attack_res/"
# model_name = path_T.split('/')[-3] + "_" + path_T.split('/')[-2] + "_" + model_name
# save_img_dir = os.path.join(save_img_dir, dataset_name, defense, model_name)
# all_img_dir = os.path.join(save_img_dir, 'all')
# success_img_dir = os.path.join(save_img_dir, 'res_success')
# transform = torchvision.transforms.Compose([torchvision.transforms.ToTensor()])
# dataset = ImageFolderWithPaths(all_img_dir, transform=transform)
# sucess_dataset = ImageFolderWithPaths(success_img_dir, transform=transform)
# train_loader = DataLoader(sucess_dataset, batch_size=1, shuffle=False)


T.eval()
accuracies = []
examples = []
# epsilons = [0.000, 0.001, 0.002, 0.003, 0.004, 0.005]
epsilons = [0.002]
# Run test for each epsilon
for eps in epsilons:
    acc, ex = test(T, device, train_loader, eps)
    accuracies.append(acc)
    examples.append(ex)
print(accuracies)
