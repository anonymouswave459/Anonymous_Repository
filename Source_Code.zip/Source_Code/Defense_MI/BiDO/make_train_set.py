import torch, os, sys, utils
import torchvision
from torchvision.utils import save_image
import torchvision.transforms as transform
from tqdm import tqdm
import time
import matplotlib.pyplot as plt
import numpy as np
import utils_GAN



# Loading Dataset
loaded_args = utils.load_json(json_file='../BiDO/config/mnist.json')
model_name = loaded_args["dataset"]["model_name"]

train_file = loaded_args['dataset']['train_file']
test_file = loaded_args['dataset']['test_file']
# gan_dataset, gan_dataloader = utils_GAN.init_dataloader(loaded_args, "../attack_dataset/CelebA/ganset_dummylabel_1.txt", 64, mode="gan")
# loaded_args[model_name]['batch_size'] = 1

# trainloader = utils.init_dataloader(loaded_args, train_file, mode="train")
testloader = utils.init_dataloader(loaded_args, train_file, mode="test")
# gan_dataset, gan_dataloader = utils_GAN.init_dataloader(loaded_args, "../attack_dataset/CelebA/ganset_dummylabel_1.txt", 64, mode="gan")
# pbar = tqdm(enumerate(trainloader), total=len(trainloader), ncols=150)
pbar = tqdm(enumerate(testloader), total=len(testloader), ncols=150)
# pbar = tqdm(enumerate(gan_dataloader), total=len(gan_dataloader), ncols=150)



image_dir = '/home/hung/mnist/train_images_all'
os.makedirs(image_dir, exist_ok=True)
device = "cuda"


count = 0
for batch_idx, (inputs, iden) in pbar:
    inputs, iden = inputs.to(device), iden.to(device)
    for i, input in enumerate(inputs):
        label = iden[i]
        # class_dir = os.path.join(image_dir, "class_"+str(label.item()))
        # os.makedirs(class_dir, exist_ok=True)
        save_image(input, os.path.join(image_dir, str(count)+"_.jpg"))
    # if count % 100:
        # print(batch_idx, "save image", os.path.join(image_dir, str(count)+"_.png"))
        count+=1
    



