# Drawn from https://gist.github.com/rocknrollnerd/06bfed6b9d1bce612fd6 (in theano)
# This is implemented in PyTorch
# Author : Anirudh Vemula
import numpy as np
import torch
import torch.nn as nn
from torch.autograd import Variable
from scipy.stats import norm
import matplotlib.pyplot as plt
import hsic
import utils

seed = 1
torch.manual_seed(seed)
np.random.seed(seed)

# Classifier
class Net(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(2, 2)
        self.fc2 = nn.Linear(2, 2)

    def forward(self, x):
        feat = self.fc1(x)
        out = self.fc2(feat)
        return [feat], out

def make_dataset_cls(mean_1, cov_1, mean_2, cov_2, num_sample):
    data_1 = np.random.multivariate_normal(mean_1, cov_1, num_sample)
    tensor_1 = torch.from_numpy(data_1).float()
    label_1 = torch.from_numpy(np.array([0]*num_sample)).long()

    data_2 = np.random.multivariate_normal(mean_2, cov_2, num_sample)
    tensor_2 = torch.from_numpy(data_2).float()
    label_2 = torch.from_numpy(np.array([1]*num_sample)).long()

    tensor = torch.cat((tensor_1, tensor_2), 0)
    label = torch.cat((label_1, label_2), 0)

    return data_1, data_2, tensor, label

def make_dataset_cls_seperate(mean_1, cov_1, mean_2, cov_2, num_sample):
    data_1 = np.random.multivariate_normal(mean_1, cov_1, num_sample)
    tensor_1 = torch.from_numpy(data_1).float()
    label_1 = torch.from_numpy(np.array([0]*num_sample)).long()

    data_2 = np.random.multivariate_normal(mean_2, cov_2, num_sample)
    tensor_2 = torch.from_numpy(data_2).float()
    label_2 = torch.from_numpy(np.array([1]*num_sample)).long()

    tensor = torch.cat((tensor_1, tensor_2), 0)
    label = torch.cat((label_1, label_2), 0)

    return data_1, data_2, tensor_1, tensor_2, label


# make classifier
net = Net()
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.SGD(net.parameters(), 0.01)

# make dataset
mean_1 = [0, 0]
cov_1 = [[0.125, 0], [0, 0.125/6]]
mean_2 = [2, 0]
cov_2 = [[0.125, 0], [0, 0.125/6]]
num_sample = 500
data_1, data_2, train_tensor, train_label = make_dataset_cls(mean_1, cov_1, mean_2, cov_2, num_sample)
test_data_1, test_data_2, test_tensor, test_label = make_dataset_cls(mean_1, cov_1, mean_2, cov_2, num_sample)

# training classifier
epochs = 50
batch_size = 64
alpha = 10000.0
for epoch in range(epochs):
    data_1, data_2, train_tensor, train_label = make_dataset_cls(mean_1, cov_1, mean_2, cov_2, batch_size)
    hiddens, output = net(train_tensor)
    loss = criterion(output, train_label)
    loss_hsic = 0
    h_target = utils.to_categorical(train_label, num_classes=2).float()
    h_data = train_tensor.view(batch_size*2, -1)
    for hidden in hiddens:
        hidden = hidden.view(batch_size*2, -1)
        hxz_l, hyz_l = hsic.hsic_objective(
                hidden,
                h_target=h_target.float(),
                h_data=h_data,
                sigma=5.,
                ktype='linear'
            )
        loss_hsic += hyz_l
    loss = loss - alpha*loss_hsic
    loss.backward()
    optimizer.step()
    acc = (output.max(-1)[1] == train_label).float().mean().item()
    print('Training ...', epoch, loss, loss_hsic, acc)

net.eval()
test_hiddens, test_output = net(test_tensor)
test_acc = (test_output.max(-1)[1] == test_label).float().mean().item()
h_target = utils.to_categorical(test_label, num_classes=2).float()
h_data = test_tensor.view(num_sample*2, -1)
test_loss_hsic = 0
for hidden in test_hiddens:
    hidden = hidden.view(num_sample*2, -1)
    hxz_l, hyz_l = hsic.hsic_objective(
            hidden,
            h_target=h_target.float(),
            h_data=h_data,
            sigma=5.,
            ktype='linear'
        )
    test_loss_hsic += hyz_l
print("Testing ...", test_acc, "Test loss hsic", test_loss_hsic)

# Test 1st dimension
new_test_tensor = test_tensor.clone()
new_test_tensor[:,1] = 0
_, test_output = net(new_test_tensor)
h_data = new_test_tensor.view(num_sample*2, -1)
for hidden in test_hiddens:
    hidden = hidden.view(num_sample*2, -1)
    hxz_l, hyz_l = hsic.hsic_objective(
            hidden,
            h_target=h_target.float(),
            h_data=h_data,
            sigma=5.,
            ktype='linear'
        )
    test_loss_hsic += hyz_l
test_loss = criterion(test_output, test_label)
test_acc = (test_output.max(-1)[1] == test_label).float().mean().item()
print("1st Dimension Testing ...", test_acc, test_loss, "1st dimension hsic", test_loss_hsic)

# 2nd dimension testing
new_test_tensor = test_tensor.clone()
new_test_tensor[:, 0] = 0
_, test_output = net(new_test_tensor)
test_loss = criterion(test_output, test_label)
test_acc = (test_output.max(-1)[1] == test_label).float().mean().item()
h_data = new_test_tensor.view(num_sample*2, -1)
for hidden in test_hiddens:
    hidden = hidden.view(num_sample*2, -1)
    hxz_l, hyz_l = hsic.hsic_objective(
            hidden,
            h_target=h_target.float(),
            h_data=h_data,
            sigma=5.,
            ktype='linear'
        )
    test_loss_hsic += hyz_l
print("2nd Dimension Testing ...", test_acc, test_loss, "2nd dimension hsic", test_loss_hsic)
print(net.state_dict())

_, _, tensor_1, tensor_2, _ = make_dataset_cls_seperate(mean_1, cov_1, mean_2, cov_2, 10000)
hiddens_1, _ = net(tensor_1)
hiddens_2, _ = net(tensor_2)


x_1, y_1 = hiddens_1[-1].detach().numpy().T
x_2, y_2 = hiddens_2[-1].detach().numpy().T
plt.plot(x_1, y_1, 'o', color='r', alpha=1.0, label='0 label data')
plt.plot(x_2, y_2, 'o', color='g', alpha=1.0, label='1 label data')
# plt.plot(x_3, y_3, 'o', color='y', alpha=0.2, label='feature')
plt.xlabel('x')
plt.ylabel('y')
plt.legend()
plt.savefig("class_visual_1.png")
