import torch, os, engine, model, utils, sys
import model
from tqdm import tqdm
import time
from util import Bar, Logger, AverageMeter, accuracy
from engine import multilayer_hsic_test
import utils_GAN
import matplotlib.pyplot as plt
import numpy as np
from torch import nn
from torch.optim.lr_scheduler import MultiStepLR
from copy import deepcopy


class Member_Net(nn.Module):
    def __init__(self):
        super(Member_Net, self).__init__()
        # self.fc1 = nn.Linear(1000, 128)
        # self.fc2 = nn.Linear(128, 2)
        self.fc = nn.Linear(1000, 2)

    # x represents our data
    def forward(self, x):
        # x = self.fc1(x)
        # output = self.fc2(x)
        output = self.fc(x)
        return output

device = "cuda"
num_classes = 1000
# T = model.VGG16(num_classes, False)
T = model.VGG16(num_classes, True)
T = torch.nn.DataParallel(T).cuda()
dataset = 'celeba'
model_path = 'target_model'
# defense = 'reg'
# defense = 'reg_hsichyperparams'
defense = 'HSIC'
# path_T = os.path.join(model_path, dataset, defense, "VGG16_reg_hsichyperparams_85.01.tar")
# path_T = os.path.join(model_path, dataset, defense, "VGG16_reg_86.60.tar")
# path_T = os.path.join(model_path, dataset, defense, "VGG16_0.050&0.500_79.39.tar")
# path_T = os.path.join(model_path, dataset, defense, "Analysis/hp_list_((0.0, 0.0),)_lr_1e-2_SGD/VGG16_0.000&0.000_86.90.tar")
# path_T = os.path.join(model_path, dataset, defense, "Analysis/hp_list_((0.0, 0.0),)_lr_1e-4_Adam/VGG16_0.000&0.000_85.90.tar")
# path_T = os.path.join(model_path, dataset, defense, "Analysis/hp_list_((0.05, 0.5),)_lr_1e-4_Adam/VGG16_0.050&0.500_79.29.tar")
# path_T = os.path.join(model_path, dataset, defense, "Analysis/hp_list_((0.0, 0.0),)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.000_85.01_91.79_30.tar")
# path_T = os.path.join(model_path, dataset, defense, "Analysis/hp_list_((0.0, 0.0),)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.000_80.68_90.49_24.tar")
# path_T = os.path.join(model_path, dataset, defense, "Analysis/hp_list_((0.0, 0.0),)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.000_81.12_90.23_47.tar")
# path_T = os.path.join(model_path, dataset, defense, "Analysis_Member/hp_list_((0.0, 0.0),)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.000_80.22_90.19_37.tar")
path_T = os.path.join(model_path, dataset, defense, "Analysis/hp_list_((0, 0.1),)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.100_82.11_90.53_47.tar")
model_path = 'distribution_classification'
os.makedirs(model_path, exist_ok=True)


print(path_T)
ckp_T = torch.load(path_T)
T.load_state_dict(ckp_T['state_dict'], strict=True)

# Loading Dataset
loaded_args = utils.load_json(json_file='config/celeba.json')
model_name = loaded_args["dataset"]["model_name"]

train_file = loaded_args['dataset']['train_file']
test_file = loaded_args['dataset']['test_file']
bs = loaded_args[model_name]['batch_size']

trainloader = utils.init_dataloader(loaded_args, train_file, mode="train")
testloader = utils.init_dataloader(loaded_args, test_file, mode="test")
gan_dataset, gan_dataloader = utils_GAN.init_dataloader(loaded_args, "../attack_dataset/CelebA/ganset_dummylabel_1.txt", 64, mode="gan")
# gan_dataset, gan_dataloader = utils_GAN.init_dataloader(loaded_args, "../attack_dataset/CelebA/reference_set.txt", 64, mode="gan")



T.eval()
batch_time = AverageMeter()
data_time = AverageMeter()
losses = AverageMeter()
top1 = AverageMeter()
top5 = AverageMeter()
loss_cls = AverageMeter()
lxz, lyz = AverageMeter(), AverageMeter()
lxy = AverageMeter()
end = time.time()

criterion = torch.nn.CrossEntropyLoss().cuda()

member_net = Member_Net()
learning_rate = 0.1
# optimizer = torch.optim.Adam(member_net.parameters(), learning_rate)
weight_decay = loaded_args[model_name]["weight_decay"]
momentum = loaded_args[model_name]["momentum"]
optimizer = torch.optim.SGD(params=member_net.parameters(),
                                lr=learning_rate,
                                momentum=momentum,
                                weight_decay=weight_decay,
                                nesterov=True
                            )
scheduler = MultiStepLR(optimizer, [20, 40], gamma=0.2)
epochs = 50
member_net = torch.nn.DataParallel(member_net).cuda()
member_net.train()

best_ACC = 0
model_name = path_T.split('/')[-1]
for epoch in range(epochs):
    print('epoch {epoch:d}/{total:d}'.format(epoch=epoch, total=epochs))
    pbar = tqdm(enumerate(zip(trainloader, gan_dataloader)), total=len(trainloader), ncols=150)
    for batch_idx, (data_1, data_2) in pbar:
        data_time.update(time.time() - end)
        data_input, data_iden = data_1
        gan_data_input, _ = data_2

        data_input, data_iden, gan_data_input = data_input.to(device), data_iden.to(device), gan_data_input.to(device)

        _, data_out = T(data_input)
        data_out = torch.nn.Softmax(dim=1)(data_out)
        _, gan_data_out = T(gan_data_input)
        gan_data_out = torch.nn.Softmax(dim=1)(gan_data_out)
        data_label = torch.zeros(bs, dtype=torch.long)
        gan_label = torch.ones(bs, dtype=torch.long)

        data_member_out = member_net(data_out)
        gan_data_member_out = member_net(gan_data_out)

        output = torch.cat((data_member_out, gan_data_member_out), 0)
        label = torch.cat((data_label, gan_label), 0)
        label = label.to(device)

        cross_loss = criterion(output, label)

        optimizer.zero_grad()
        cross_loss.backward()
        optimizer.step()

        prec1 = accuracy(output.data, label.data, topk=(1,))[0]
        losses.update(cross_loss.item(), bs)
        top1.update(prec1.item())

        # plot progress
        msg = 'CE:{cls:.4f} | top1:{top1: .4f}'.format(
            cls=losses.avg,
            top1=top1.avg,
        )
        pbar.set_description(msg)
    if top1.avg > best_ACC:
        best_ACC = top1.avg
        best_model = deepcopy(member_net)
    print("best acc:", best_ACC)
utils.save_checkpoint({
    'state_dict': best_model.state_dict(),
}, model_path, "{}_{:.3f}.tar".format(model_name, best_ACC))

# Testing
batch_time = AverageMeter()
data_time = AverageMeter()
losses = AverageMeter()
top1 = AverageMeter()
top5 = AverageMeter()
loss_cls = AverageMeter()
lxz, lyz = AverageMeter(), AverageMeter()
lxy = AverageMeter()
end = time.time()
best_model.eval()
print('Testing {epoch:d}/{total:d}'.format(epoch=epoch, total=epochs))
pbar = tqdm(enumerate(zip(trainloader, gan_dataloader)), total=len(trainloader), ncols=150)
with torch.no_grad():
    for batch_idx, (data_1, data_2) in pbar:
        data_time.update(time.time() - end)
        data_input, data_iden = data_1
        gan_data_input, _ = data_2

        data_input, data_iden, gan_data_input = data_input.to(device), data_iden.to(device), gan_data_input.to(device)

        _, data_out = T(data_input)
        data_out = torch.nn.Softmax(dim=1)(data_out)
        _, gan_data_out = T(gan_data_input)
        gan_data_out = torch.nn.Softmax(dim=1)(gan_data_out)
        data_label = torch.zeros(bs, dtype=torch.long)
        gan_label = torch.ones(bs, dtype=torch.long)

        data_member_out = best_model(data_out)
        gan_data_member_out = best_model(gan_data_out)

        output = torch.cat((data_member_out, gan_data_member_out), 0)
        label = torch.cat((data_label, gan_label), 0)
        label = label.to(device)

        cross_loss = criterion(output, label)

        prec1 = accuracy(output.data, label.data, topk=(1,))[0]
        losses.update(cross_loss.item(), bs)
        top1.update(prec1.item())

        # plot progress
        msg = 'CE:{cls:.4f} | top1:{top1: .4f}'.format(
            cls=losses.avg,
            top1=top1.avg,
        )
        pbar.set_description(msg)


# pbar = tqdm(enumerate(trainloader), total=len(trainloader), ncols=150)
# with torch.no_grad():
#     for batch_idx, (inputs, iden) in pbar:
#         data_time.update(time.time() - end)

#         inputs, iden = inputs.to(device), iden.to(device)
#         bs = inputs.size(0)
#         iden = iden.view(-1)

#         loss, cross_loss, out_digit, hx_l_list, hy_l_list, hxy_l = multilayer_hsic_test(T, criterion, inputs, iden, 1, 1,
#                                                                             num_classes, 'linear', True, 'HSIC')

#         # measure accuracy and record loss

#         prec1, prec5 = accuracy(out_digit.data, iden.data, topk=(1, 5))
#         losses.update(loss.item(), bs)
#         loss_cls.update(cross_loss.item(), bs)
#         lxz.update(sum(hx_l_list) / len(hx_l_list), bs)
#         lyz.update(sum(hy_l_list) / len(hy_l_list), bs)
#         lxy.update(hxy_l, bs)

#         top1.update(prec1.item(), bs)
#         top5.update(prec5.item(), bs)

#         # measure elapsed time
#         batch_time.update(time.time() - end)
#         end = time.time()

#         # plot progress
#         msg = 'CE:{cls:.4f} | Lxz(down):{lxz:.5f} | Lyz(up):{lyz:.5f} | Lxy(out):{lxy:.5f}| Loss:{loss:.4f} | ' \
#                 'top1:{top1: .4f} | top5:{top5: .4f}'.format(
#             cls=loss_cls.avg,
#             lxz=lxz.avg,
#             lyz=lyz.avg,
#             lxy=lxy.avg,
#             loss=losses.avg,
#             top1=top1.avg,
#             top5=top5.avg,
#         )
#         pbar.set_description(msg)
# exit()
