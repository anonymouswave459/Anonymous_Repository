import torch, os, engine, model, utils, sys
import model
from tqdm import tqdm
import time
from util import Bar, Logger, AverageMeter, accuracy
from engine import multilayer_hsic_test
import utils_GAN

import torch.nn.functional as F
import torch.optim as optim
import numpy as np
import matplotlib.pyplot as plt


# FGSM attack code
def fgsm_attack(image, epsilon, data_grad):
    # Collect the element-wise sign of the data gradient
    sign_data_grad = data_grad.sign()
    # Create the perturbed image by adjusting each pixel of the input image
    perturbed_image = image + epsilon*sign_data_grad
    # Adding clipping to maintain [0,1] range
    perturbed_image = torch.clamp(perturbed_image, 0, 1)
    # Return the perturbed image
    return perturbed_image

def test(model, device, test_loader, epsilon ):

    # Accuracy counter
    correct = 0
    adv_examples = []

    # Loop over all examples in test set
    pbar = tqdm(enumerate(test_loader), total=len(test_loader), ncols=150)
    for batch_idx, (data, target)  in pbar:

        # Send the data and label to the device
        data, target = data.to(device), target.to(device)

        # Set requires_grad attribute of tensor. Important for Attack
        data.requires_grad = True

        # Forward pass the data through the model
        _, output = model(data)
        init_pred = output.max(1, keepdim=True)[1] # get the index of the max log-probability

        # If the initial prediction is wrong, dont bother attacking, just move on
        if init_pred.item() != target.item():
            continue

        # Calculate the loss
        loss = F.nll_loss(output, target)

        # Zero all existing gradients
        model.zero_grad()

        # Calculate gradients of model in backward pass
        loss.backward()

        # Collect datagrad
        data_grad = data.grad.data

        # Call FGSM Attack
        perturbed_data = fgsm_attack(data, epsilon, data_grad)

        # Re-classify the perturbed image
        _, output = model(perturbed_data)

        # Check for success
        final_pred = output.max(1, keepdim=True)[1] # get the index of the max log-probability
        if final_pred.item() == target.item():
            correct += 1
            # Special case for saving 0 epsilon examples
            if (epsilon == 0) and (len(adv_examples) < 5):
                adv_ex = perturbed_data.squeeze().detach().cpu().numpy()
                adv_examples.append( (init_pred.item(), final_pred.item(), adv_ex) )
        else:
            # Save some adv examples for visualization later
            if len(adv_examples) < 5:
                adv_ex = perturbed_data.squeeze().detach().cpu().numpy()
                adv_examples.append( (init_pred.item(), final_pred.item(), adv_ex) )
         # plot progress
        msg = 'Accuracy:{acc:.5f}'.format(
            acc=correct/float(len(test_loader))
        )
        pbar.set_description(msg)
    # Calculate final accuracy for this epsilon
    final_acc = correct/float(len(test_loader))
    print("Epsilon: {}\tTest Accuracy = {} / {} = {}".format(epsilon, correct, len(test_loader), final_acc))

    # Return the accuracy and an adversarial example
    return final_acc, adv_examples

# Defining
device = "cuda"
num_classes = 5
T = model.MCNN(5)
T = torch.nn.DataParallel(T).cuda()
dataset = 'mnist'
model_path = 'target_model'
defense = 'COCO'
# path_T = os.path.join(model_path, f"{dataset}", defense, "Analysis/hp_list_((0.0, 0.0),)_lr_1e-1_SGD/MCNN_0.000&0.000_99.92.tar")
# path_T = os.path.join(model_path, f"{dataset}", defense, "Analysis/hp_list_((1.0, 50.0),)_lr_1e-1_Adam/MCNN_1.000&50.000_99.61.tar")
path_T = os.path.join(model_path, f"{dataset}", defense, "MCNN_1.000&50.000_99.51.tar")



print(path_T)
ckp_T = torch.load(path_T)
T.load_state_dict(ckp_T['state_dict'], strict=True)

# Loading Dataset
loaded_args = utils.load_json(json_file='config/mnist.json')
model_name = loaded_args["dataset"]["model_name"]
train_file = loaded_args['dataset']['train_file']
test_file = loaded_args['dataset']['test_file']
# trainloader = utils.init_adv_dataloader(loaded_args, train_file, mode="test")
testloader = utils.init_adv_dataloader(loaded_args, test_file, mode="test")
# gan_dataset, gan_dataloader = utils_GAN.init_dataloader(loaded_args, "../attack_dataset/CelebA/ganset_dummylabel.txt", 64, mode="gan")

T.eval()
accuracies = []
examples = []
epsilons = [0.1, 0.15, 0.2]
# epsilons = [0.003]
# Run test for each epsilon
for eps in epsilons:
    acc, ex = test(T, device, testloader, eps)
    accuracies.append(acc)
    examples.append(ex)
print(accuracies)
