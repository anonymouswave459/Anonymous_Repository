import torch, os, engine, model, utils, sys
import torchvision
from torchvision.utils import save_image
import torchvision.transforms as transform
import model
from tqdm import tqdm
import time
from util import Bar, Logger, AverageMeter, accuracy
from engine import multilayer_hsic_test
import utils_GAN
import matplotlib.pyplot as plt
import numpy as np
from torchvision import datasets
from torch.utils.data import DataLoader


class ImageFolderWithPaths(datasets.ImageFolder):

    def __getitem__(self, index):
  
        img, label = super(ImageFolderWithPaths, self).__getitem__(index)
        
        path = self.imgs[index][0]
        
        return (img, label ,path)


evaluation = False
device = "cuda"
num_classes = 1000
dataset = 'celeba'
model_path = 'target_model'
# defense = 'reg'
# defense = 'reg_hsichyperparams'
defense = 'HSIC'

# path_T = os.path.join(model_path, dataset, defense, "Analysis/hp_list_((0.0, 0.0),)_lr_1e-2_SGD/VGG16_0.000&0.000_86.90.tar")
# path_T = os.path.join(model_path, dataset, defense, 'Analysis/hp_list_((0.0, 0.0),)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.000_85.01_91.79_30.tar')
path_T = os.path.join(model_path, dataset, defense, 'Analysis_1/hp_list_((0.05, 0.5),)_lr_1e-4_Adam_all_epochs/VGG16_0.050&0.500_79.85_90.33_47.tar')
# path_T = os.path.join(model_path, dataset, defense, 'Analysis_DiffAug/hp_list_((0, 0.1),)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.100_80.75_89.76_44.tar')
# path_T = os.path.join(model_path, dataset, defense, 'Analysis_1/hp_list_((0, 0.22),)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.220_80.55_89.20_41.tar')

target_label = 53

if evaluation:
    T = model.FaceNet_test(num_classes)
    T = torch.nn.DataParallel(T).cuda()
    eval_path = '../GMI/eval_model/'
    e_path = os.path.join(eval_path, "FaceNet_95.88.tar")
    ckp_E = torch.load(e_path)
    T.load_state_dict(ckp_E['state_dict'], strict=True)
    T.eval()
else:
    T = model.VGG16(num_classes, True)
    T = torch.nn.DataParallel(T).cuda()
    print("Loading from ...", path_T)
    ckp_T = torch.load(path_T)
    T.load_state_dict(ckp_T['state_dict'], strict=True)
    # print(T.state_dict().keys())

# Loading Dataset
loaded_args = utils.load_json(json_file='config/celeba.json')
model_name = loaded_args["dataset"]["model_name"]

train_file = loaded_args['dataset']['train_file']
test_file = loaded_args['dataset']['test_file']

# trainloader = utils.init_dataloader(loaded_args, train_file, mode="train")
# testloader = utils.init_dataloader(loaded_args, test_file, mode="test")
# gan_dataset, gan_dataloader = utils_GAN.init_dataloader(loaded_args, "../attack_dataset/CelebA/ganset_dummylabel_1.txt", 64, mode="gan")
# path_T = os.path.join(model_path, dataset, defense, 'Analysis_1/hp_list_((0.05, 0.5),)_lr_1e-4_Adam_all_epochs/VGG16_0.050&0.500_79.85_90.33_47.tar')
# path_T = os.path.join(model_path, dataset, defense, 'Analysis/hp_list_((0.0, 0.0),)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.000_85.01_91.79_30.tar')
print("Dataset ", path_T)
model_name = "VGG16"
dataset_name = "celeba"
save_img_dir = "../DMI/attack_res/"
model_name = path_T.split('/')[-3] + "_" + path_T.split('/')[-2] + "_" + model_name
save_img_dir = os.path.join(save_img_dir, dataset_name, defense, model_name)
all_img_dir = os.path.join(save_img_dir, 'Each_Class_Attack', 'Aug_all_class_53')
# success_img_dir = os.path.join(save_img_dir, 'res_success')
transform = torchvision.transforms.Compose([torchvision.transforms.ToTensor()])
dataset = ImageFolderWithPaths(all_img_dir, transform=transform)
# sucess_dataset = ImageFolderWithPaths(success_img_dir, transform=transform)
dataloader = DataLoader(dataset, batch_size=64, shuffle=False)
# dataloader = DataLoader(sucess_dataset, batch_size=64, shuffle=False)


# pbar = tqdm(enumerate(testloader), total=len(testloader), ncols=150)
pbar = tqdm(enumerate(dataloader), total=len(dataloader), ncols=150)
criterion = torch.nn.CrossEntropyLoss().cuda()

T.eval()
batch_time = AverageMeter()
data_time = AverageMeter()
losses = AverageMeter()
top1 = AverageMeter()
top5 = AverageMeter()
loss_cls = AverageMeter()
lxz, lyz = AverageMeter(), AverageMeter()
lxy = AverageMeter()
end = time.time()

h = w = 32
# w = 64
# h = 32
print("LABEL:", target_label)

with torch.no_grad():
    for i in range(1):
        pbar = tqdm(enumerate(dataloader), total=len(dataloader), ncols=150)
        count = 0
        if i % 50 ==0:
            print("Iteration", i)
        for batch_idx, (inputs, label, image_path) in pbar: 
            data_time.update(time.time() - end)
            idens = []
            for path in image_path:
                target = path.split('/')[-1].split('.')[0].split('_')[-2]
                image_name = path.split('/')[-1].split('.')[0]
                target = int(target)
                idens.append(target)
            iden = torch.Tensor(np.array(idens)).long()
            # if count == 5:
                # break
            # if iden!=target_label:
            #     continue
            # else:
            #     # print("Process Data", batch_idx, iden)
            #     count+=1

            inputs, iden = inputs.to(device), iden.to(device)
            bs = inputs.size(0)
            # iden = iden.view(-1)
            input_list = []
            for input in inputs:
                # input = torchvision.transforms.functional.erase(input, i=0, j=0, h=h, w=w, v=0)
                # input = torchvision.transforms.functional.erase(input, i=0, j=64-w, h=h, w=w, v=0)
                # input = torchvision.transforms.functional.erase(input, i=64-h, j=0, h=h, w=w, v=0)
                input = torchvision.transforms.functional.erase(input, i=64-h, j=64-w, h=h, w=w, v=0)
                # input = torchvision.transforms.functional.erase(input, i=0, j=0, h=64, w=w, v=0)
                # input = torchvision.transforms.functional.erase(input, i=32-int(h/2), j=32-int(w/2), h=h, w=w, v=1)
                # input = torchvision.transforms.functional.erase(input, i=32-int(h/2), j=32-int(w/2), h=h, w=w, v=0.5)
                # input = torchvision.transforms.functional.resized_crop(input, top=32-int(h/2), left=32-int(w/2), height=h,width=w, size=64)
                # input = torchvision.transforms.RandomErasing(p=1.0, scale=(0.1, 0.1), ratio=(1, 3), value=0, inplace=False)(input)
                # input = torchvision.transforms.GaussianBlur(kernel_size=(3, 3), sigma=(5, 5))(input)
                # input = torchvision.transforms.functional.adjust_sharpness(input, 10)
                # input = torchvision.transforms.ColorJitter(brightness=.5, hue=.3)(input)
                # input = torchvision.transforms.functional.resized_crop(input, top=32-int(h/2), left=32-int(w/2), height=h,width=w, size=64)
                input = torch.unsqueeze(input, 0)
                input_list.append(input)
            inputs = torch.cat(input_list, 0)
            
            if batch_idx == 0:
                save_image(inputs, 'train_images.png')
            # print(inputs.shape)
            # exit()
            if evaluation:
                input_tensor = inputs.to(device)
                input_tensor = utils.low2high(input_tensor)
                output = T(input_tensor)
                eval_iden = torch.argmax(output, dim=1).view(-1)

                prec1, prec5 = accuracy(output.data, iden.data, topk=(1, 5))
                loss = criterion(output, iden)
                losses.update(loss.item(), bs)
                top1.update(prec1.item(), bs)
                top5.update(prec5.item(), bs)
                # plot progress
                msg = 'Loss:{loss:.4f} | ' \
                        'top1:{top1: .4f} | top5:{top5: .4f}'.format(
                    loss=losses.avg,
                    top1=top1.avg,
                    top5=top5.avg,
                )
                pbar.set_description(msg)
            else:
                loss, cross_loss, out_digit, hx_l_list, hy_l_list, hxy_l = multilayer_hsic_test(T, criterion, inputs, iden, 1, 1, num_classes, 'linear', True, 'HSIC')

                # measure accuracy and record loss

                prec1, prec5 = accuracy(out_digit.data, iden.data, topk=(1, 5))
                losses.update(loss.item(), bs)
                loss_cls.update(cross_loss.item(), bs)
                lxz.update(sum(hx_l_list) / len(hx_l_list), bs)
                lyz.update(sum(hy_l_list) / len(hy_l_list), bs)
                lxy.update(hxy_l, bs)

                top1.update(prec1.item(), bs)
                top5.update(prec5.item(), bs)

                # measure elapsed time
                batch_time.update(time.time() - end)
                end = time.time()

                # plot progress
                msg = 'CE:{cls:.4f} | Lxz(down):{lxz:.5f} | Lyz(up):{lyz:.5f} | Lxy(out):{lxy:.5f}| Loss:{loss:.4f} | ' \
                        'top1:{top1: .4f} | top5:{top5: .4f}'.format(
                    cls=loss_cls.avg,
                    lxz=lxz.avg,
                    lyz=lyz.avg,
                    lxy=lxy.avg,
                    loss=losses.avg,
                    top1=top1.avg,
                    top5=top5.avg,
                )
                pbar.set_description(msg)
    if not evaluation:
        print("MI(x, z)", hx_l_list, lxz.avg)
        print("MI(z, y)", hy_l_list, lyz.avg)
        print("MI(x, y", lxy.avg)
    print("top 1", top1.avg)
    print("top 5", top5.avg)

