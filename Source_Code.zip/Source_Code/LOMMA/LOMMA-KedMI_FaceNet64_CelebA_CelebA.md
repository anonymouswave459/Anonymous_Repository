### CVPR_analysis_checkpoints/target_ckp_random_erasing_0.0_0.0_1_2/FaceNet64_87.47_allclass.tar
Method: kedmi 
Variant: ours
Top 1 attack accuracy:87.20 +/- 1.11 
Top 5 attack accuracy:98.33 +/- 0.33 
KNN distance: 1178.005
FID score: 36.651

### CVPR_analysis_checkpoints/target_ckp_random_erasing_0.05_0.05_1_2/FaceNet64_86.54_allclass.tar
Method: kedmi 
Variant: ours
Top 1 attack accuracy:85.67 +/- 1.31 
Top 5 attack accuracy:96.00 +/- 0.63 
KNN distance: 1200.094
FID score: 40.653

### CVPR_analysis_checkpoints/target_ckp_random_erasing_0.1_0.1_1_2/FaceNet64_87.17_allclass.tar

### CVPR_analysis_checkpoints/target_ckp_random_erasing_0.2_0.2_1_2/FaceNet64_82.65_allclass.tar

### CVPR_analysis_checkpoints/target_ckp_random_erasing_0.3_0.3_1_2/FaceNet64_80.19_allclass.tar


