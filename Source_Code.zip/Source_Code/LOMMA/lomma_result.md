# LOMMA-KedMI/CelebA/CelebA
# ../Defense_MI/BiDO/target_model/celeba/vib/VGG16_vib_beta0.003_77.99.tar
Top 1 attack accuracy:59.27 +/- 2.74 
Top 5 attack accuracy:87.00 +/- 1.18 
KNN distance: 1376.563
FID 37.61
# ../PLG_MI/baselines/checkpoints/target_ckp_random_erasing_0.2_0.2_1_1/IR152_87.87_allclass.tar
Method: kedmi 
Variant: ours
Top 1 attack accuracy:70.60 +/- 1.94 
Top 5 attack accuracy:91.00 +/- 1.38 
KNN distance: 1358.279
Method: kedmi 
Variant: ours
Top 1 attack accuracy:69.20 +/- 1.59 
Top 5 attack accuracy:86.67 +/- 1.50 
KNN distance: 1345.407
FID score: 43.466

# Adaptive ../PLG_MI/baselines/checkpoints/target_ckp_random_erasing_0.2_0.2_1_1/IR152_87.87_allclass.tar
Method: kedmi 
Variant: ours
Top 1 attack accuracy:69.73 +/- 2.12 
Top 5 attack accuracy:92.33 +/- 0.78 
KNN distance: 1348.370
FID score: 42.565

## /home/hung/PLG_MI/baselines/checkpoints/target_ckp_random_erasing_0.1_0.3_1_1_meansub/IR152_88.24_allclass.tar
Method: kedmi 
Variant: ours
Top 1 attack accuracy:70.00 +/- 2.02 
Top 5 attack accuracy:89.67 +/- 1.49 
KNN distance: 1367.899
FID score: 41.365

## /home/hung/PLG_MI/baselines/checkpoints/target_ckp_random_erasing_0.1_0.4_1_1_meansub/IR152_84.91_allclass.tar
Method: kedmi 
Variant: ours
Top 1 attack accuracy:52.13 +/- 1.81 
Top 5 attack accuracy:79.00 +/- 1.74 
KNN distance: 1481.698
FID score: 42.980

## /home/hung/PLG_MI/baselines/checkpoints/target_ckp_random_erasing_0.1_0.5_1_1_meansub/IR152_82.85_allclass.tar
Method: kedmi 
Variant: ours
Top 1 attack accuracy:48.33 +/- 1.91 
Top 5 attack accuracy:77.00 +/- 1.44 
KNN distance: 1478.918
FID score: 47.404


# ../PLG_MI/baselines/checkpoints/target_ckp_random_erasing_0.2_0.2_1_1/FaceNet64_83.72_allclass.tar
Top 1 attack accuracy:67.53 +/- 1.64 
Top 5 attack accuracy:88.00 +/- 0.75 
KNN distance: 1393.562

# ../PLG_MI/baselines/checkpoints/target_ckp_random_erasing_0.2_0.2_1_1/VGG16_MIDRE_0.2_1_0.050&0.100_83.88.tar
Top 1 attack accuracy:54.27 +/- 1.99 
Top 5 attack accuracy:79.67 +/- 1.26 
KNN distance: 1452.702

# ../PLG_MI/baselines/checkpoints/target_ckp_random_erasing_0.2_0.2_1_1_randomsub/IR152_86.81_allclass.tar
<!-- Method: kedmi 
Variant: ours
Top 1 attack accuracy:69.87 +/- 1.52 
Top 5 attack accuracy:90.33 +/- 1.26 
KNN distance: 1349.926
FID score: 42.836 -->
Method: kedmi 
Variant: ours
Top 1 attack accuracy:66.73 +/- 1.65 
Top 5 attack accuracy:88.00 +/- 1.04 
KNN distance: 1374.097
FID score: 42.950

# ../PLG_MI/baselines/checkpoints/target_ckp_random_erasing_0.2_0.2_1_1_1sub/IR152_88.50_allclass.tar
Method: kedmi 
Variant: ours
Top 1 attack accuracy:65.40 +/- 1.68 
Top 5 attack accuracy:89.00 +/- 1.28 
KNN distance: 1335.145
FID score: 39.334

# ../PLG_MI/baselines/checkpoints/target_ckp_random_erasing_0.2_0.2_1_1_meansub/IR152_88.40_allclass.tar
Method: kedmi 
Variant: ours
Top 1 attack accuracy:67.73 +/- 1.75 
Top 5 attack accuracy:87.67 +/- 1.32 
KNN distance: 1365.010
FID score: 40.764

# LOMMA-GMI/CelebA/CelebA
# ../PLG_MI/baselines/checkpoints/target_ckp_random_erasing_0.2_0.2_1_1/IR152_87.87_allclass.tar
Top 1 attack accuracy:52.47 +/- 7.26 
Top 5 attack accuracy:83.67 +/- 6.94 
KNN distance: 1471.724

# ../PLG_MI/baselines/checkpoints/target_ckp_random_erasing_0.2_0.2_1_1/FaceNet64_83.72_allclass.tar
Top 1 attack accuracy:52.40 +/- 5.81 
Top 5 attack accuracy:79.67 +/- 4.35 
KNN distance: 1495.849



