### GAN Training
```
CUDA_VISIBLE_DEVICES=0 python train_gan.py --configs ./config/celeba/training_GAN/specific_gan/celeba.json --mode "specific"
```

### 3. Learn augmented models
```
CUDA_VISIBLE_DEVICES=0 python train_augmented_model.py --configs ./config/celeba/training_augmodel/celeba.json
CUDA_VISIBLE_DEVICES=0 python train_augmented_model.py --configs ./config/celeba/training_augmodel/ffhq.json

```

### 4. Model Inversion Attack
```
<!-- Modify save path -->
<!-- Modify GAN path -->
<!-- Modify target model path -->
<!-- Modify aug model path -->
rm -rf checkpoints/p_reg/
CUDA_VISIBLE_DEVICES=0 python recovery.py --configs ./config/celeba/attacking/celeba.json

CUDA_VISIBLE_DEVICES=0 python adaptive_recovery.py --configs ./config/celeba/attacking/celeba.json
CUDA_VISIBLE_DEVICES=0 python recovery.py --configs ./config/celeba/attacking/ffhq.json

```


### 5. Evaluation
```
CUDA_VISIBLE_DEVICES=0 python evaluation.py --configs ./config/celeba/attacking/celeba.json
CUDA_VISIBLE_DEVICES=0 python evaluation.py --configs ./config/celeba/attacking/ffhq.json

```
