python top_n_selection.py --model=VGG16 --data_name=celeba --top_n=30 --save_root=reclassified_public_data_RE_BiDO

python train_cgan.py \
--data_name=celeba \
--target_model=VGG16 \
--calc_FID \
--inv_loss_type=margin \
--max_iteration=30000 \
--alpha=0.2 \
--private_data_root=./datasets/celeba_private_domain \
--data_root=./reclassified_public_data_RE_BiDO/celeba/VGG16_top30 \
--results_root=PLG_MI_Results_RE_BiDO

rm -rf PLG_MI_Inversion_BiDO/
python reconstruct.py \
--model=VGG16 \
--inv_loss_type=margin \
--lr=0.1 \
--iter_times=600 \
--path_G=./PLG_MI_Results_RE_BiDO/celeba/VGG16/gen_latest.pth.tar \
--save_dir=PLG_MI_Inversion_BiDO
