### CelebA -> CelebA
### checkpoints/target_ckp_random_erasing_0.1_0.4_1_2/FaceNet64_82.02_allclass.tar
Average Acc:50.47       Average Acc5:76.13      Average Acc_var:5.4398  Average Acc_var5:4.2365
KNN Dist 1509.22
FID 26.10

### FFHQ -> CelebA
### checkpoints/target_ckp_random_erasing_0.1_0.4_1_2/FaceNet64_82.02_allclass.tar
Average Acc:17.00       Average Acc5:40.00      Average Acc_var:3.7479  Average Acc_var5:5.1691
KNN Dist 1729.02
FID 58.60

