# CelebA
# ../../Defense_MI/BiDO/target_model/celeba/vib/VGG16_vib_beta0.003_77.99.tar
Average Acc:56.20       Average Acc5:85.33      Average Acc_var:4.4601  Average Acc_var5:3.3012
KNN Dist 1346.56s
42.30

# FFHQ
# ../../Defense_MI/BiDO/target_model/celeba/vib/VGG16_vib_beta0.003_77.99.tar
Average Acc:25.73       Average Acc5:52.33      Average Acc_var:3.9520  Average Acc_var5:3.1867
KNN Dist 1606.22
FID 75.93
# checkpoints/target_ckp_random_erasing_0.2_0.2_1_1/VGG16_MIDRE_0.2_1_0.050&0.100_83.88.tar
Average Acc:11.27       Average Acc5:27.33      Average Acc_var:14.0000 Average Acc_var5:15.2778
KNN Dist 1765.53
FID 67.14

