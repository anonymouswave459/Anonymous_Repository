# Public Dataset: CelebA
# ./checkpoints/NoDef_VGG16_0.000&0.000_86.90.tar
Average Acc:20.07       Average Acc5:42.67      Average Acc_var:5.4624  Average Acc_var5:6.6962
KNN Dist 1679.18
FID 31.61
# ./checkpoints/BiDO_VGG16_0.050&0.500_79.85_90.33_47.tar
Average Acc:6.13        Average Acc5:17.67      Average Acc_var:2.9771  Average Acc_var5:4.8019
KNN Dist 1927.11
FID 31.36
# ./checkpoints/Random_Erasing_VGG16_0.000&0.000_80.25_89.76_44.tar
Average Acc:4.40        Average Acc5:13.60      Average Acc_var:2.4281  Average Acc_var5:3.3793
KNN Dist 1958.99
FID 31.17
# ../../Defense_MI/BiDO/target_model/celeba/vib/VGG16_vib_beta0.003_77.99.tar
Average Acc:17.00       Average Acc5:36.60      Average Acc_var:3.7913  Average Acc_var5:5.0547
KNN Dist 1728.39
FID 37.88
# checkpoints/target_ckp_random_erasing_0.2_0.2_1_1/VGG16_MIDRE_0.2_1_0.050&0.100_83.88.tar
Average Acc:5.67        Average Acc5:15.40      Average Acc_var:8.0000  Average Acc_var5:15.2778
KNN Dist 1957.47
FID 61.67


# Public Dataset: FFHQ
# ./checkpoints/NoDef_VGG16_0.000&0.000_86.90.tar
Average Acc:8.67        Average Acc5:23.47      Average Acc_var:2.1520  Average Acc_var5:5.1647
KNN Dist 1800.29
FID 51.46
# ./checkpoints/BiDO_VGG16_0.050&0.500_79.85_90.33_47.tar
Average Acc:2.87        Average Acc5:8.20       Average Acc_var:2.0241  Average Acc_var5:3.0894
KNN Dist 2009.52
FID 72.79
# ./checkpoints/Random_Erasing_VGG16_0.000&0.000_80.25_89.76_44.tar
Average Acc:1.53        Average Acc5:6.67       Average Acc_var:1.3701  Average Acc_var5:3.4520
KNN Dist 2028.99
FID 65.57
# ../../Defense_MI/BiDO/target_model/celeba/vib/VGG16_vib_beta0.003_77.99.tar
Average Acc:6.67        Average Acc5:18.87      Average Acc_var:2.4932  Average Acc_var5:3.7786
KNN Dist 1840.91
FID 60.23

# Public Dataset: FaceScrub
# ./checkpoints/NoDef_VGG16_0.000&0.000_86.90.tar
Average Acc:0.00        Average Acc5:0.02       Average Acc_var:0.0000  Average Acc_var5:0.0002
KNN Dist 2213.55
FID 294.16
# ./checkpoints/BiDO_VGG16_0.050&0.500_79.85_90.33_47.tar
Average Acc:0.00        Average Acc5:0.01       Average Acc_var:0.0000  Average Acc_var5:0.0001
KNN Dist 2305.85
FID 429.91
# ./checkpoints/Random_Erasing_VGG16_0.000&0.000_80.25_89.76_44.tar
Average Acc:0.00        Average Acc5:0.01       Average Acc_var:0.0000  Average Acc_var5:0.0002
KNN Dist 2339.01
FID 396.84
