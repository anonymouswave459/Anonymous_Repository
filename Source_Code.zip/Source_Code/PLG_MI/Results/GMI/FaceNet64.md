# Celeba -> Celeba
# ./target_model/FaceNet64_88.50.tar
Average Acc:29.60       Average Acc5:54.00      Average Acc_var:5.4311  Average Acc_var5:5.5494
KNN Dist 1607.86
FID 27.71
# baselines/checkpoints/target_ckp_bido/FaceNet64_69.25_allclass.tar
# baselines/checkpoints/target_ckp_random_erasing_0.1_0.75_1_1/FaceNet64_72.01_allclass.tar
Average Acc:3.40        Average Acc5:12.13      Average Acc_var:2.3786  Average Acc_var5:3.6547
KNN Dist 1991.68
FID 65.39
# checkpoints/target_ckp_random_erasing_0.1_0.4_1_2/FaceNet64_82.02_allclass.tar
Average Acc:7.47        Average Acc5:21.60      Average Acc_var:4.0632  Average Acc_var5:5.8897
KNN Dist 1843.41
FID 58.84

# FFHQ -> Celeba
# ./target_model/FaceNet64_88.50.tar
Average Acc:12.93       Average Acc5:29.67      Average Acc_var:4.6976  Average Acc_var5:4.9057
KNN Dist 1773.66
FID 55.43
# baselines/checkpoints/target_ckp_bido/FaceNet64_69.25_allclass.tar
# baselines/checkpoints/target_ckp_random_erasing_0.1_0.75_1_1/FaceNet64_72.01_allclass.tar
Average Acc:1.00        Average Acc5:3.67       Average Acc_var:0.8794  Average Acc_var5:2.2049
KNN Dist 2109.27
FID 106.67
# checkpoints/target_ckp_random_erasing_0.1_0.4_1_2/FaceNet64_82.02_allclass.tar
Average Acc:3.07        Average Acc5:10.27      Average Acc_var:1.9092  Average Acc_var5:3.7725
KNN Dist 1965.68
FID 73.97


# FaceScrub -> Celeba
# ./target_model/FaceNet64_88.50.tar
Average Acc:12.93       Average Acc5:29.67      Average Acc_var:4.6976  Average Acc_var5:4.9057


# baselines/checkpoints/target_ckp_bido/FaceNet64_69.25_allclass.tar
# ./baselines/checkpoints/target_ckp_random_erasing_0.1_0.75_1_1/FaceNet64_72.01_allclass.tar
# ./baselines/checkpoints/target_ckp_random_erasing_0.1_0.4_1_2/FaceNet64_82.65_allclass.tar



