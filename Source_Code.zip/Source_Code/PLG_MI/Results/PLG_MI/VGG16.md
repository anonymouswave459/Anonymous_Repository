# Celeba -> Celeba
# baselines/checkpoints/NoDef_VGG16_0.000&0.000_86.90.tar
Average Acc:97.47       Average Acc5:99.80      Average Acc_var:1.6759  Average Acc_var5:0.3316
KNN Dist 1149.67
FID 18.02
# baselines/checkpoints/BiDO_VGG16_0.050&0.500_79.85_90.33_47.tar
Average Acc:92.40       Average Acc5:99.20      Average Acc_var:1.7352  Average Acc_var5:0.9757
KNN Dist 1228.36
FID 21.91
# baselines/checkpoints/Cutout_0.75_VGG16_0.000&0.000_82.28_91.39_46.tar
Average Acc:0.84        Average Acc5:0.95       Average Acc_var:0.0006  Average Acc_var5:0.0003
KNN Dist 1366.84
FID 28.23
# baselines/checkpoints/Random_Erasing_VGG16_0.000&0.000_80.25_89.76_44.tar
Average Acc:77.13       Average Acc5:92.80      Average Acc_var:2.7811  Average Acc_var5:1.7808
KNN Dist 1374.62
FID 22.60
## /home/hung/PLG_MI/baselines/checkpoints/target_ckp_random_erasing_0.1_0.4_1_1_meansub/VGG16_0.000&0.000_79.85.tar
Average Acc:66.60       Average Acc5:86.40      Average Acc_var:2.9430  Average Acc_var5:2.2098
KNN Dist 1475.76
FID 26.33

# FFHQ -> Celeba
# baselines/checkpoints/NoDef_VGG16_0.000&0.000_86.90.tar
Average Acc:81.80       Average Acc5:94.73      Average Acc_var:2.7366  Average Acc_var5:1.6463
KNN Dist 1323.27
FID 18.73
# baselines/checkpoints/BiDO_VGG16_0.050&0.500_79.85_90.33_47.tar
Average Acc:60.93       Average Acc5:82.80      Average Acc_var:3.9869  Average Acc_var5:2.8231
KNN Dist 1440.16
FID 25.19
# baselines/checkpoints/Cutout_0.75_VGG16_0.000&0.000_82.28_91.39_46.tar
Average Acc:0.50        Average Acc5:0.76       Average Acc_var:0.0023  Average Acc_var5:0.0007
KNN Dist 1553.19
FID 33.36
# baselines/checkpoints/Random_Erasing_VGG16_0.000&0.000_80.25_89.76_44.tar
Average Acc:45.73       Average Acc5:72.53      Average Acc_var:4.8499  Average Acc_var5:3.9549
KNN Dist 1558.52
FID 32.14
# ../../Defense_MI/BiDO/target_model/celeba/vib/VGG16_vib_beta0.003_77.99.tar
Average Acc:63.87       Average Acc5:85.33      Average Acc_var:5.0210  Average Acc_var5:2.5873
KNN Dist 1403.12
FID 23.12
# checkpoints/target_ckp_random_erasing_0.2_0.2_1_1/VGG16_MIDRE_0.2_1_0.050&0.100_83.88.tar
Average Acc:50.80       Average Acc5:76.73      Average Acc_var:4.4429  Average Acc_var5:2.4767
KNN Dist 1564.51
FID 32.47
## /home/hung/PLG_MI/baselines/checkpoints/target_ckp_random_erasing_0.1_0.4_1_1_meansub/VGG16_0.000&0.000_79.85.tar
Average Acc:36.07       Average Acc5:62.73      Average Acc_var:4.7640  Average Acc_var5:4.8212
KNN Dist 1654.41
FID 37.22

# FaceScrub -> Celeba
# baselines/checkpoints/NoDef_VGG16_0.000&0.000_86.90.tar
Average Acc:0.15        Average Acc5:0.32       Average Acc_var:0.0005  Average Acc_var5:0.0003
KNN Dist 1702.50
FID 109.44
# baselines/checkpoints/BiDO_VGG16_0.050&0.500_79.85_90.33_47.tar
Average Acc:0.10        Average Acc5:0.26       Average Acc_var:0.0004  Average Acc_var5:0.0000
KNN Dist 1822.60
FID 167.26
# baselines/checkpoints/Cutout_0.75_VGG16_0.000&0.000_82.28_91.39_46.tar
Average Acc:0.11        Average Acc5:0.26       Average Acc_var:0.0005  Average Acc_var5:0.0008
KNN Dist 1909.84
FID 165.17
# baselines/checkpoints/Random_Erasing_VGG16_0.000&0.000_80.25_89.76_44.tar
Average Acc:0.08        Average Acc5:0.22       Average Acc_var:0.0002  Average Acc_var5:0.0002
KNN Dist 1920.27
FID 143.59
