# /home/hung/PLG_MI/baselines/checkpoints/target_ckp_random_erasing_0.2_0.2_1_1_meansub/FaceNet64_85.14_allclass.tar



