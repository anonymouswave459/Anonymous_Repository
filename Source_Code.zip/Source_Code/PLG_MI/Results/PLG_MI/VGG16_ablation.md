## /home/hung/PLG_MI/baselines/checkpoints/target_ckp_random_erasing_0.05_0.05_1_1_meansub/VGG16_0.000&0.000_85.74.tar
Average Acc:95.93       Average Acc5:98.87      Average Acc_var:0.9342  Average Acc_var5:0.7164
KNN Dist 1147.77
FID 17.75
## /home/hung/PLG_MI/baselines/checkpoints/target_ckp_random_erasing_0.1_0.1_1_1_meansub/VGG16_0.000&0.000_84.71.tar
Average Acc:95.07       Average Acc5:99.73      Average Acc_var:1.2503  Average Acc_var5:0.4807
KNN Dist 1163.54
FID 20.06
## /home/hung/PLG_MI/baselines/checkpoints/target_ckp_random_erasing_0.2_0.2_1_1_meansub/VGG16_0.000&0.000_82.98.tar
Average Acc:82.00       Average Acc5:96.33      Average Acc_var:3.8080  Average Acc_var5:1.5261
KNN Dist 1344.40
FID 20.49

## /home/hung/PLG_MI/baselines/checkpoints/target_ckp_random_erasing_0.3_0.3_1_1_meansub/VGG16_0.000&0.000_79.52.tar
Average Acc:68.40       Average Acc5:89.27      Average Acc_var:3.7652  Average Acc_var5:2.7770
KNN Dist 1437.17
FID 25.11

## home/hung/PLG_MI/baselines/checkpoints/Analysis_Random_Erasing_0.4_0.4_1_1_meansub/hp_list_((0, 0),)_milestones_(40,)_lr_1e-4_Adam_all_epochs/VGG16_0.000&0.000_74.14.tar
Average Acc:46.00       Average Acc5:72.00      Average Acc_var:4.7255  Average Acc_var5:2.8556

## /home/hung/PLG_MI/baselines/checkpoints/target_ckp_random_erasing_0.5_0.5_1_1_meansub/VGG16_0.000&0.000_68.38.tar
Average Acc:31.80       Average Acc5:56.33      Average Acc_var:3.8159  Average Acc_var5:4.5094

