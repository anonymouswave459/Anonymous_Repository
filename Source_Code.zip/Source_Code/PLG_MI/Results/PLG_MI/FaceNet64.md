# Celeba -> Celeba
# ./target_model/FaceNet64_88.50.tar
Average Acc:99.47       Average Acc5:99.87      Average Acc_var:0.6829  Average Acc_var5:0.2981
KNN Dist 1091.51
FID 19.30
# baselines/checkpoints/target_ckp_bido/FaceNet64_69.25_allclass.tar
Average Acc:0.79        Average Acc5:0.93       Average Acc_var:0.0013  Average Acc_var5:0.0003
KNN Dist 1294.52
FID 25.53
# baselines/checkpoints/target_ckp_random_erasing_0.1_0.75_1_1/FaceNet64_72.01_allclass.tar
Average Acc:41.93       Average Acc5:67.47      Average Acc_var:4.5911  Average Acc_var5:2.8912
KNN Dist 1675.83
FID 36.78
# ./baselines/checkpoints/target_ckp_random_erasing_0.2_0.2_1_1/FaceNet64_83.72_allclass.tar
Average Acc:89.67       Average Acc5:97.47      Average Acc_var:3.7447  Average Acc_var5:1.4665
KNN Dist 1364.09
FID 18.89
## /content/drive/MyDrive/Model_Inversion/checkpoints/target_models/target_ckp_random_erasing_0.1_0.4_1_1_meansub/FaceNet64_81.56_allclass.tar
Average Acc:75.00	Average Acc5:90.73	Average Acc_var:4.2976	Average Acc_var5:2.8905
KNN Dist 1509.78
FID 27.98


# FFHQ -> Celeba
# ./target_model/FaceNet64_88.50.tar
Average Acc:95.00       Average Acc5:99.20      Average Acc_var:2.5612  Average Acc_var5:0.7931
KNN Dist 1250.90
FID 17.74
# baselines/checkpoints/target_ckp_bido/FaceNet64_69.25_allclass.tar
Acc:0.29        Acc_5:0.51      Acc_var:0.0024  Acc_var5:0.0034
KNN Dist 1692.62
FID 43.15
# baselines/checkpoints/target_ckp_random_erasing_0.1_0.75_1_1/FaceNet64_72.01_allclass.tar
Average Acc:19.53       Average Acc5:39.13      Average Acc_var:3.2761  Average Acc_var5:4.4979
KNN Dist 1834.21
FID 61.25
# ./baselines/checkpoints/target_ckp_random_erasing_0.2_0.2_1_1/FaceNet64_83.72_allclass.tar
Average Acc:59.80       Average Acc5:82.07      Average Acc_var:4.9910  Average Acc_var5:3.9443
KNN Dist 1553.22
FID 31.20
Average Acc:69.20       Average Acc5:88.73      Average Acc_var:2.6369  Average Acc_var5:3.2501
KNN Dist 1503.29
FID 27.03
# Adaptive ./baselines/checkpoints/target_ckp_random_erasing_0.2_0.2_1_1/FaceNet64_83.72_allclass.tar
Average Acc:68.07       Average Acc5:87.40      Average Acc_var:5.7325  Average Acc_var5:2.7328
KNN Dist 1499.85
FID 30.47
Average Acc:69.13       Average Acc5:87.73      Average Acc_var:3.3042  Average Acc_var5:3.1256
KNN Dist 1495.28
FID 31.52

## /home/hung/PLG_MI/baselines/checkpoints/target_ckp_random_erasing_0.1_0.3_1_1_meansub/FaceNet64_83.55_allclass.tar
Average Acc:65.07       Average Acc5:85.00      Average Acc_var:4.0217  Average Acc_var5:2.8750
KNN Dist 1501.85
FID 30.33

## /home/hung/PLG_MI/baselines/checkpoints/target_ckp_random_erasing_0.1_0.4_1_1_meansub/FaceNet64_81.56_allclass.tar
Average Acc:51.60       Average Acc5:74.07      Average Acc_var:3.6088  Average Acc_var5:3.2358
KNN Dist 1625.36
FID 31.15

## /home/hung/PLG_MI/baselines/checkpoints/target_ckp_random_erasing_0.1_0.5_1_1_meansub/FaceNet64_78.50_allclass.tar
Average Acc:45.40	Average Acc5:70.00	Average Acc_var:3.8496	Average Acc_var5:3.4720
KNN Dist 1663.81


# ./baselines/checkpoints/target_ckp_random_erasing_0.2_0.2_1_1_randomsub/FaceNet64_80.76_allclass.tar
Average Acc:51.87       Average Acc5:76.47      Average Acc_var:4.4255  Average Acc_var5:3.2863
KNN Dist 1603.89
FID 29.85
# ./baselines/checkpoints/target_ckp_random_erasing_0.2_0.2_1_1_1sub/FaceNet64_83.68_allclass.tar
Average Acc:70.00       Average Acc5:88.00      Average Acc_var:3.1769  Average Acc_var5:3.4188
KNN Dist 1537.65
FID 23.72
# ./baselines/checkpoints/target_ckp_random_erasing_0.2_0.2_1_1_meansub/FaceNet64_85.14_allclass.tar
Average Acc:68.87       Average Acc5:89.60      Average Acc_var:3.9650  Average Acc_var5:2.9379
KNN Dist 1491.82
FID 28.28

# FaceScrub -> Celeba
# ./target_model/FaceNet64_88.50.tar
Average Acc:0.42        Average Acc5:0.69       Average Acc_var:0.0009  Average Acc_var5:0.0006
KNN Dist 1617.04
FID 71.03
# baselines/checkpoints/target_ckp_bido/FaceNet64_69.25_allclass.tar
Average Acc:0.04        Average Acc5:0.12       Average Acc_var:0.0002  Average Acc_var5:0.0004
KNN Dist 1923.31
FID 207.87
# ./baselines/checkpoints/target_ckp_random_erasing_0.1_0.75_1_1/FaceNet64_72.01_allclass.tar
Average Acc:0.05        Average Acc5:0.16       Average Acc_var:0.0002  Average Acc_var5:0.0009
KNN Dist 1999.02
FID 171.89
# ./baselines/checkpoints/target_ckp_random_erasing_0.1_0.4_1_2/FaceNet64_82.65_allclass.tar



