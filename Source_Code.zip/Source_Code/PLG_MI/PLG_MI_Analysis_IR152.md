FFHQ -> CelebA
# baselines/checkpoints/target_ckp_random_erasing_0.0_0.0_1_2/IR152_89.66_allclass.tar
# baselines/checkpoints/target_ckp_random_erasing_0.05_0.05_1_2/IR152_92.12_allclass.tar
# baselines/checkpoints/target_ckp_random_erasing_0.1_0.1_1_2/IR152_89.66_allclass.tar
Average Acc:91.93       Average Acc5:98.53      Average Acc_var:2.7663  Average Acc_var5:1.3844
KNN Dist 1292.03
FID 23.13
# baselines/checkpoints/target_ckp_random_erasing_0.2_0.2_1_2/IR152_80.82_allclass.tar
# baselines/checkpoints/target_ckp_random_erasing_0.3_0.3_1_2/IR152_82.49_allclass.tar

