# CelebA -> CelebA
# ./baselines/checkpoints/target_ckp_random_erasing_0.0_0.0_1_2/FaceNet64_87.47_allclass.tar
Average Acc:73.13       Average Acc5:94.33      Average Acc_var:4.7992  Average Acc_var5:2.5844
KNN Dist 1321.82
FID 24.53
# ./baselines/checkpoints/target_ckp_random_erasing_0.05_0.05_1_2/FaceNet64_86.54_allclass.tar
# ./baselines/checkpoints/target_ckp_random_erasing_0.1_0.1_1_2/FaceNet64_87.17_allclass.tar
# ./baselines/checkpoints/target_ckp_random_erasing_0.2_0.2_1_2/FaceNet64_82.65_allclass.tar
Average Acc:52.13       Average Acc5:78.27      Average Acc_var:5.8144  Average Acc_var5:5.6559
KNN Dist 1487.12
FID 28.73
# ./baselines/checkpoints/target_ckp_random_erasing_0.3_0.3_1_2/FaceNet64_80.19_allclass.tar
Average Acc:39.93       Average Acc5:67.60      Average Acc_var:5.4669  Average Acc_var5:4.3000
KNN Dist 1556.28
FID 32.02

# FFHQ -> CelebA
# ./baselines/checkpoints/target_ckp_random_erasing_0.0_0.0_1_2/FaceNet64_87.47_allclass.tar
Average Acc:45.93       Average Acc5:73.87      Average Acc_var:4.0580  Average Acc_var5:3.6030
KNN Dist 1483.78
FID 41.80


