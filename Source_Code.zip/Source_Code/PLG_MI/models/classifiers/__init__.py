from .classifier import VGG16, FaceNet, IR152, FaceNet64, VGG16_BiDO, VGG16_nohidden, VGG16_vib
