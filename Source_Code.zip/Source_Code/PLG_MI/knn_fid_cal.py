import logging
import numpy as np
import os
import random
import statistics
import time
import torch
from argparse import ArgumentParser
from kornia import augmentation

import losses as L
import utils
from evaluation import get_knn_dist, calc_fid
from models.classifiers import VGG16, IR152, FaceNet, FaceNet64, VGG16_BiDO
from models.generators.resnet64 import ResNetGenerator
from utils import save_tensor_images

device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')


def set_random_seed(seed=0):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


set_random_seed(42)

# Load evaluation model
E = FaceNet(1000)
E = torch.nn.DataParallel(E).cuda()
path_E = 'checkpoints/evaluate_model/FaceNet_95.88.tar'
ckp_E = torch.load(path_E)
E.load_state_dict(ckp_E['state_dict'], strict=True)
E.eval()


save_dir = "../LOMMA/attack_results_0.05/kedmi_300ids/celeba_VGG16_Vib/ours/latent/images/"
print(save_dir)

# print("=> Calculate the KNN Dist.")
# knn_dist = get_knn_dist(E, os.path.join(save_dir, 'all'), "celeba_private_feats")
# print("KNN Dist %.2f" % knn_dist)

print("=> Calculate the FID.")
fid = calc_fid(recovery_img_path=os.path.join(save_dir, "res_success"),
                private_img_path="datasets/celeba_private_domain",
                batch_size=100)
print("FID %.2f" % fid)
