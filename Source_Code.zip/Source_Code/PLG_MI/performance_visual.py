import matplotlib.pyplot as plt

###############################KedMI############################################################
nodef_acc = [79.65, 82.05, 85.01]
nodef_kedmi_acc = [51.40, 57.67, 59.87]

bido_acc = [79.85]
bido_kedmi_acc = [43.53]

audo_acc = [80.75]
audo_kedmi_acc = [38.33]

udo_acc = [80.55, 80.32, 81.58]
udo_kedmi_acc = [44.87, 46.40, 47.27]

cutout_acc = [84.94]
cutout_kedmi_acc = [48.33]

plt.plot(nodef_acc, nodef_kedmi_acc, label='NoDef', c='red', marker="o", markersize=9)
plt.scatter(bido_acc, bido_kedmi_acc, c='green',  marker="o", s=26)
plt.scatter(udo_acc, udo_kedmi_acc, c='orange',  marker="o", s=26)
plt.scatter(audo_acc, audo_kedmi_acc, c='cyan',  marker="o", s=26)
plt.scatter(cutout_acc, cutout_kedmi_acc, c='blue',  marker="o", s=26)

for i in range(len(bido_acc)):
    plt.annotate('BiDO', (bido_acc[i], bido_kedmi_acc[i]))
for i in range(len(udo_acc)):
    plt.annotate('UDO', (udo_acc[i], udo_kedmi_acc[i]))
for i in range(len(audo_acc)):
    plt.annotate('AUDO', (audo_acc[i], audo_kedmi_acc[i]))
for i in range(len(cutout_acc)):
    plt.annotate('Cutout', (cutout_acc[i], cutout_kedmi_acc[i]))

plt.legend()
plt.grid()
plt.title("KedMI attack Acc and Main task Acc Trade Off")
plt.xlabel('Main task Acc')
plt.ylabel('KedMI attack Acc')
plt.savefig("Kedmi.png")
plt.close()

###############################GMI############################################################

nodef_acc = [79.65, 82.05, 85.01]
nodef_gmi_acc = [7.2, 6.6, 7.4]

bido_acc = [79.85]
bido_gmi_acc = [6.6]

audo_acc = [80.75]
audo_gmi_acc = [5.33]

cutout_acc = [84.94]
cutout_gmi_acc = [6.2]


plt.plot(nodef_acc, nodef_gmi_acc, label='NoDef', c='red', marker="o", markersize=9)
plt.scatter(bido_acc, bido_gmi_acc, c='green',  marker="o", s=26)
plt.scatter(audo_acc, audo_gmi_acc, c='cyan',  marker="o", s=26)
plt.scatter(cutout_acc, cutout_gmi_acc, c='blue',  marker="o", s=26)

for i in range(len(bido_acc)):
    plt.annotate('BiDO', (bido_acc[i], bido_gmi_acc[i]))
for i in range(len(audo_acc)):
    plt.annotate('AUDO', (audo_acc[i], audo_gmi_acc[i]))
for i in range(len(cutout_acc)):
    plt.annotate('Cutout', (cutout_acc[i], cutout_gmi_acc[i]))


plt.legend()
plt.grid()
plt.title("GMI attack Acc and Main task Acc Trade Off")
plt.xlabel('Main task Acc')
plt.ylabel('GMI attack Acc')
plt.savefig("GMI.png")
plt.close()

###############################KedMI Feat Dis############################################################


nodef_acc = [79.65, 82.05, 85.01]
nodef_featdis = [0.9576, 0.9292, 0.9184]

bido_acc = [79.85]
bido_featdis = [0.9857]

audo_acc = [80.75]
audo_featdis = [0.9867]

cutout_acc = [84.94]
cutout_featdis = [0.9402]


plt.plot(nodef_acc, nodef_featdis, label='NoDef', c='red', marker="o", markersize=9)
plt.scatter(bido_acc, bido_featdis, c='green',  marker="o", s=26)
plt.scatter(audo_acc, audo_featdis, c='cyan',  marker="o", s=26)
plt.scatter(cutout_acc, cutout_featdis, c='blue',  marker="o", s=26)

for i in range(len(bido_acc)):
    plt.annotate('BiDO', (bido_acc[i], bido_featdis[i]))
for i in range(len(audo_acc)):
    plt.annotate('AUDO', (audo_acc[i], audo_featdis[i]))
for i in range(len(cutout_acc)):
    plt.annotate('Cutout', (cutout_acc[i], cutout_featdis[i]))


plt.legend()
plt.grid()
plt.title("KedMI Feature Distance and Main task Acc Trade Off")
plt.xlabel('Main task Acc')
plt.ylabel('Feature Distance')
plt.savefig("KedMI_KNN_FeatureDis.png")
plt.close()

