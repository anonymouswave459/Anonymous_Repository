# ./baselines/checkpoints/target_ckp_random_erasing_0.0_0.0_1_2/FaceNet64_87.47_allclass.tar
Average Acc:90.73       Average Acc5:98.13      Average Acc_var:3.4795  Average Acc_var5:1.2114
KNN Dist 1254.58
FID 20.54
# ./baselines/checkpoints/target_ckp_random_erasing_0.05_0.05_1_2/FaceNet64_86.54_allclass.tar
Average Acc:85.93       Average Acc5:96.73      Average Acc_var:3.6286  Average Acc_var5:1.4598
KNN Dist 1318.29
FID 18.93
# ./baselines/checkpoints/target_ckp_random_erasing_0.1_0.1_1_2/FaceNet64_87.17_allclass.tar
Average Acc:84.27       Average Acc5:96.13      Average Acc_var:3.3780  Average Acc_var5:2.1966
KNN Dist 1359.56
FID 21.78
# ./baselines/checkpoints/target_ckp_random_erasing_0.2_0.2_1_2/FaceNet64_82.65_allclass.tar
Average Acc:65.20       Average Acc5:86.67      Average Acc_var:3.8019  Average Acc_var5:2.4315
KNN Dist 1506.27
FID 31.00
# ./baselines/checkpoints/target_ckp_random_erasing_0.3_0.3_1_2/FaceNet64_80.19_allclass.tar
Average Acc:50.40       Average Acc5:75.93      Average Acc_var:3.7163  Average Acc_var5:3.2049
KNN Dist 1606.92
FID 31.44
# ./baselines/checkpoints/target_ckp_random_erasing_0.4_0.4_1_2/FaceNet64_77.40_allclass.tar
Average Acc:41.53       Average Acc5:66.20      Average Acc_var:5.0334  Average Acc_var5:4.1654
KNN Dist 1686.89
FID 37.45
# ./baselines/checkpoints/target_ckp_random_erasing_0.5_0.5_1_2/FaceNet64_72.18_allclass.tar
Average Acc:21.40       Average Acc5:43.07      Average Acc_var:3.0595  Average Acc_var5:3.3203
KNN Dist 1833.91
FID 47.15

