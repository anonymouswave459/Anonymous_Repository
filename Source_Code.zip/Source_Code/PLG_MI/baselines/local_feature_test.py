from pytorch_grad_cam import GradCAM, HiResCAM, ScoreCAM, GradCAMPlusPlus, AblationCAM, XGradCAM, EigenCAM, FullGrad, EigenGradCAM, GradCAMElementWise, LayerCAM
from pytorch_grad_cam.feature_factorization.deep_feature_factorization import DeepFeatureFactorization, run_dff_on_image
from pytorch_grad_cam.utils.model_targets import ClassifierOutputTarget
from pytorch_grad_cam.utils.image import show_cam_on_image
from torchvision.models import resnet50

import torch, os, engine, utils, sys
from tqdm import tqdm
import time
import matplotlib.pyplot as plt
import numpy as np
import cv2
from torch import nn
import torchvision
from torchvision import datasets
from PIL import Image
from classify import *
from PIL import Image
import torchvision.transforms.functional as TF
from torchvision.utils import save_image




os.environ["CUDA_VISIBLE_DEVICES"]="0"
# Target Model Loading
device = "cuda"
num_classes = 1000
T = VGG16_BiDO_nohidden(1000, hsic_training=True)
T = torch.nn.DataParallel(T).cuda()

E = FaceNet(1000)
E = torch.nn.DataParallel(E).cuda()
path_E = '../checkpoints/evaluate_model/FaceNet_95.88.tar'
ckp_E = torch.load(path_E)
E.load_state_dict(ckp_E['state_dict'], strict=True)
E.eval()


FaceNet64_MIDRE_eval = FaceNet64(1000)
FaceNet64_MIDRE_path_T = './checkpoints/target_ckp_random_erasing_0.2_0.2_1_2/FaceNet64_82.65_allclass.tar'
FaceNet64_MIDRE_eval = torch.nn.DataParallel(FaceNet64_MIDRE_eval).cuda()
FaceNet64_MIDRE_ckp_T = torch.load(FaceNet64_MIDRE_path_T)
print(FaceNet64_MIDRE_path_T)
FaceNet64_MIDRE_eval.load_state_dict(FaceNet64_MIDRE_ckp_T['state_dict'], strict=True)
FaceNet64_MIDRE_eval.eval()

FaceNet64_NoDef_eval = FaceNet64(1000)
FaceNet64_NoDef_path_T = '../target_model/FaceNet64_88.50.tar'
FaceNet64_NoDef_eval = torch.nn.DataParallel(FaceNet64_NoDef_eval).cuda()
FaceNet64_NoDef_ckp_T = torch.load(FaceNet64_NoDef_path_T)
print(FaceNet64_NoDef_path_T)
FaceNet64_NoDef_eval.load_state_dict(FaceNet64_NoDef_ckp_T['state_dict'], strict=True)
FaceNet64_NoDef_eval.eval()

dataset_name = 'celeba'
model_path = 'target_model'
defense = 'NoDef'
if defense == 'NoDef':
    path_T = './checkpoints/NoDef_VGG16_0.000&0.000_86.90.tar'
elif defense == 'BiDO':
    path_T = './checkpoints/BiDO_VGG16_0.050&0.500_79.85_90.33_47.tar'
elif defense == 'MIDRE':
    path_T = 'checkpoints/Random_Erasing_VGG16_0.000&0.000_80.25_89.76_44.tar'


print(path_T)
ckp_T = torch.load(path_T)
T.load_state_dict(ckp_T['state_dict'], strict=True)
T = T.module
T = T.to(device)
T.eval()
target_layers = [T.layer5[-2]]

label = 144
# Label: 2, 3, 10, 18
defense = "MIDRE"
if defense == 'NoDef':
    image_folder = '../PLG_MI_Inversion_NoDef/all_imgs/'
elif defense == 'BiDO':
    image_folder = '../PLG_MI_Inversion_BiDO/all_imgs/'
elif defense == 'MIDRE':
    # image_folder = '../PLG_MI_Inversion_MIDRE/all_imgs/'
    image_folder = '../PLG_MI_Inversion_MIDRE/un_success_imgs/'
    # image_folder = '../VGG16_0.000&0.000_80.25_89.76_44.tar_KedMI/all'
elif defense == "Private":
    image_folder = 'datasets/celeba'

if defense == "Private":
    image_path = os.path.join(image_folder, str(label))
    for index, iter_image in enumerate(os.listdir(image_path)):
        if index == 11:
            image_path = os.path.join(image_path, iter_image)
            break
else:
    # image_path = os.path.join(image_folder, str(label),'attack_iden_'+str(label).zfill(3)+'_3.png')
    image_path = os.path.join(image_folder, str(label),'attack_iden_'+str(label)+'_0.png')
print(image_path)
image = Image.open(image_path)
image = TF.to_tensor(image)
image.unsqueeze_(0)
image = image.to(device)


# h = 56
# w = 56
# pad = 8
# modified_image = torchvision.transforms.functional.erase(image, i=0, j=0, h=pad, w=64, v=0, inplace=False)
# modified_image = torchvision.transforms.functional.erase(modified_image, i=64-pad, j=0, h=pad, w=64, v=0, inplace=False)
# modified_image = torchvision.transforms.functional.erase(modified_image, i=0, j=0, h=64, w=pad, v=0, inplace=False)
# modified_image = torchvision.transforms.functional.erase(modified_image, i=0, j=64-pad, h=64, w=pad, v=0, inplace=False)

# modified_image = torchvision.transforms.functional.erase(image, i=20, j=20, h=32, w=32, v=0, inplace=False)

# modified_image = modified_image.to(device)

### GRADCAM VGG16
cam = GradCAM(model=T, target_layers=target_layers, use_cuda=True)
targets = [ClassifierOutputTarget(label)]
grayscale_cam = cam(input_tensor=image, targets=targets)
grayscale_cam = grayscale_cam[0, :]
input_tensor = torch.squeeze(image, 0)
rgb_img = torchvision.transforms.ToPILImage()(input_tensor)
rgb_img = np.array(rgb_img)/255
visualization = show_cam_on_image(rgb_img, grayscale_cam, use_rgb=True)
im = Image.fromarray(visualization)
im.save('temp_images/NoRE_GRADCAM.jpg')

# print(FaceNet64_MIDRE_eval.module.feature.body[-1])
# exit()
# image = torchvision.transforms.RandomErasing(p=1.0, scale=(0.4, 0.4), ratio=(1, 2), value=0, inplace=False)(image)
# target_layers = [FaceNet64_MIDRE_eval.module.feature.body[-1]]
# cam = GradCAM(model=FaceNet64_MIDRE_eval, target_layers=target_layers, use_cuda=True)
# targets = [ClassifierOutputTarget(label)]
# grayscale_cam = cam(input_tensor=image, targets=targets)
# grayscale_cam = grayscale_cam[0, :]
# input_tensor = torch.squeeze(image, 0)
# rgb_img = torchvision.transforms.ToPILImage()(input_tensor)
# rgb_img = np.array(rgb_img)/255
# visualization = show_cam_on_image(rgb_img, grayscale_cam, use_rgb=True)
# im = Image.fromarray(visualization)
# im.save('temp_images/Masked_FaceNet64_MIDRE_eval_NoRE_GRADCAM.jpg')

# modified_image = torchvision.transforms.RandomErasing(p=1.0, scale=(0.6, 0.6), ratio=(1, 2), value=0, inplace=False)(image)
modified_image = image
cam = GradCAM(model=T, target_layers=target_layers, use_cuda=True)
targets = [ClassifierOutputTarget(label)]
grayscale_cam = cam(input_tensor=modified_image, targets=targets)
grayscale_cam = grayscale_cam[0, :]
input_tensor = torch.squeeze(modified_image, 0)
rgb_img = torchvision.transforms.ToPILImage()(input_tensor)
rgb_img = np.array(rgb_img)/255
visualization = show_cam_on_image(rgb_img, grayscale_cam, use_rgb=True)
im = Image.fromarray(visualization)
im.save('temp_images/modified_image_GRADCAM.jpg')

softmax_f = nn.Softmax(dim=1)

output = T(modified_image)
output = softmax_f(output)
output.squeeze_(0)
print("Confidence Score, modified_image RE", path_T, output[label])
save_image(image, 'temp_images/modified_image.jpg')

output = T(image)
output = softmax_f(output)
output.squeeze_(0)
print("Confidence Score, No RE", path_T, output[label])
save_image(image, 'temp_images/NoRE.jpg')

softmax_f = nn.Softmax(dim=1)
_, output = FaceNet64_NoDef_eval(image)
output = softmax_f(output)
output.squeeze_(0)
print("FaceNet64_NoDef_eval's Confidence Score, No RE", output[label])
save_image(image, 'temp_images/NoRE.jpg')

softmax_f = nn.Softmax(dim=1)
_, output = FaceNet64_MIDRE_eval(image)
output = softmax_f(output)
output.squeeze_(0)
print("FaceNet64_MIDRE_eval's Confidence Score, No RE", output[label])
save_image(image, 'temp_images/NoRE.jpg')




# eval_image = utils.low2high(image)
# eval_prob = E(eval_image)[-1]
# eval_prob = softmax_f(eval_prob)
# eval_prob.squeeze_(0)
# print("Evaluation Model's Confidence Score, No RE", eval_prob[label])
# save_image(eval_image, 'temp_images/Eval_image.jpg')
# high_image = torchvision.transforms.Resize((1024, 1024))(image)
# save_image(high_image, 'temp_images/High_image.jpg')





# eval_image = utils.low2high(image)
# eval_image = torchvision.transforms.RandomErasing(p=1.0, scale=(0.1, 0.4), ratio=(1, 2), value=0, inplace=False)(eval_image)
# eval_prob = E(eval_image)[-1]
# eval_prob = softmax_f(eval_prob)
# eval_prob.squeeze_(0)
# print("Evaluation Model's Confidence Score, RE", eval_prob[label])
# save_image(eval_image, 'temp_images/RE_Eval_image.jpg')


# image = torchvision.transforms.Resize((112,112))(image)
# image = torchvision.transforms.Resize((64,64))(image)
# output = T(image)
# output = softmax_f(output)
# output.squeeze_(0)
# print("Confidence Score, RESIZE", output[label])
# save_image(image, 'temp_images/RESIZE.jpg')



# image = torchvision.transforms.RandomErasing(p=1.0, scale=(0.1, 0.4), ratio=(1, 2), value=0, inplace=False)(image)
# output = T(image)
# output = softmax_f(output)
# output.squeeze_(0)
# print("Confidence Score, RE", output[label])
# save_image(image, 'temp_images/RE.jpg')


# output_3 = T(modified_image)
# output_3 = softmax_f(output_3)
# output_3.squeeze_(0)
# print("Confidence Score, modified_image", label, output_3[label])
# save_image(modified_image, 'temp_images/modified_image.jpg')
