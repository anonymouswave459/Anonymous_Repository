import numpy as np
import os
import sys
import torch
import torch.nn as nn
from sklearn.model_selection import train_test_split
from torchvision.utils import save_image

import classify
import engine
import utils

file = "./config/classify.json"
args = utils.load_json(json_file=file)
model_name = args['dataset']['model_name']

# log_file = "{}.txt".format(model_name)
# utils.Tee(os.path.join(log_path, log_file), 'w')

os.environ["CUDA_VISIBLE_DEVICES"] = args['dataset']['gpus']
# print(log_file)
print("---------------------Training [%s]---------------------" % model_name)
utils.print_params(args["dataset"], args[model_name], dataset=args['dataset']['name'])

train_file = args['dataset']['train_file_path']
test_file = args['dataset']['test_file_path']

name_list, label_list, image_list = utils.load_image_list(args, train_file, mode='test')
_, trainloader = utils.init_dataloader(args, train_file, 1, mode="test", iterator=False, name_list=name_list,
                                        label_list=label_list, image_list=image_list)
print("test image_list", len(image_list))
root_folder = "datasets/celeba"
os.makedirs(root_folder, exist_ok=True)
count = 0
for image, label in trainloader:
    # print(image.shape, label)
    class_folder = os.path.join(root_folder, str(label.item()))
    os.makedirs(class_folder, exist_ok=True)
    image_path = os.path.join(class_folder, str(count)+".jpg")
    count+=1
    if count % 100 == 0:
        print("Processing ...", count)
    save_image(image, image_path)
    # exit()

