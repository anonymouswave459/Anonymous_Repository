import os
import shutil


image_folder = '../PLG_MI_Inversion_MIDRE/'
all_image_folder = os.path.join(image_folder, 'all_imgs')
success_image_folder = os.path.join(image_folder, 'success_imgs')
unsuccess_image_folder = os.path.join(image_folder, 'un_success_imgs')
os.makedirs(unsuccess_image_folder, exist_ok=True)



for image_class in os.listdir(all_image_folder):
    success_class_dir = os.path.join(success_image_folder, image_class)
    if not os.path.isdir(success_class_dir):
        success_list = []
    else:
        success_list = os.listdir(success_class_dir)
    unsuccess_class_dir = os.path.join(unsuccess_image_folder, image_class)
    all_class_dir = os.path.join(all_image_folder, image_class)
    for image_name in os.listdir(all_class_dir):
        print(image_name, success_list, '0_'+image_name in success_list)
        if '0_'+image_name not in success_list:
            os.makedirs(unsuccess_class_dir, exist_ok=True)
            src = os.path.join(all_class_dir, image_name)
            dst = os.path.join(unsuccess_class_dir, image_name)
            shutil.copyfile(src, dst)




