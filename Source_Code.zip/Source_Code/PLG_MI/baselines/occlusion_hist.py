from pytorch_grad_cam import GradCAM, HiResCAM, ScoreCAM, GradCAMPlusPlus, AblationCAM, XGradCAM, EigenCAM, FullGrad, EigenGradCAM, GradCAMElementWise, LayerCAM
from pytorch_grad_cam.feature_factorization.deep_feature_factorization import DeepFeatureFactorization, run_dff_on_image
from pytorch_grad_cam.utils.model_targets import ClassifierOutputTarget
from pytorch_grad_cam.utils.image import show_cam_on_image
from torchvision.models import resnet50

import torch, os, engine, utils, sys
from tqdm import tqdm
import time
import matplotlib.pyplot as plt
import numpy as np
import cv2
from torch import nn
import torchvision
from torchvision import datasets
from PIL import Image
from classify import *
from PIL import Image
import torchvision.transforms.functional as TF
from torchvision.utils import save_image




os.environ["CUDA_VISIBLE_DEVICES"]="0"
# Target Model Loading
device = "cuda"
num_classes = 1000
T = VGG16_BiDO_nohidden(1000, hsic_training=True)
T = torch.nn.DataParallel(T).cuda()

E = FaceNet(1000)
E = torch.nn.DataParallel(E).cuda()
path_E = '../checkpoints/evaluate_model/FaceNet_95.88.tar'
ckp_E = torch.load(path_E)
E.load_state_dict(ckp_E['state_dict'], strict=True)
E.eval()


FaceNet64_MIDRE_eval = FaceNet64(1000)
FaceNet64_MIDRE_path_T = 'checkpoints/target_ckp_random_erasing_0.2_0.2_1_2/FaceNet64_82.65_allclass.tar'
FaceNet64_MIDRE_eval = torch.nn.DataParallel(FaceNet64_MIDRE_eval).cuda()
FaceNet64_MIDRE_ckp_T = torch.load(FaceNet64_MIDRE_path_T)
print(FaceNet64_MIDRE_path_T)
FaceNet64_MIDRE_eval.load_state_dict(FaceNet64_MIDRE_ckp_T['state_dict'], strict=True)
FaceNet64_MIDRE_eval.eval()

FaceNet64_NoDef_eval = FaceNet64(1000)
FaceNet64_NoDef_path_T = '../target_model/FaceNet64_88.50.tar'
FaceNet64_NoDef_eval = torch.nn.DataParallel(FaceNet64_NoDef_eval).cuda()
FaceNet64_NoDef_ckp_T = torch.load(FaceNet64_NoDef_path_T)
print(FaceNet64_NoDef_path_T)
FaceNet64_NoDef_eval.load_state_dict(FaceNet64_NoDef_ckp_T['state_dict'], strict=True)
FaceNet64_NoDef_eval.eval()

dataset_name = 'celeba'
model_path = 'target_model'
defense = 'NoDef'
if defense == 'NoDef':
    path_T = './checkpoints/NoDef_VGG16_0.000&0.000_86.90.tar'
elif defense == 'BiDO':
    path_T = './checkpoints/BiDO_VGG16_0.050&0.500_79.85_90.33_47.tar'
elif defense == 'MIDRE':
    path_T = 'checkpoints/Random_Erasing_VGG16_0.000&0.000_80.25_89.76_44.tar'


print(path_T)
ckp_T = torch.load(path_T)
T.load_state_dict(ckp_T['state_dict'], strict=True)
T = T.module
T = T.to(device)
T.eval()
target_layers = [T.layer5[-2]]

# Label: 2, 3, 10, 18
data_defense = "MIDRE"
if data_defense == 'NoDef':
    image_folder = '../PLG_MI_Inversion_NoDef/all_imgs/'
    # image_folder = '../NoDef_VGG16_0.000&0.000_86.90.tar_KedMI/all'
elif data_defense == 'BiDO':
    image_folder = '../PLG_MI_Inversion_BiDO/all_imgs/'
elif data_defense == 'MIDRE':
    # image_folder = '../PLG_MI_Inversion_MIDRE/all_imgs/'
    image_folder = '../PLG_MI_Inversion_MIDRE/un_success_imgs/'
    # image_folder = '../VGG16_0.000&0.000_80.25_89.76_44.tar_KedMI/all'
elif data_defense == "Private":
    image_folder = 'datasets/celeba'

scores = []
count = 0
total = 0
for label in range(300):
    if label % 10 == 0:
        print("label", label)
    for index in range(0, 5):
        if data_defense == "Private":
            image_path = os.path.join(image_folder, str(label))
            for iter_image in os.listdir(image_path):
                image_path = os.path.join(image_path, iter_image)
                break
        else:
            image_path = os.path.join(image_folder, str(label),'attack_iden_'+str(label)+'_'+str(index)+'.png')
            # image_path = os.path.join(image_folder, str(label),'attack_iden_'+str(label).zfill(3)+'_'+str(index)+'.png')
        if not os.path.isfile(image_path):
            continue
        total += 1
        image = Image.open(image_path)
        image = TF.to_tensor(image)
        image.unsqueeze_(0)
        image = image.to(device)
        image = torchvision.transforms.RandomErasing(p=1.0, scale=(0.1, 0.4), ratio=(1, 2), value=0, inplace=False)(image)


        softmax_f = nn.Softmax(dim=1)
        _, output = FaceNet64_NoDef_eval(image)
        # output = T(image)
        output = softmax_f(output)
        eval_iden = torch.argmax(output, dim=1).view(-1)
        if eval_iden==label:
            count+=1
        output.squeeze_(0)
        scores.append(output[label].item())
        save_image(image, 'temp_images/NoRE.jpg')
        torch.cuda.empty_cache()
# scores = np.array(scores)
# plt.axes().set_facecolor("papayawhip")
# plt.hist(scores, color='g', label="Our Method", bins=10, range=(0,1), facecolor='mediumseagreen', edgecolor='black', linewidth=0.5)
# plt.xticks(fontsize=21)
# plt.yticks(fontsize=21)
# # plt.title("Ours", fontsize=35)
# plt.grid()
# hist_folder = os.path.join("../Histogram", str(data_defense)+'_Data_KedMI')
# os.makedirs(hist_folder, exist_ok=True) 
# plt.savefig(os.path.join(hist_folder, "FaceNet64_"+ defense + "_" + data_defense+".png"))
print("Num of correct samples", count, "Num of total", total, "Acc", count/total*100)

# softmax_f = nn.Softmax(dim=1)
# _, output = FaceNet64_NoDef_eval(image)
# output = softmax_f(output)
# output.squeeze_(0)
# print("FaceNet64_NoDef_eval's Confidence Score, No RE", output[label])
# save_image(image, 'temp_images/NoRE.jpg')

# softmax_f = nn.Softmax(dim=1)
# _, output = FaceNet64_MIDRE_eval(image)
# output = softmax_f(output)
# output.squeeze_(0)
# print("FaceNet64_MIDRE_eval's Confidence Score, No RE", output[label])
# save_image(image, 'temp_images/NoRE.jpg')




