import numpy as np
import os
import sys
import torch
import torch.nn as nn
from sklearn.model_selection import train_test_split

import classify
import engine
import utils

path_T = '/home/hung/PLG_MI/baselines/checkpoints/IR152_91.16.tar'

model_name = 'IR152'
mode = "reg"
n_classes = 1000

if model_name == "VGG16":
    if mode == "reg":
        net = classify.VGG16_BiDO(n_classes,hsic_training=True)
    elif mode == "vib":
        net = classify.VGG16_vib(n_classes)

elif model_name == "FaceNet":
    net = classify.FaceNet(n_classes)
    # BACKBONE_RESUME_ROOT = os.path.join(root_path, "backbone_ir50_ms1m_epoch120.pth")
    BACKBONE_RESUME_ROOT = "/public/yuanxiaojian/Competition/OPPO_2021_Face_Attack/other_code/OPPO_Face_Attack/My_Attack_2/models/extractor_weights/backbone_ir50_ms1m_epoch120.pth"
    print("Loading Backbone Checkpoint ")
    utils.load_state_dict(net.feature, torch.load(BACKBONE_RESUME_ROOT))
    # utils.weights_init_classifier(net.fc_layer)

elif model_name == "FaceNet_all":
    net = classify.FaceNet(202599)
    # BACKBONE_RESUME_ROOT = os.path.join(root_path, "backbone_ir50_ms1m_epoch120.pth")
    BACKBONE_RESUME_ROOT = "/public/yuanxiaojian/Competition/OPPO_2021_Face_Attack/other_code/OPPO_Face_Attack/My_Attack_2/models/extractor_weights/backbone_ir50_ms1m_epoch120.pth"
    print("Loading Backbone Checkpoint ")
    utils.load_state_dict(net.feature, torch.load(BACKBONE_RESUME_ROOT))
    # utils.weights_init_classifier(net.fc_layer)

elif model_name == "FaceNet64":
    net = classify.FaceNet64(n_classes)
    # BACKBONE_RESUME_ROOT = os.path.join(root_path, "backbone_ir50_ms1m_epoch120.pth")
    # BACKBONE_RESUME_ROOT = "/public/yuanxiaojian/Competition/OPPO_2021_Face_Attack/other_code/OPPO_Face_Attack/My_Attack_2/models/extractor_weights/backbone_ir50_ms1m_epoch120.pth"
    # print("Loading Backbone Checkpoint ")
    # utils.load_state_dict(net.feature, torch.load(BACKBONE_RESUME_ROOT))
    # net.fc_layer.apply(net.weight_init)

elif model_name == "IR50":
    if mode == "reg":
        net = classify.IR50(n_classes)
    elif mode == "vib":
        net = classify.IR50_vib(n_classes)
    BACKBONE_RESUME_ROOT = "ir50.pth"
    print("Loading Backbone Checkpoint ")
    load_my_state_dict(net.feature, torch.load(BACKBONE_RESUME_ROOT))

elif model_name == "IR152":
    if mode == "reg":
        net = classify.IR152(n_classes)
    else:
        net = classify.IR152_vib(n_classes)
else:
    print("Model name Error")
    exit()
device = "cuda"
ckp_T = torch.load(path_T)
net = torch.nn.DataParallel(net).cuda()
net.load_state_dict(ckp_T['state_dict'], strict=True)
net = net.module
net = net.to(device)
net.eval()

loaded_args = utils.load_json(json_file='config/classify.json')
train_file = loaded_args['dataset']['train_file_path']
test_file = loaded_args['dataset']['test_file_path']
name_list, label_list, image_list = utils.load_image_list(loaded_args, test_file, mode='test')
_, testloader = utils.init_dataloader(loaded_args, test_file, 1, mode="test", iterator=False, name_list=name_list, label_list=label_list, image_list=image_list)
print("test image_list", len(image_list))
Accuracy_dict = {}
count = 0
for img, iden in testloader:
    img, iden = img.to(device), iden.to(device)
    bs = img.size(0)
    iden = iden.view(-1)
    # print(iden.cpu().item())
    # exit()
    out_prob = net(img)[-1]
    out_iden = torch.argmax(out_prob, dim=1).view(-1)
    label = iden.cpu().item()
    if label not in Accuracy_dict:
        Accuracy_dict[label] = [0, 0]
    if out_iden == iden:
        Accuracy_dict[label][0]+=1
    Accuracy_dict[label][1]+=1
    count+=1

# print(list(Accuracy_dict.keys())[0])
acc_list = []
for key in Accuracy_dict:
    acc = Accuracy_dict[key][0]/Accuracy_dict[key][1]*100
    # print(acc)
    # exit()
    acc_list.append(acc)
accs = np.array(acc_list)
print(len(Accuracy_dict))
print("error bar", np.std(accs), np.mean(accs))
