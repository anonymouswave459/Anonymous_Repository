import torch.utils.data as data
from torchvision import transforms
import torch
import torchvision
import time
from classify import VGG16, VGG16_BiDO, FaceNet
import utils
from models.generators.resnet64 import ResNetGenerator
from generator import Generator
from argparse import ArgumentParser
import numpy as np
from torchvision.utils import save_image
import random

def set_random_seed(seed=0):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

random_seed = 2023
set_random_seed(random_seed)



device = torch.device("cuda")
def test(model, eval_model, criterion, dataloader):
    tf = time.time()
    model.eval()
    eval_model.eval()
    loss, cnt, ACC, TP_ACC = 0.0, 0, 0, 0

    for img, iden in dataloader:
        img, iden = img.to(device), iden.to(device)
        bs = img.size(0)
        iden = iden.view(-1)
        eval_out_prob = eval_model(utils.low2high(img))[-1]
        out_prob = eval_model(utils.low2high(img))[-1]
        out_prob = model(img)[-1]
        out_iden = torch.argmax(out_prob, dim=1).view(-1)
        ACC += torch.sum(iden == out_iden).item()
        cnt += bs

        eval_out_iden = torch.argmax(eval_out_prob, dim=1).view(-1)
        TP_ACC += torch.sum(out_iden == eval_out_iden).item()
    print(cnt, ACC, TP_ACC)

    return ACC * 100.0 / cnt,  TP_ACC * 100.0 / cnt

def test_gan(model, eval_model, criterion, dataloader):
    tf = time.time()
    model.eval()
    eval_model.eval()
    loss, cnt, ACC, TP_ACC = 0.0, 0, 0, 0

    for index, img in enumerate(dataloader):
        img = img.to(device)
        bs = img.size(0)
        eval_out_prob = eval_model(utils.low2high(img))[-1]
        out_prob = eval_model(utils.low2high(img))[-1]
        out_prob = model(img)[-1]
        out_iden = torch.argmax(out_prob, dim=1).view(-1)
        cnt += bs

        eval_out_iden = torch.argmax(eval_out_prob, dim=1).view(-1)
        TP_ACC += torch.sum(out_iden == eval_out_iden).item()
        if index % 10 == 0:
            print("Processing ...", index)
            print(cnt, ACC, TP_ACC, TP_ACC * 100.0 / cnt)
    print(cnt, ACC, TP_ACC)

    return ACC * 100.0 / cnt,  TP_ACC * 100.0 / cnt

def sample_z(batch_size, dim_z, device, distribution=None):
    """Sample random noises.

    Args:
        batch_size (int)
        dim_z (int)
        device (torch.device)
        distribution (str, optional): default is normal

    Returns:
        torch.FloatTensor or torch.cuda.FloatTensor

    """

    if distribution is None:
        distribution = 'normal'
    if distribution == 'normal':
        return torch.empty(batch_size, dim_z, dtype=torch.float32, device=device).normal_()
    else:
        return torch.empty(batch_size, dim_z, dtype=torch.float32, device=device).uniform_()


def test_generative_plgmi(args, model, eval_model, criterion, G):
    tf = time.time()
    model.eval()
    eval_model.eval()
    G.eval()
    loss, cnt, ACC, TP_ACC = 0.0, 0, 0, 0
    bs = 10
    device = torch.device("cuda")
    for index in range(300):
        iden = torch.from_numpy(np.random.randint(1000, size=bs))
        # iden = torch.from_numpy(np.arange(index*bs, (index+1)*bs))
        iden = iden.view(-1).long().cuda()
        z = sample_z(
            bs, args.gen_dim_z, device, args.gen_distribution
        )
        img = G(z, iden)
        # save_image(img, "samples.png")
        # exit()
        img = img.to(device)
        bs = img.size(0)
        eval_out_prob = eval_model(utils.low2high(img))[-1]
        out_prob = model(img)[-1]
        out_iden = torch.argmax(out_prob, dim=1).view(-1)
        cnt += bs

        eval_out_iden = torch.argmax(eval_out_prob, dim=1).view(-1)
        TP_ACC += torch.sum(out_iden == eval_out_iden).item()
        if index % 10 == 0:
            print("Processing ...", index)
            print(cnt, ACC, TP_ACC, TP_ACC * 100.0 / cnt)
    print(cnt, ACC, TP_ACC)

    return ACC * 100.0 / cnt,  TP_ACC * 100.0 / cnt

def reparameterize(mu, logvar):
    """
    Reparameterization trick to sample from N(mu, var) from
    N(0,1).
    :param mu: (Tensor) Mean of the latent Gaussian [B x D]
    :param logvar: (Tensor) Standard deviation of the latent Gaussian [B x D]
    :return: (Tensor) [B x D]
    """
    std = torch.exp(0.5 * logvar)
    eps = torch.randn_like(std)

    return eps * std + mu

from torch.autograd import Variable
def test_generative_gmi(args, model, eval_model, criterion, G):
    tf = time.time()
    model.eval()
    eval_model.eval()
    G.eval()
    loss, cnt, ACC, TP_ACC = 0.0, 0, 0, 0
    bs = 1
    device = torch.device("cuda")
    mu = Variable(torch.zeros(bs, 100), requires_grad=False)
    log_var = Variable(torch.ones(bs, 100), requires_grad=False)
    for index in range(300):
        z = reparameterize(mu, log_var)
        img = G(z)
        img = img.to(device)
        bs = img.size(0)
        eval_out_prob = eval_model(utils.low2high(img))[-1]
        out_prob = model(img)[-1]
        out_iden = torch.argmax(out_prob, dim=1).view(-1)
        cnt += bs

        eval_out_iden = torch.argmax(eval_out_prob, dim=1).view(-1)
        TP_ACC += torch.sum(out_iden == eval_out_iden).item()
        if index % 10 == 0:
            print("Processing ...", index)
            print(cnt, ACC, TP_ACC, TP_ACC * 100.0 / cnt)
    print(cnt, ACC, TP_ACC)

    return ACC * 100.0 / cnt,  TP_ACC * 100.0 / cnt

# Target Model
T = VGG16_BiDO(1000, hsic_training=True)
path_T = './checkpoints/Random_Erasing_VGG16_0.000&0.000_80.25_89.76_44.tar'
# path_T = './checkpoints/NoDef_VGG16_0.000&0.000_86.90.tar'
# path_T = './checkpoints/BiDO_VGG16_0.050&0.500_79.85_90.33_47.tar'
T = torch.nn.DataParallel(T).cuda()
ckp_T = torch.load(path_T)
print(path_T)
T.load_state_dict(ckp_T['state_dict'], strict=True)

E = FaceNet(1000)
E = torch.nn.DataParallel(E).cuda()
path_E = '../checkpoints/evaluate_model/FaceNet_95.88.tar'
ckp_E = torch.load(path_E)
E.load_state_dict(ckp_E['state_dict'], strict=True)

# Generator
# load Generator
# parser = ArgumentParser(description='Stage-2: Image Reconstruction')
# parser.add_argument('--model', default='VGG16', help='VGG16 | IR152 | FaceNet64')
# parser.add_argument('--inv_loss_type', type=str, default='margin', help='ce | margin | poincare')
# parser.add_argument('--lr', type=float, default=0.1)
# parser.add_argument('--iter_times', type=int, default=600)
# # Generator configuration
# parser.add_argument('--gen_num_features', '-gnf', type=int, default=64,
#                     help='Number of features of generator (a.k.a. nplanes or ngf). default: 64')
# parser.add_argument('--gen_dim_z', '-gdz', type=int, default=128,
#                     help='Dimension of generator input noise. default: 128')
# parser.add_argument('--gen_bottom_width', '-gbw', type=int, default=4,
#                     help='Initial size of hidden variable of generator. default: 4')
# parser.add_argument('--gen_distribution', '-gd', type=str, default='normal',
#                     help='Input noise distribution: normal (default) or uniform.')
# # path
# parser.add_argument('--save_dir', type=str,
#                     default='PLG_MI_Inversion')
# parser.add_argument('--path_G', type=str,
#                     default='')
# args = parser.parse_args()
# args.path_G = "../PLG_MI_Results/celeba/VGG16/gen_latest.pth.tar"
# # args.path_G = "../PLG_MI_Results_random_erasing/celeba/VGG16/gen_latest.pth.tar"
# G = ResNetGenerator(
#     args.gen_num_features, args.gen_dim_z, args.gen_bottom_width,
#     num_classes=1000, distribution=args.gen_distribution
# )
# gen_ckpt_path = args.path_G
# print("gen_ckpt_path", gen_ckpt_path)
# gen_ckpt = torch.load(gen_ckpt_path)['model']
# G.load_state_dict(gen_ckpt)
# G = G.cuda()
# criterion = torch.nn.CrossEntropyLoss().cuda()
# test_acc, tp_acc = test_generative_plgmi(args, T, E, criterion, G)
# print(path_T, "Test Accuracy:", test_acc, "TP ACC", tp_acc, "FP Acc", 100-tp_acc)

z_dim = 100
###########################################
###########     load model       ##########
###########################################
G = Generator(z_dim)
G = torch.nn.DataParallel(G).cuda()
path_G = "./GMI_Baseline/celeba/celeba_GMI_G.tar"
ckp_G = torch.load(path_G)
G.load_state_dict(ckp_G['state_dict'], strict=True)
criterion = torch.nn.CrossEntropyLoss().cuda()
test_acc, tp_acc = test_generative_gmi(None, T, E, criterion, G)
print(path_T, "Test Accuracy:", test_acc, "TP ACC", tp_acc, "FP Acc", 100-tp_acc)




# file = "./config/classify.json"
# args = utils.load_json(json_file=file)
# method = "GAN"
# if method == "random_erasing":
#     args["dataset"]["img_path"] =  "../../Defense_MI/DMI/attack_res/celeba/HSIC/VGG16_0.000&0.000_80.25_89.76_44.tar_KedMI/all"
#     test_file = "../../Defense_MI/DMI/attack_res/celeba/HSIC/VGG16_0.000&0.000_80.25_89.76_44.tar_KedMI/attack_set.txt"
# elif method == "Nodef":
#     args["dataset"]["img_path"] =  "../../Defense_MI/DMI/attack_res/celeba/HSIC/NoDef_VGG16_0.000&0.000_86.90.tar_KedMI/all"
#     test_file = "../../Defense_MI/DMI/attack_res/celeba/HSIC/NoDef_VGG16_0.000&0.000_86.90.tar_KedMI/attack_set.txt"
# elif method == "GAN":
#     dataset_name = "ffhq"
#     file = "./config/" + dataset_name + ".json"
#     args = utils.load_json(json_file=file)
#     file_path = args['dataset']['gan_file_path']
#     model_name = args['dataset']['model_name']
#     lr = args[model_name]['lr']
#     batch_size = args[model_name]['batch_size']
#     z_dim = args[model_name]['z_dim']
#     epochs = args[model_name]['epochs']
#     n_critic = args[model_name]['n_critic']
#     test_file = args['dataset']['gan_file_path']
# # test_file = args['dataset']['test_file_path']

# if method in ["GAN"]:
#     name_list, label_list, image_list = utils.load_image_list(args, test_file, mode='gan')
#     dataset, testloader = utils.init_dataloader(args, file_path, batch_size, mode="gan", name_list=name_list,
#                                                 label_list=label_list, image_list=image_list)
# else:
#     name_list, label_list, image_list = utils.load_image_list_attack(args, test_file, mode='test')
#     # print(name_list[0])
#     _, testloader = utils.init_dataloader_attack(args, test_file, 16, mode="test", iterator=False, name_list=name_list,
#                                         label_list=label_list, image_list=image_list)

# criterion = torch.nn.CrossEntropyLoss().cuda()
# # test_acc = test(T, criterion, testloader, False)
# if method == "GAN":
#     test_acc, tp_acc = test_gan(T, E, criterion, testloader)
# else:
#     test_acc, tp_acc = test(T, E, criterion, testloader)
# print(path_T, "Test Accuracy:", test_acc, "TP ACC", tp_acc, "FP Acc", 100-tp_acc)
