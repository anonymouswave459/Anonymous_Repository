
import torch, os, engine, utils, sys
from tqdm import tqdm
import time
import matplotlib.pyplot as plt
import numpy as np
import cv2
from torch import nn
import torchvision
from torchvision import datasets
from PIL import Image
from classify import *

from torchvision.utils import save_image


device = "cuda"

dataset_name = 'celeba'


# Loading Dataset
args = utils.load_json(json_file='config/classify.json')
test_file = args['dataset']['test_file_path']
name_list, label_list, image_list = utils.load_image_list(args, test_file, mode='test')
_, testloader = utils.init_dataloader(args, test_file, 64, mode="test", iterator=False, name_list=name_list,
                                          label_list=label_list, image_list=image_list)
dataset = testloader.dataset

image = dataset[10][0]
# image = torchvision.transforms.RandomErasing(p=1.0, scale=(0.2, 0.2), ratio=(1, 1), value=0, inplace=False)(image)
# image = torchvision.transforms.GaussianBlur((9,9), sigma=(2.0, 2.0))(image)
# image = torchvision.transforms.functional.rotate(image, 90)
image = torchvision.transforms.CenterCrop((60, 60))(image)
image = torchvision.transforms.Grayscale()(image)
print(image.shape)
# compute the entropy on input tensor element wise
ent = torch.special.entr(image)
# Display the computed entropies
print("Entropy:", ent.shape)
save_image(ent, "hung_ent.png")
save_image(image, "hung_org.png")
print(torch.sum(ent))

