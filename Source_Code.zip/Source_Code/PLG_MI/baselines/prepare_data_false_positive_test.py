import os

img_dir = "../../Defense_MI/DMI/attack_res/celeba/HSIC/NoDef_VGG16_0.000&0.000_86.90.tar_KedMI/all"
file_path = "../../Defense_MI/DMI/attack_res/celeba/HSIC/NoDef_VGG16_0.000&0.000_86.90.tar_KedMI/attack_set.txt"
for sub_dir in os.listdir(img_dir):
    # print(sub_dir)
    for img_name in os.listdir(os.path.join(img_dir, sub_dir)):
        # print(img_name)
        img_path = os.path.join(img_dir, sub_dir, img_name)
        with open(file_path, "a") as file:
            file.write(str(img_path)+" "+sub_dir+"\n") 
    
    
