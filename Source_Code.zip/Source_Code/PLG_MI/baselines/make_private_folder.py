import numpy as np
import os
import sys
import torch
import torch.nn as nn
from sklearn.model_selection import train_test_split

import classify
import engine
import utils

dataset_name = "celeba"
device = "cuda"
root_path = "./target_model_20220510"
log_path = os.path.join(root_path, "target_logs")
model_path = os.path.join(root_path, "target_ckp")
os.makedirs(model_path, exist_ok=True)
os.makedirs(log_path, exist_ok=True)

file = "./config/classify.json"
args = utils.load_json(json_file=file)
model_name = args['dataset']['model_name']

log_file = "{}.txt".format(model_name)
utils.Tee(os.path.join(log_path, log_file), 'w')

os.environ["CUDA_VISIBLE_DEVICES"] = args['dataset']['gpus']
print(log_file)
print("---------------------Training [%s]---------------------" % model_name)
utils.print_params(args["dataset"], args[model_name], dataset=args['dataset']['name'])

train_file = args['dataset']['train_file_path']
test_file = args['dataset']['test_file_path']


name_list2, label_list2, image_list2 = utils.load_image_list(args, train_file, mode='train')
_, trainloader = utils.init_dataloader(args, train_file, 1, mode="test", iterator=False, name_list=name_list2,
                                           label_list=label_list2, image_list=image_list2)
print("train image_list", len(image_list2))
from torchvision.utils import save_image
private_dir = "../datasets/celeba_private_domain/Img/"
for index, input_data in enumerate(trainloader):
    image, label = input_data
    image_dir = os.path.join(private_dir, str(index)+"_celeba.jpg")
    save_image(image, image_dir)
