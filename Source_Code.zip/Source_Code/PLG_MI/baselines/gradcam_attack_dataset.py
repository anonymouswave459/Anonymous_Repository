from pytorch_grad_cam import GradCAM, HiResCAM, ScoreCAM, GradCAMPlusPlus, AblationCAM, XGradCAM, EigenCAM, FullGrad, EigenGradCAM, GradCAMElementWise, LayerCAM
from pytorch_grad_cam.feature_factorization.deep_feature_factorization import DeepFeatureFactorization, run_dff_on_image
from pytorch_grad_cam.utils.model_targets import ClassifierOutputTarget
from pytorch_grad_cam.utils.image import show_cam_on_image
from torchvision.models import resnet50

import torch, os, engine, utils, sys
from tqdm import tqdm
import time
import matplotlib.pyplot as plt
import numpy as np
import cv2
from torch import nn
import torchvision
from torchvision import datasets
from PIL import Image
from classify import *



class ImageFolderWithPaths(datasets.ImageFolder):

    def __getitem__(self, index):
  
        img, label = super(ImageFolderWithPaths, self).__getitem__(index)
        
        path = self.imgs[index][0]
        
        return (img, label ,path)

# Target Model Loading
device = "cuda"
num_classes = 1000
T = VGG16_BiDO_nohidden(1000, hsic_training=True)
target_layers = [T.layer5[-2]]
T = torch.nn.DataParallel(T).cuda()

dataset_name = 'celeba'
model_path = 'target_model'
defense = 'MIDRE'
if defense == 'NoDef':
    path_T = './checkpoints/NoDef_VGG16_0.000&0.000_86.90.tar'
elif defense == 'BiDO':
    path_T = './checkpoints/BiDO_VGG16_0.050&0.500_79.85_90.33_47.tar'
elif defense == 'MIDRE':
    path_T = 'checkpoints/Random_Erasing_VGG16_0.000&0.000_80.25_89.76_44.tar'
print(path_T)
ckp_T = torch.load(path_T)
T.load_state_dict(ckp_T['state_dict'], strict=True)
T = T.module
T = T.to(device)
T.eval()
T.eval()

save_img_dir = '../PLG_MI_Inversion_MIDRE/'
# all_img_dir = os.path.join(save_img_dir, 'all_imgs')
# all_img_dir_gradcam = os.path.join(save_img_dir, 'all_imgs_gradcam')
# os.makedirs(all_img_dir_gradcam, exist_ok=True)
# success_img_dir = os.path.join(save_img_dir, 'success_imgs')
# success_img_dir_gradcam = os.path.join(save_img_dir, 'success_imgs_gradcam')
# os.makedirs(success_img_dir_gradcam, exist_ok=True)
un_success_img_dir = os.path.join(save_img_dir, 'un_success_imgs')
un_success_img_dir_gradcam = os.path.join(save_img_dir, 'un_success_imgs_gradcam')
os.makedirs(un_success_img_dir_gradcam, exist_ok=True)


transform = torchvision.transforms.Compose([torchvision.transforms.ToTensor()])
# dataset = ImageFolderWithPaths(all_img_dir, transform=transform)
# sucess_dataset = ImageFolderWithPaths(success_img_dir, transform=transform)
un_sucess_dataset = ImageFolderWithPaths(un_success_img_dir, transform=transform)


# dataloader = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=False)
def grad_cam(dataset, model, save_dir, except_names = ()):
    print("Do grad cam on ...", save_dir)
    individual_save_dir = os.path.join(save_dir, "IndividualExample")
    os.makedirs(individual_save_dir, exist_ok=True)
    average_grayscale_cam = np.zeros((64,64))
    count = 0
    for i in range(len(dataset)):
        if i % 100 == 0:
            print("Loading " + str(i)) 
        image, target, image_path = dataset[i]
        target = image_path.split('/')[-1].split('.')[0].split('_')[-2]
        image_name = image_path.split('/')[-1].split('.')[0]
        grad_cam_image_name = image_name + '_gradcam.png'
        target = int(target)

        input_tensor = torch.unsqueeze(image, 0)
        input_tensor = input_tensor.to(device)
        # input_tensor = torchvision.transforms.RandomErasing(p=1.0, scale=(0.1, 0.1), ratio=(1, 3), value=0, inplace=False)(input_tensor)
        try:
            output = T(input_tensor)
        except:
            output = T(input_tensor)
            print("$$$$$$$$$$$Run Again$$$$$$$$$$$$$$$")
        # Note: input_tensor can be a batch tensor with several images!

        # Construct the CAM object once, and then re-use it on many images:
        cam = GradCAM(model=T, target_layers=target_layers, use_cuda=True)

        # You can also use it within a with statement, to make sure it is freed,
        # In case you need to re-create it inside an outer loop:
        # with GradCAM(model=model, target_layers=target_layers, use_cuda=args.use_cuda) as cam:
        #   ...

        # We have to specify the target we want to generate
        # the Class Activation Maps for.
        # If targets is None, the highest scoring category
        # will be used for every image in the batch.
        # Here we use ClassifierOutputTarget, but you can define your own custom targets
        # That are, for example, combinations of categories, or specific outputs in a non standard model.
        targets = [ClassifierOutputTarget(target)]

        # You can also pass aug_smooth=True and eigen_smooth=True, to apply smoothing.
        grayscale_cam = cam(input_tensor=input_tensor, targets=targets)

        # In this example grayscale_cam has only one image in the batch:
        grayscale_cam = grayscale_cam[0, :]
        average_grayscale_cam += grayscale_cam
        input_tensor = torch.squeeze(input_tensor, 0)
        rgb_img = torchvision.transforms.ToPILImage()(input_tensor)
        rgb_img = np.array(rgb_img)/255

        visualization = show_cam_on_image(rgb_img, grayscale_cam, use_rgb=True)
        # print(visualization, rgb_img, grayscale_cam)
        # exit()
        im = Image.fromarray(visualization)
        im.save(os.path.join(individual_save_dir, grad_cam_image_name))
        count+=1

# grad_cam(dataset=dataset, model=T, save_dir=all_img_dir_gradcam, except_names=sucess_names)
# grad_cam(dataset=sucess_dataset, model=T, save_dir=success_img_dir_gradcam)
grad_cam(dataset=un_sucess_dataset, model=T, save_dir=un_success_img_dir_gradcam)

