import os
import numpy as np

attack_dir = "/home/hung/PLG_MI/PLG_MI_Inversion_RE_0.2_0.2_1_1_meansub"
success_dir = os.path.join(attack_dir, "success_imgs")
acc_list = []
for id in range(300):
    id_success_dir = os.path.join(success_dir, str(id))
    if not os.path.isdir(id_success_dir): 
        num_correct = 0
    else:
        num_correct = len(os.listdir(id_success_dir))
    acc = num_correct/5*100
    acc_list.append(acc)
accs = np.array(acc_list)
print(len(acc_list))
print("error bar", np.std(accs), np.mean(accs))

